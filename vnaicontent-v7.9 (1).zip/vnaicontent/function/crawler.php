<?php
class VnAIContentCrawler
{
    private $maxContentSize = 5000000; // 5MB
    private $minWordCount = 350;
    private $maxSanitizedSize = 500000; // 500KB
    private $retryAttempts = 3;
    private $retryDelay = 1; // seconds

    public function crawl(string $url): string
    {
        try {
            $this->validateUrl($url);
            $html = $this->fetchContent($url);

            if (empty($html)) {
                return '';
            }

            $dom = $this->initializeDom($html);
            $this->removeUnwantedElements($dom);
            $content = $this->extractMainContent($dom);

            return $this->sanitizeContent($content);
        } catch (Exception $e) {
            error_log("Crawl error for URL {$url}: " . $e->getMessage());
            throw $e;
        } finally {
            if (isset($dom)) {
                $dom->clear();
                unset($dom);
            }
            unset($html);
        }
    }

    private function validateUrl(string $url): void
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new InvalidArgumentException('Invalid URL provided');
        }
    }

    private function initializeDom(string $html): simple_html_dom
    {
        if (strlen($html) > $this->maxContentSize) {
            throw new Exception('Content exceeds size limit');
        }

        $simpleDomPath = $this->getLibraryPath();
        require_once $simpleDomPath;

        $dom = new simple_html_dom();
        $dom->load($html);
        return $dom;
    }

    private function getLibraryPath(): string
    {
        $path = VNAICONTENT_PATH . 'lib/simple_html_dom.php';
        if (!file_exists($path)) {
            throw new Exception('Required library not found');
        }
        return $path;
    }

    private function removeUnwantedElements(simple_html_dom $dom): void
    {
        $unwantedTags = [
            'nav',
            'header',
            'footer',
            'time',
            'noscript',
            'script',
            'style',
            'iframe',
            'div#ez-toc-container',
            'div.vnaicontent-toc'
        ];

        foreach ($unwantedTags as $tag) {
            foreach ($dom->find($tag) as $item) {
                $item->remove();
            }
        }
    }

    private function extractMainContent(simple_html_dom $dom): string
    {
        // Try adjacent paragraphs method
        $content = $this->extractByParagraphs($dom);
        if ($this->isContentValid($content)) {
            return $content;
        }

        // Try content/detail classes method
        $content = $this->extractByContentClasses($dom);
        if ($this->isContentValid($content)) {
            return $content;
        }

        // Try text density method
        return $this->extractByTextDensity($dom);
    }

    private function extractByParagraphs(simple_html_dom $dom): string
    {
        $p_elements = $dom->find('p');
        foreach ($p_elements as $index => $p) {
            if (
                isset($p_elements[$index + 1]) &&
                $p->parent() === $p_elements[$index + 1]->parent()
            ) {
                $parent = $p->parent();
                if ($parent) {
                    return $parent->innertext;
                }
            }
        }
        return '';
    }

    private function extractByContentClasses(simple_html_dom $dom): string
    {
        $patterns = ['content', 'detail', 'article', 'post'];
        foreach ($patterns as $pattern) {
            $elements = $dom->find("[class*={$pattern}], [id*={$pattern}]");
            foreach ($elements as $element) {
                if ($this->isContentValid($element->innertext)) {
                    return $element->innertext;
                }
            }
        }
        return '';
    }

    private function extractByTextDensity(simple_html_dom $dom): string
    {
        $maxDensity = 0;
        $bestElement = null;

        foreach ($dom->find('*') as $element) {
            $density = $this->calculateTextDensity($element);
            if ($density > $maxDensity) {
                $maxDensity = $density;
                $bestElement = $element;
            }
        }

        if ($bestElement && $bestElement->parent()) {
            return $bestElement->parent()->innertext;
        }

        return '';
    }

    private function calculateTextDensity($element): float
    {
        $text = strip_tags($element->innertext);
        $wordCount = str_word_count($text);
        $tagCount = substr_count($element->innertext, '<') ?: 1;

        return $wordCount / $tagCount;
    }

    private function fetchContent(string $url): string
    {
        $attempt = 0;
        while ($attempt < $this->retryAttempts) {
            try {
                $response = wp_remote_get($url, $this->getRequestArgs());

                if (is_wp_error($response)) {
                    throw new Exception($response->get_error_message());
                }

                $statusCode = wp_remote_retrieve_response_code($response);
                if ($statusCode !== 200) {
                    throw new Exception("HTTP error {$statusCode}");
                }

                return wp_remote_retrieve_body($response);
            } catch (Exception $e) {
                $attempt++;
                if ($attempt === $this->retryAttempts) {
                    error_log("Failed to fetch {$url} after {$this->retryAttempts} attempts: {$e->getMessage()}");
                    return '';
                }
                sleep($this->retryDelay);
            }
        }
        return '';
    }

    private function getRequestArgs(): array
    {
        return [
            'timeout' => 30,
            'redirection' => 5,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
            'sslverify' => false,
            'headers' => [
                'Accept-Encoding' => 'gzip, deflate'
            ]
        ];
    }

    private function sanitizeContent(string $content): string
    {
        if (empty($content)) {
            return '';
        }

        // Basic sanitization
        $content = wp_kses_post($content);
        $content = preg_replace('/\s+/', ' ', $content);
        $content = trim($content);

        // Additional security measures
        $content = $this->sanitizeUrls($content);

        if (!$this->isContentValid($content)) {
            return '';
        }

        if (strlen($content) > $this->maxSanitizedSize) {
            $content = mb_substr($content, 0, $this->maxSanitizedSize);
        }

        return $content;
    }

    private function sanitizeUrls(string $content): string
    {
        // Remove potentially harmful URLs
        return preg_replace(
            '/(href|src)=(["\'])(javascript|data|vbscript):/i',
            '$1=$2#',
            $content
        );
    }

    private function isContentValid(string $content): bool
    {
        return str_word_count(strip_tags($content)) >= $this->minWordCount;
    }
}
