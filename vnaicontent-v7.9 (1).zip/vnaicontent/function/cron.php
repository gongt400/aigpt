<?php
class CronVnAIContent
{
    private $options;
    private $create;
    private $max_execution_time = 900;

    public function __construct()
    {
        $this->options = get_option('vnaicontent_option');
        require_once VNAICONTENT_PATH . 'function/create.php';
        $this->create = new VnAIContentCreatePost();

        add_action('update_option_vnaicontent_option', array($this, 'update_cron_schedules'), 10, 2);
        add_filter('cron_schedules', array($this, 'register_cron_schedules'));
        $this->register_cron_jobs();
    }

    public function register_cron_jobs()
    {
        $cron_jobs = array(
            'post_action' => 'vnaicontent_post_action_cron',
            'img_action' => 'vnaicontent_img_action_cron',
            'publish_action' => 'vnaicontent_publish_action_cron',
            'yt_action' => 'vnaicontent_yt_action_cron',
            'tag_action' => 'vnaicontent_tag_action_cron',
            'des_action' => 'vnaicontent_des_action_cron',
            'feed_podcast_action' => 'vnaicontent_feed_podcast_action_cron'
        );
        if ($this->check_at()) {
            $cron_jobs['audio_action'] = 'vnaicontent_audio_action_cron';
        }

        foreach ($cron_jobs as $option_key => $cron_hook) {
            if (!wp_next_scheduled($cron_hook) && isset($this->options[$option_key . '_time']) && $this->options[$option_key . '_time'] > 0) {
                wp_schedule_event(time(), $option_key . '_schedule', $cron_hook);
            }
            add_action($cron_hook, array($this, $option_key));
        }
    }

    public function update_cron_schedules($old_value, $new_value)
    {
        $cron_jobs = array(
            'post_action' => 'vnaicontent_post_action_cron',
            'img_action' => 'vnaicontent_img_action_cron',
            'publish_action' => 'vnaicontent_publish_action_cron',
            'yt_action' => 'vnaicontent_yt_action_cron',
            'tag_action' => 'vnaicontent_tag_action_cron',
            'des_action' => 'vnaicontent_des_action_cron',
            'feed_podcast_action' => 'vnaicontent_feed_podcast_action_cron'
        );

        if ($this->check_at()) {
            $cron_jobs['audio_action'] = 'vnaicontent_audio_action_cron';
        }

        foreach ($cron_jobs as $option_key => $cron_hook) {
            if (isset($old_value[$option_key . '_time']) && isset($new_value[$option_key . '_time'])) {
                if ($old_value[$option_key . '_time'] != $new_value[$option_key . '_time']) {
                    $timestamp = wp_next_scheduled($cron_hook);
                    if ($timestamp) {
                        wp_unschedule_event($timestamp, $cron_hook);
                    }
                    if ($new_value[$option_key . '_time'] > 0) {
                        wp_schedule_event(time(), $option_key . '_schedule', $cron_hook);
                    }
                }
            }
        }
    }

    public function register_cron_schedules($schedules)
    {
        $cron_jobs = array('post_action', 'img_action', 'publish_action', 'yt_action', 'tag_action', 'des_action', 'feed_podcast_action');
        if ($this->check_at()) {
            $cron_jobs[] = 'audio_action';
        }

        foreach ($cron_jobs as $job) {
            $time = isset($this->options[$job . '_time']) ? $this->options[$job . '_time'] : 0;
            if ($time > 0) {
                $schedules[$job . '_schedule'] = array(
                    'interval' => $time * 60,
                    'display' => sprintf(__('Every %d minutes'), $time)
                );
            }
        }

        return $schedules;
    }

    private function should_execute($option_key)
    {
        $current_time = time();
        $start_time = get_option($option_key, false);
        if ($start_time !== false) {
            if ($current_time - $start_time < $this->max_execution_time) {
                return false;
            } else {
                update_option($option_key, $current_time, 'no');
                return true;
            }
        }
        add_option($option_key, $current_time, '', 'no');
        return true;
    }

    private function complete_execution($option_key)
    {
        delete_option($option_key);
    }

    public function post_action()
    {
        if (!$this->should_execute('vnaicontent_post_action_running')) {
            return;
        }

        try {
            $this->create->create($this->options['type_ai']);
        } catch (Exception $e) {
            $this->create->log_mess('VnAIContent post_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_post_action_running');
        }
    }

    public function img_action()
    {
        if (!$this->should_execute('vnaicontent_img_action_running')) {
            return;
        }

        try {
            $post_status = array('publish', 'draft');
            if (!empty($this->options['status_post_img'])) {
                $post_status = $this->options['status_post_img'];
            }

            $args = array(
                'post_type'   => 'post',
                'numberposts' => 1,
                'post_status' => $post_status,
                'fields'      => 'ids',
                'meta_query' => array(
                    array(
                        'key'     => 'img_by',
                        'compare' => 'NOT EXISTS',
                    )
                )
            );
            if (isset($this->options['only_img_ai'])) {
                $args['meta_query'][] = array(
                    'key'     => 'type_ai',
                    'compare' => 'EXISTS',
                );
            }
            if (isset($this->options['exclude_cat_img']) && !empty($this->options['exclude_cat_img'])) {
                $args['category__not_in'] = explode(',', $this->options['exclude_cat_img']);
            }
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                $post_id = $query->posts[0];
                $this->create->create('', $post_id);
            } else {
                $mess = '<span class="red-text">Không còn bài viết hợp lệ để tạo ảnh!</span>';
                $this->create->log_mess($mess, false, true, 0);
            }
            wp_reset_postdata();
        } catch (Exception $e) {
            $this->create->log_mess('VnAIContent img_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_img_action_running');
        }
    }

    public function publish_action()
    {
        if (!$this->should_execute('vnaicontent_publish_action_running')) {
            return;
        }

        try {
            $args = array(
                'post_type'   => 'post',
                'numberposts' => 1,
                'post_status' => 'draft',
                'orderby'     => 'rand',
                'fields'      => 'ids',
                'meta_query' => array(
                    array(
                        'key'     => 'type_ai',
                        'compare' => 'EXISTS',
                    )
                )
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                $post_id = $query->posts[0];
                $current_time = time();
                $row = array(
                    'ID'                => $post_id,
                    'post_status'       => 'publish',
                    'post_date'         => date('Y-m-d H:i:s', $current_time),
                    'post_date_gmt'     => gmdate('Y-m-d H:i:s', $current_time),
                    'post_modified'     => date('Y-m-d H:i:s', $current_time),
                    'post_modified_gmt' => gmdate('Y-m-d H:i:s', $current_time)
                );
                wp_update_post($row);
            }
            wp_reset_postdata();
        } catch (Exception $e) {
            $this->create->log_mess('VnAIContent publish_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_publish_action_running');
        }
    }

    public function audio_action()
    {
        if (!$this->should_execute('vnaicontent_audio_action_running')) {
            return;
        }

        try {
            $args = array(
                'post_type'      => 'post',
                'post_status'    => !empty($this->options['audio_status_post']) ? $this->options['audio_status_post'] : array('draft', 'publish'),
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'orderby'        => 'rand',
                'meta_query'     => array(
                    array(
                        'key'     => 'audio',
                        'compare' => 'NOT EXISTS',
                    ),
                ),
            );

            if (!empty($this->options['audio_exclude_cat'])) {
                $args['category__not_in'] = explode(',', $this->options['audio_exclude_cat']);
            }

            $query = new WP_Query($args);

            if ($query->have_posts()) {
                $post_id = $query->posts[0];

                if ($this->check_thumb($post_id)) {
                    require_once VNAICONTENT_PATH . 'function/audio.php';
                    $audio = new VnAIContentAudio();
                    $audio->create_audio($post_id);
                } else {
                    update_post_meta($post_id, 'audio', 'Error');
                    $mess = '<span class="orange-text">Bài viết không có thumbnail hoặc file thumbnail không tồn tại, đang tìm bài khác...</span>';
                    $this->create->log_mess($mess, false, true, 0);
                }
            } else {
                $mess = '<span class="orange-text">Đã hết bài viết để tạo audio!</span>';
                $this->create->log_mess($mess, false, true, 0);
            }
            wp_reset_postdata();
        } catch (Exception $e) {
            $this->create->log_mess('audio_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_audio_action_running');
        }
    }

    public function yt_action()
    {
        if (!$this->should_execute('vnaicontent_yt_action_running')) {
            return;
        }

        try {
            $args = array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => 5,
                'fields'         => 'ids',
                'orderby'        => 'rand',
                'meta_query'     => array(
                    array(
                        'key'     => 'youtube_id',
                        'compare' => 'NOT EXISTS',
                    ),
                ),
            );

            $query = new WP_Query($args);

            if ($query->have_posts()) {
                $post_ids = $query->posts;
                foreach ($post_ids as $post_id) {
                    $this->get_yt_for_post($post_id);
                    sleep(2);
                }
            } else {
                $mess = '<span class="orange-text">Đã hết bài viết để lấy video youtube!</span>';
                $this->create->log_mess($mess, false, true, 0);
            }
            wp_reset_postdata();
        } catch (Exception $e) {
            $this->create->log_mess('yt_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_yt_action_running');
        }
    }

    public function tag_action()
    {
        if (!$this->should_execute('vnaicontent_tag_action_running')) {
            return;
        }

        try {
            $args = array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'orderby'        => 'rand',
                'tax_query'      => array(
                    array(
                        'taxonomy' => 'post_tag',
                        'operator' => 'NOT EXISTS'
                    )
                ),
                'meta_query' => array(
                    array(
                        'key'     => 'tag',
                        'compare' => 'NOT EXISTS'
                    )
                )
            );

            $query = new WP_Query($args);

            if ($query->have_posts()) {
                $mess = '<span class="orange-text">Đang tạo tag!</span>';
                $this->create->log_mess($mess, false, true, 0);

                $post_id = $query->posts[0];
                $tags = $this->create->create_tag($post_id);
                if (!empty($tags)) {
                    wp_set_post_tags($post_id, $tags, true);
                    update_post_meta($post_id, 'tag', 'ok');
                    $mess = '<span class="green-text">Tạo tag thành công!</span>';
                    $this->create->log_mess($mess, false, true, 2);
                } else {
                    update_post_meta($post_id, 'tag', 'no');
                }
            } else {
                $mess = '<span class="orange-text">Đã hết bài viết để tạo tag!</span>';
                $this->create->log_mess($mess, false, true, 0);
            }
            wp_reset_postdata();
        } catch (Exception $e) {
            $this->create->log_mess('tag_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_tag_action_running');
        }
    }

    public function des_action()
    {
        if (!$this->should_execute('vnaicontent_des_action_running')) {
            return;
        }

        try {
            $args = array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'orderby'        => 'rand',
                'meta_query' => array(
                    array(
                        'key'     => 'des',
                        'compare' => 'NOT EXISTS'
                    )
                )
            );

            $query = new WP_Query($args);

            if ($query->have_posts()) {
                $mess = '<span class="orange-text">Đang tạo meta description!</span>';
                $this->create->log_mess($mess, false, true, 0);

                $post_id = $query->posts[0];
                $excerpt = $this->create->create_des($post_id);
                if (!empty($excerpt)) {
                    wp_update_post(array('ID' => $post_id, 'post_excerpt' => wp_strip_all_tags($excerpt)));
                    update_post_meta($post_id, 'des', 'ok');
                    $mess = '<span class="green-text">Tạo meta description thành công!</span>';
                    $this->create->log_mess($mess, false, true, 2);
                } else {
                    update_post_meta($post_id, 'des', 'no');
                }
            } else {
                $mess = '<span class="orange-text">Đã hết bài viết để tạo meta description!</span>';
                $this->create->log_mess($mess, false, true, 0);
            }
            wp_reset_postdata();
        } catch (Exception $e) {
            $this->create->log_mess('des_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_des_action_running');
        }
    }

    private function get_yt_for_post($post_id)
    {
        if (empty($this->options['yt_url'])) {
            $mess = '<span class="red-text">Chưa nhập url kênh Youtube</span>';
            $this->create->log_mess($mess, false, true, 0);
        } else {
            $url = $this->options['yt_url'] . '/search?query=id' . $post_id;

            $response = wp_remote_get($url, array(
                'timeout' => 10,
                'sslverify' => false,
            ));

            if (is_wp_error($response)) {
                $this->create->log_mess('get_yt_for_post: Lỗi khi thực hiện truy vấn đến youtube ' . $response->get_error_message(), true, false, 0);
                update_post_meta($post_id, 'youtube_id', 'no');
            } else {
                $body = wp_remote_retrieve_body($response);
                preg_match('/"videoIds":\["(.*?)"\]/', $body, $matches);

                if (!empty($matches[1])) {
                    $mess = '<span class="green-text">Lấy video youtube cho bài viết thành công!</span>';
                    $this->create->log_mess($mess, false, true, 2);
                    update_post_meta($post_id, 'youtube_id', $matches[1]);
                } else {
                    $mess = '<span class="red-text">Không tìm thấy video</span>';
                    $this->create->log_mess($mess, false, true, 0);
                    update_post_meta($post_id, 'youtube_id', 'no');
                }
            }
        }
    }

    public function feed_podcast_action()
    {
        if (!$this->should_execute('vnaicontent_feed_podcast_action_running')) {
            return;
        }

        try {
            $args = array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'meta_query'     => array(
                    array(
                        'key'     => 'audio',
                        'value'   => 'error',
                        'compare' => '!=',
                    ),
                ),
                'fields'         => 'ids',
                'posts_per_page' => -1,
            );

            $query = new WP_Query($args);
            $total_posts = $query->post_count;
            wp_reset_postdata();

            $feed_podcast_offset = (isset($this->options['feed_podcast_offset']) ? $this->options['feed_podcast_offset'] : 0) + get_option('posts_per_rss');

            if ($feed_podcast_offset >= $total_posts) {
                $feed_podcast_offset = 0;
                $this->options['feed_podcast_order'] = '';
                $this->options['feed_podcast_action_time'] = 0;
            }
            $this->options['feed_podcast_offset'] = $feed_podcast_offset;

            update_option('vnaicontent_option', $this->options);
        } catch (Exception $e) {
            $this->create->log_mess('feed_podcast_action error: ' . $e->getMessage(), true, false, 0);
        } finally {
            $this->complete_execution('vnaicontent_feed_podcast_action_running');
        }
    }

    private function check_thumb($post_id)
    {
        if (!isset($this->options['audio_check_thumb'])) {
            return true;
        }
        if (!has_post_thumbnail($post_id)) {
            return false;
        }
        $thumbnail_id = get_post_thumbnail_id($post_id);
        $thumbnail_path = get_attached_file($thumbnail_id);
        return $thumbnail_path && file_exists($thumbnail_path);
    }

    private function check_at()
    {
        $end_t = get_option('vnaicontent_end_time');
        if (isset($end_t) && ($end_t >= 5 || $end_t == -1)) {
            return true;
        } else {
            return false;
        }
    }
}

$cron_vnaicontent = new CronVnAIContent();
