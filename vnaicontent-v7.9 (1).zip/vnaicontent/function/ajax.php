<?php
// clear_cache
add_action('wp_ajax_clear_cache', function () {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vnaicontent_clear_cache')) {
        wp_send_json_error('Invalid nonce');
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    try {
        global $wpdb;
        $total_processed = 0;

        // Xóa tất cả transients liên quan
        $deleted = $wpdb->query("
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient%related_posts_%' 
            OR option_name LIKE '_transient%post_toc_%'
            OR option_name LIKE '_transient%post_char_count_%'
            OR option_name LIKE '_transient%post_audio_%'
            OR option_name LIKE '_transient%post_youtube_%'
        ");

        // Xử lý từng batch bài viết
        $batch_size = 100;
        $offset = 0;

        while (true) {
            $posts = get_posts([
                'posts_per_page' => $batch_size,
                'offset' => $offset,
                'post_type' => 'post',
                'fields' => 'ids',
                'no_found_rows' => true,
                'ignore_sticky_posts' => true
            ]);

            if (empty($posts)) {
                break;
            }

            foreach ($posts as $post_id) {
                // Xóa related posts cache
                for ($i = 1; $i <= 10; $i++) {
                    delete_transient('related_posts_' . $post_id . '_' . $i);
                    if (wp_using_ext_object_cache()) {
                        wp_cache_delete('related_posts_' . $post_id . '_' . $i);
                    }
                }

                // Xóa taxonomy cache
                delete_transient('post_categories_' . $post_id);
                delete_transient('post_tags_' . $post_id);
                delete_transient('post_toc_' . $post_id);
                delete_transient('post_char_count_' . $post_id);
                delete_transient('post_youtube_' . $post_id);

                if (wp_using_ext_object_cache()) {
                    wp_cache_delete('post_categories_' . $post_id);
                    wp_cache_delete('post_tags_' . $post_id);
                    wp_cache_delete('related_query_' . $post_id . '_tag');
                    wp_cache_delete('post_toc_' . $post_id);
                    wp_cache_delete('post_char_count_' . $post_id);
                    wp_cache_delete('post_youtube_' . $post_id);
                }

                // riêng audio
                $player_types = ['plyr', 'aplayer', 'default'];
                foreach ($player_types as $player) {
                    delete_transient('post_audio_' . $post_id . '_' . $player);
                    if (wp_using_ext_object_cache()) {
                        wp_cache_delete('post_audio_' . $post_id . '_' . $player);
                    }
                }

                $total_processed++;
            }

            $offset += $batch_size;

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Processed $total_processed posts. Memory usage: " . size_format(memory_get_usage(true)));
            }
        }

        wp_send_json_success([
            'message' => 'Cache cleared successfully',
            'processed' => $total_processed,
            'transients_deleted' => $deleted
        ]);
    } catch (Exception $e) {
        error_log('Cache clear error: ' . $e->getMessage());
        wp_send_json_error($e->getMessage());
    }
});

//createprompt_savecat
add_action('wp_ajax_vnaicontent_createprompt_savecat', 'vnaicontent_createprompt_savecat');
function vnaicontent_createprompt_savecat()
{
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vnaicontent_createprompt_savecat_action')) {
        wp_send_json_error('Invalid security token sent.');
        die();
    }

    $cat = isset($_POST['cat']) ? sanitize_text_field($_POST['cat']) : '';
    $prompt = isset($_POST['prompt']) ? $_POST['prompt'] : '';
    $type_prompt = isset($_POST['type_prompt']) ? sanitize_text_field($_POST['type_prompt']) : '';

    if (empty($cat) || empty($prompt)) {
        wp_send_json_error('Dữ liệu không hợp lệ.');
        die();
    }

    update_term_meta($cat, $type_prompt, $prompt);

    wp_send_json_success(['html' => 'Lưu vào danh mục thành công']);
    die();
}

//createprompt
add_action('wp_ajax_vnaicontent_createprompt', 'vnaicontent_createprompt');
function vnaicontent_createprompt()
{
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vnaicontent_createprompt_action')) {
        wp_send_json_error('Invalid security token sent.');
        die();
    }

    $ai = isset($_POST['ai']) ? sanitize_text_field($_POST['ai']) : '';
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
    $topic = isset($_POST['topic']) ? sanitize_text_field($_POST['topic']) : '';
    $is_detail = isset($_POST['is_detail']) ? sanitize_text_field($_POST['is_detail']) : '';
    $is_as_ai = isset($_POST['is_as_ai']) ? sanitize_text_field($_POST['is_as_ai']) : '';

    if (empty($ai) || empty($model) || empty($topic)) {
        wp_send_json_error('Dữ liệu không hợp lệ.');
        die();
    }

    require_once VNAICONTENT_PATH . 'function/create.php';
    $create = new VnAIContentCreatePost();
    $options = get_option('vnaicontent_option');

    $in = array(
        'token' => $options['user_key'],
        'lang' => get_option('vnaicontent_option')['lang'],
        'topic' => $topic,
        'is_detail' => $is_detail,
        'is_as_ai' => $is_as_ai,
        'brand' => get_bloginfo('name'),
        'tool' => 'createprompt'
    );
    $out = $create->vnaicontent_user($in);

    if (isset($out['end_time'])) {
        //update_option('vnaicontent_end_time', $out['end_time']);
        if ($out['end_time'] == 1) {
            $mess = 'Chưa nhập User key';
        } elseif ($out['end_time'] == 2) {
            $mess = 'User key không hợp lệ';
        } elseif ($out['end_time'] == 3) {
            $mess = 'Tên miền không hợp lệ';
        }

        if (!empty($mess)) {
            wp_send_json_error($mess);
            die();
        }
    }

    if (empty($out['p'])) {
        wp_send_json_error('Không thể tạo ' . (!empty($is_as_ai) ? 'vai trò AI' : 'prompt') . '. Vui lòng thử lại. (1)');
        die();
    }

    if ($ai == 'gemini') {
        $api_key_str = $options['gemini_api_key'];
    } elseif ($ai == 'openai') {
        $api_key_str = $options['openai_api_key'];
    } elseif ($ai == 'claude') {
        $api_key_str = $options['claude_api_key'];
    } else {
        $api_key_str = 'abacus không cần api :D';
    }

    if (empty($api_key_str)) {
        wp_send_json_error('Không có ' . $ai . ' API key');
        die();
    }

    $res = $create->vnaicontent_type($ai, $out['p'], false, false, false, true);

    if (empty($res)) {
        wp_send_json_error('Không thể tạo ' . (!empty($is_as_ai) ? 'vai trò AI' : 'prompt') . '. Vui lòng thử lại. (1)');
        die();
    }

    $res = str_replace(['<prompt>', '</prompt>'], '', $res);
    $res = rtrim($res);

    $categories = get_categories(array(
        'hide_empty' => 0,
        'orderby' => 'name',
        'order' => 'ASC'
    ));

    $select = '<select id="cat-prompt">';
    $select .= '<option value="">Chọn danh mục để lưu</option>';

    foreach ($categories as $category) {
        $select .= sprintf(
            '<option value="%s" %s>%s</option>',
            esc_attr($category->term_id),
            '',
            esc_html($category->name)
        );
    }

    $select .= '</select>';

    $result = '<pre class="prompt-content">' . htmlspecialchars($res) . '</pre>
                <div class="res-prompt-cp">
                    ' . $select . '
                    <button id="prompt-to-cat" class="button" type="button">Lưu</button>
                    <button id="copy-keyword" class="button" type="button">Copy</button><span id="copy-mess" style="display:none; color: #00a32a; margin: 10px; position: relative; top: 2px;">Copied</span>
                </div>';

    wp_send_json_success(['html' => $result]);
    die();
}

//filterkeyword
add_action('wp_ajax_vnaicontent_filterkeyword', 'vnaicontent_filterkeyword');
function vnaicontent_filterkeyword()
{
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vnaicontent_filterkeyword_action')) {
        wp_send_json_error('Invalid security token sent.');
        die();
    }

    $lang = isset($_POST['lang']) ? sanitize_text_field($_POST['lang']) : '';
    $ai = isset($_POST['ai']) ? sanitize_text_field($_POST['ai']) : '';
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
    $topic = isset($_POST['topic']) ? sanitize_text_field($_POST['topic']) : '';

    if (empty($lang) || empty($ai) || empty($model) || empty($topic)) {
        wp_send_json_error('Dữ liệu không hợp lệ.');
        die();
    }

    if (!isset($_FILES['file'])) {
        wp_send_json_error('Không có file txt.');
        die();
    }

    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error('Lỗi khi upload file txt: ' . $file['error']);
        die();
    }

    $keywords = file($file['tmp_name'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (empty($keywords)) {
        wp_send_json_error('File txt rỗng');
        die();
    }
    $old_count = count($keywords);

    $keywords = array_map(function ($keyword) {
        return preg_replace('/[^\p{L}\p{N}\s]/u', '', mb_strtolower(trim($keyword), 'UTF-8'));
    }, $keywords);

    $keywords = array_unique(array_filter($keywords));

    $keywords_number = array_map(function ($index, $keyword) {
        return ($index + 1) . ". " . $keyword;
    }, range(0, count($keywords) - 1), $keywords);

    $keywords_txt = implode("\n", $keywords_number);

    require_once VNAICONTENT_PATH . 'function/create.php';
    $create = new VnAIContentCreatePost();
    $options = get_option('vnaicontent_option');

    $in = array(
        'token' => $options['user_key'],
        'lang' => $lang,
        'topic' => $topic,
        'tool' => 'filterkeyword'
    );
    $out = $create->vnaicontent_user($in);

    if (isset($out['end_time'])) {
        //update_option('vnaicontent_end_time', $out['end_time']);
        if ($out['end_time'] == 1) {
            $mess = 'Chưa nhập User key';
        } elseif ($out['end_time'] == 2) {
            $mess = 'User key không hợp lệ';
        } elseif ($out['end_time'] == 3) {
            $mess = 'Tên miền không hợp lệ';
        }

        if (!empty($mess)) {
            wp_send_json_error($mess);
            die();
        }
    }

    if (empty($out['p'])) {
        die();
    }

    if ($ai == 'gemini') {
        $api_key_str = $options['gemini_api_key'];
    } elseif ($ai == 'openai') {
        $api_key_str = $options['openai_api_key'];
    } elseif ($ai == 'claude') {
        $api_key_str = $options['claude_api_key'];
    } else {
        $api_key_str = 'abacus không cần api :D';
    }

    if (empty($api_key_str)) {
        wp_send_json_error('Không có ' . $ai . ' API key');
        die();
    }

    $res_ai = $create->vnaicontent_type($ai, $out['p'] . $keywords_txt, false, true);

    preg_match_all('/\b\d+(?:,\d+)*\b/', $res_ai, $matches);

    if (empty($matches[0])) {
        wp_send_json_error('Kết quả trả về từ ' . $ai . ' rỗng');
        die();
    }

    $keyword_str = '';
    foreach ($matches[0] as $match) {
        if (strlen($match) > strlen($keyword_str)) {
            $keyword_str = $match;
        }
    }

    $keyword_array = explode("\n", $keywords_txt);
    $selected_indices = explode(',', $keyword_str);

    $selected_keywords = [];
    foreach ($selected_indices as $index) {
        $array_index = intval($index) - 1;
        if (isset($keyword_array[$array_index])) {
            $keyword = preg_replace('/^\d+\.\s*/', '', $keyword_array[$array_index]);
            $selected_keywords[] = $keyword;
        }
    }

    $new_count = count($selected_keywords);
    $keywords_final = implode("\n", $selected_keywords);

    $result = '<div class="notice notice-success">
                    Số keyword ban đầu: ' . $old_count . '<br><br>
                    Số keyword sau khi lọc: ' . $new_count . '
                </div>
                <pre class="keyword-list">' . htmlspecialchars($keywords_final) . '</pre>
                <button id="copy-keyword" class="button" type="button">Copy</button><span id="copy-mess" style="display:none; color: #00a32a; margin: 10px; position: relative; top: 7px;">Copied</span>';

    wp_send_json_success(['html' => $result]);
    die();
}

//debug log
add_action('wp_ajax_vnaicontent_toggle_debug_log', 'vnaicontent_toggle_debug_log');
function vnaicontent_toggle_debug_log()
{
    $response = array('success' => false, 'message' => '', 'newNonce' => '');

    try {
        if (!check_ajax_referer('vnaicontent_config_action', 'nonce', false)) {
            throw new Exception('Invalid nonce. Please refresh the page and try again.');
        }

        if (!current_user_can('manage_options')) {
            throw new Exception('Insufficient permissions');
        }

        $config_file = ABSPATH . 'wp-config.php';
        if (!is_writable($config_file)) {
            throw new Exception('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_file);
        $debug_status = defined('WP_DEBUG') && WP_DEBUG;
        $debug_log_status = defined('WP_DEBUG_LOG') && WP_DEBUG_LOG;

        if ($debug_status && $debug_log_status) {
            $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*true\s*\);/", "define('WP_DEBUG', false);", $config_content);
            $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG_LOG['\"]\s*,\s*true\s*\);/", "define('WP_DEBUG_LOG', false);", $config_content);
            $new_status = false;
        } else {
            $config_content = vnaicontent_update_or_add_define($config_content, 'WP_DEBUG', 'true');
            $config_content = vnaicontent_update_or_add_define($config_content, 'WP_DEBUG_LOG', 'true');
            $new_status = true;
        }

        if (file_put_contents($config_file, $config_content) === false) {
            throw new Exception('Failed to write to wp-config.php');
        }

        $response['success'] = true;
        $response['message'] = 'Debug settings toggled successfully';
        $response['status'] = $new_status;
        $response['newNonce'] = wp_create_nonce('vnaicontent_config_action');
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log('VnAIContent Error: ' . $e->getMessage());
    }

    wp_send_json($response);
}

function vnaicontent_update_or_add_define($content, $constant, $value)
{
    $pattern = "/define\s*\(\s*['\"]" . preg_quote($constant, '/') . "['\"]\s*,.*?\);/";
    $replacement = "define('" . $constant . "', " . $value . ");";

    if (preg_match($pattern, $content)) {
        return preg_replace($pattern, $replacement, $content);
    } else {
        $insertion_point = strpos($content, "/* That's all, stop editing! Happy publishing. */");
        if ($insertion_point === false) {
            $insertion_point = strpos($content, "require_once ABSPATH . 'wp-settings.php';");
        }
        if ($insertion_point !== false) {
            return substr_replace($content, $replacement . "\n", $insertion_point, 0);
        } else {
            return $content . "\n" . $replacement . "\n";
        }
    }
}

add_action('wp_ajax_vnaicontent_read_log', 'vnaicontent_read_error_log');
function vnaicontent_read_error_log()
{
    $response = array('success' => false, 'message' => '', 'data' => '');

    try {
        if (!check_ajax_referer('vnaicontent_read_log', 'nonce', false)) {
            throw new Exception('Invalid nonce. Please refresh the page and try again.');
        }

        if (!current_user_can('manage_options')) {
            throw new Exception('Insufficient permissions');
        }

        $log_file = WP_CONTENT_DIR . '/debug.log';

        if (!file_exists($log_file)) {
            throw new Exception('Debug log file does not exist: ' . $log_file);
        }

        if (!is_readable($log_file)) {
            throw new Exception('Debug log file is not readable: ' . $log_file);
        }

        $log_content = file_get_contents($log_file);

        if ($log_content === false) {
            throw new Exception('Failed to read debug log file');
        }

        // Limit the size of the log content if it's too large
        $max_length = 1000000; // Approximately 1MB
        if (strlen($log_content) > $max_length) {
            $log_content = substr($log_content, -$max_length);
            $log_content = "... (log truncated)\n" . $log_content;
        }

        $response['success'] = true;
        $response['data'] = $log_content;
        $response['message'] = 'Log read successfully';
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log('VnAIContent Error reading log: ' . $e->getMessage());
    }

    wp_send_json($response);
}

add_action('wp_ajax_vnaicontent_clear_log', 'vnaicontent_clear_log');
function vnaicontent_clear_log()
{
    $response = array('success' => false, 'message' => '');

    try {
        if (!check_ajax_referer('vnaicontent_read_log', 'nonce', false)) {
            throw new Exception('Invalid nonce. Please refresh the page and try again.');
        }

        if (!current_user_can('manage_options')) {
            throw new Exception('Insufficient permissions');
        }

        $log_file = WP_CONTENT_DIR . '/debug.log';

        if (!file_exists($log_file)) {
            throw new Exception('Debug log file does not exist.');
        }

        if (!is_writable($log_file)) {
            throw new Exception('Debug log file is not writable.');
        }

        if (file_put_contents($log_file, '') !== false) {
            $response['success'] = true;
            $response['message'] = 'Log file cleared successfully.';
        } else {
            throw new Exception('Failed to clear the log file.');
        }
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log('VnAIContent Error clearing log: ' . $e->getMessage());
    }

    wp_send_json($response);
}

add_action('wp_ajax_ajax_load_keyword', 'ajax_load_keyword');
add_action('wp_ajax_nopriv_ajax_load_keyword', 'ajax_load_keyword');
function ajax_load_keyword()
{
    $cat = isset($_POST['cat']) ? $_POST['cat'] : '';
    if ($cat != '') {
        $keyword_txt = VNAICONTENT_DATA . 'keyword_' . $cat . '.txt';
        $keyword_value = file_exists($keyword_txt) ? file_get_contents($keyword_txt) : '';
        echo $keyword_value;
    }
    die();
}

add_action('wp_ajax_vnaicontent_create_post', 'vnaicontent_create_post');
add_action('wp_ajax_nopriv_vnaicontent_create_post', 'vnaicontent_create_post');
function vnaicontent_create_post()
{
    set_time_limit(0);
    if ((!isset($GLOBALS['vnaicontent_post_executed']) || !$GLOBALS['vnaicontent_post_executed'])) {
        $GLOBALS['vnaicontent_post_executed'] = true;
        require_once VNAICONTENT_PATH . 'function/create.php';
        $create = new VnAIContentCreatePost();
        $type_ai = isset($_POST['type_ai']) ? $_POST['type_ai'] : 'gemini';

        $ajax = array(
            'cmd'       => isset($_POST['cmd']) ? $_POST['cmd'] : '',
            'img_by'    => isset($_POST['img_by']) ? $_POST['img_by'] : '',
            'keyword'   => isset($_POST['keyword']) ? $_POST['keyword'] : '',
            'post_id'   => isset($_POST['id']) ? $_POST['id'] : '',
            'content'   => isset($_POST['content']) ? $_POST['content'] : '',
            'num_title' => isset($_POST['num_title']) ? $_POST['num_title'] : 0,
            'cat'       => isset($_POST['cat']) ? $_POST['cat'] : ''
        );

        $create->create($type_ai, '', $ajax);

        $GLOBALS['vnaicontent_post_executed'] = false;
    }
    die();
}

add_action('wp_ajax_vnaicontent_save_post', 'vnaicontent_save_post');
add_action('wp_ajax_nopriv_vnaicontent_save_post', 'vnaicontent_save_post');
function vnaicontent_save_post()
{
    set_time_limit(0);
    if ((!isset($GLOBALS['save_post_executed']) || !$GLOBALS['save_post_executed'])) {
        $GLOBALS['save_post_executed'] = true;

        require_once VNAICONTENT_PATH . 'function/create.php';
        $save = new VnAIContentCreatePost();

        $ajax = array(
            'cmd'       => isset($_POST['cmd']) ? $_POST['cmd'] : 'save_draft',
            'post_id'   => isset($_POST['id']) ? $_POST['id'] : '',
            'type_ai'   => isset($_POST['type_ai']) ? $_POST['type_ai'] : 'gemini',
            'img_by'    => isset($_POST['img_by']) ? $_POST['img_by'] : '',
            'keyword'   => isset($_POST['keyword']) ? $_POST['keyword'] : '',
            'slug'      => isset($_POST['slug']) ? $_POST['slug'] : '',
            'title'     => isset($_POST['title']) ? $_POST['title'] : '',
            'content'   => isset($_POST['content']) ? $_POST['content'] : '',
            'num_title' => isset($_POST['num_title']) ? $_POST['num_title'] : 0,
            'cat'       => isset($_POST['cat']) ? $_POST['cat'] : ''
        );
        $save->save_post_ajax($ajax);

        $GLOBALS['save_post_executed'] = false;
    }
    die();
}

function vnaicontent_line_count_ajax($file)
{
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES);
        return count($lines);
    } else {
        return 0;
    }
}

add_action('wp_ajax_vnaicontent_save_keyword', 'vnaicontent_save_keyword');
add_action('wp_ajax_nopriv_vnaicontent_save_keyword', 'vnaicontent_save_keyword');
function vnaicontent_save_keyword()
{
    $keyword_arr              = array();
    $keyword_active_arr       = array();
    $keyword_miss_arr         = array();
    $keyword_post_removed_arr = array();
    $keyword_not_suitable_arr = array();

    $cat = isset($_POST['cat']) ? $_POST['cat'] : '';

    $keyword              = 'keyword_' . $cat;
    $keyword_active       = 'keyword_active_' . $cat;
    $keyword_miss         = 'keyword_miss_' . $cat;
    $keyword_post_removed = 'keyword_post_removed_' . $cat;
    $keyword_not_suitable = 'keyword_not_suitable_' . $cat;

    $keyword_txt              = VNAICONTENT_DATA . $keyword . '.txt';
    $keyword_active_txt       = VNAICONTENT_DATA . $keyword_active . '.txt';
    $keyword_miss_txt         = VNAICONTENT_DATA . $keyword_miss . '.txt';
    $keyword_post_removed_txt = VNAICONTENT_DATA . $keyword_post_removed . '.txt';
    $keyword_not_suitable_txt = VNAICONTENT_DATA . $keyword_not_suitable . '.txt';

    $input_keyword              = isset($_POST['input_keyword']) ? $_POST['input_keyword'] : '';
    $input_keyword_active       = isset($_POST['input_keyword_active']) ? $_POST['input_keyword_active'] : '';
    $input_keyword_miss         = isset($_POST['input_keyword_miss']) ? $_POST['input_keyword_miss'] : '';
    $input_keyword_post_removed = isset($_POST['input_keyword_post_removed']) ? $_POST['input_keyword_post_removed'] : '';
    $input_keyword_not_suitable = isset($_POST['input_keyword_not_suitable']) ? $_POST['input_keyword_not_suitable'] : '';

    $keyword_arr              = array_unique(array_map('trim', explode("\n", preg_replace('/^\s*$\n|\\\/m', '', $input_keyword))));
    $keyword_active_arr       = array_unique(array_map('trim', explode("\n", preg_replace('/^\s*$\n|\\\/m', '', $input_keyword_active))));
    $keyword_miss_arr         = array_unique(array_map('trim', explode("\n", preg_replace('/^\s*$\n|\\\/m', '', $input_keyword_miss))));
    $keyword_post_removed_arr = array_unique(array_map('trim', explode("\n", preg_replace('/^\s*$\n|\\\/m', '', $input_keyword_post_removed))));
    $keyword_not_suitable_arr = array_unique(array_map('trim', explode("\n", preg_replace('/^\s*$\n|\\\/m', '', $input_keyword_not_suitable))));

    $keyword_arr = array_diff($keyword_arr, $keyword_active_arr, $keyword_miss_arr, $keyword_not_suitable_arr);

    $new_input_keyword              = implode("\n", $keyword_arr);
    $new_input_keyword_active       = implode("\n", $keyword_active_arr);
    $new_input_keyword_miss         = implode("\n", $keyword_miss_arr);
    $new_input_keyword_post_removed = implode("\n", $keyword_post_removed_arr);
    $new_input_keyword_not_suitable = implode("\n", $keyword_not_suitable_arr);

    if ($new_input_keyword != '') {
        file_put_contents($keyword_txt, $new_input_keyword);
    } else {
        wp_delete_file($keyword_txt);
    }

    if ($new_input_keyword_active != '') {
        file_put_contents($keyword_active_txt, $new_input_keyword_active);
    } else {
        wp_delete_file($keyword_active_txt);
    }

    if ($new_input_keyword_miss != '') {
        file_put_contents($keyword_miss_txt, $new_input_keyword_miss);
    } else {
        wp_delete_file($keyword_miss_txt);
    }

    if ($new_input_keyword_post_removed != '') {
        file_put_contents($keyword_post_removed_txt, $new_input_keyword_post_removed);
    } else {
        wp_delete_file($keyword_post_removed_txt);
    }

    if ($new_input_keyword_not_suitable != '') {
        file_put_contents($keyword_not_suitable_txt, $new_input_keyword_not_suitable);
    } else {
        wp_delete_file($keyword_not_suitable_txt);
    }

    $topic = isset($_POST['input_topic']) ? $_POST['input_topic'] : '';
    update_term_meta($cat, 'topic', sanitize_text_field($topic));

    echo '<div style="border: 1px solid #8c8f94; padding: 15px; margin-top: 15px;">
            Trước khi AI tạo bài sẽ kiểm tra xem keyword có phù hợp với</label>
            <input style="' . (!empty($topic) ? 'font-weight: bold;' : '') . '" name="topic_' . $cat . '" id="topic_' . $cat . '" class="regular-text" value="' . $topic . '" type="text" placeholder="công thức, cách làm món ăn">
            hay không? Nếu không sẽ bị loại bỏ. <code>(Nếu để trống sẽ không kiểm tra)</code>
        </div>';

    echo '<div class="poststuff">';
    echo '<div class="postbox">';
    echo '<div class="postbox-header">';
    echo '<h2 class="hndle">Keywords chưa tạo bài viết (' . vnaicontent_line_count_ajax($keyword_txt) . ')</h2>';
    echo '</div>';
    echo '<div class="inside">';
    echo '<textarea style="width: 100%" wrap="off" id="' . $keyword . '" class="large-text" rows="15">' . $new_input_keyword . '</textarea>';
    echo '</div>';
    echo '</div>';

    echo '<div class="postbox">';
    echo '<div class="postbox-header">';
    echo '<h2 class="green-text">Keywords tạo bài viết thành công (' . vnaicontent_line_count_ajax($keyword_active_txt) . ')</h2>';
    echo '</div>';
    echo '<div class="inside">';
    echo '<textarea style="width: 100%" wrap="off" id="' . $keyword_active . '" class="large-text" rows="15">' . $new_input_keyword_active . '</textarea>';
    echo '</div>';
    echo '</div>';

    echo '<div class="postbox">';
    echo '<div class="postbox-header">';
    echo '<h2 class="red-text">Keywords tạo bài viết thất bại (' . vnaicontent_line_count_ajax($keyword_miss_txt) . ')</h2>';
    echo '</div>';
    echo '<div class="inside">';
    echo '<textarea style="width: 100%" wrap="off" id="' . $keyword_miss . '" class="large-text" rows="15">' . $new_input_keyword_miss . '</textarea>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div class="poststuff">';
    echo '<div class="postbox">';
    echo '<div class="postbox-header">';
    echo '<h2 class="red-text">Keywords không phù hợp (' . vnaicontent_line_count_ajax($keyword_not_suitable_txt) . ')</h2>';
    echo '</div>';
    echo '<div class="inside">';
    echo '<textarea style="width: 100%" wrap="off" id="' . $keyword_not_suitable . '" class="large-text" rows="15">' . $new_input_keyword_not_suitable . '</textarea>';
    echo '</div>';
    echo '</div>';

    echo '<div class="postbox">';
    echo '<div class="postbox-header">';
    echo '<h2 class="red-text">Keywords của bài viết đã xóa (' . vnaicontent_line_count_ajax($keyword_post_removed_txt) . ')</h2>';
    echo '</div>';
    echo '<div class="inside">';
    echo '<textarea style="width: 100%" wrap="off" id="' . $keyword_post_removed . '" class="large-text" rows="15">' . $new_input_keyword_post_removed . '</textarea>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

    echo '<button type="button" class="button button-primary" id="save-keyword" data-cat="' . $cat . '">Save</button>';
    echo '<p class="orange-text"><em>(*) Mỗi keyword trên 1 dòng</em></p>';
    die();
}

//check_mess
function vnaicontent_check_mess()
{
    $last_update = isset($_POST['last_update']) ? intval($_POST['last_update']) : 0;
    $mess = get_transient('vnaicontent_mess');
    $mess_time = get_transient('vnaicontent_mess_time');

    if ($mess && $mess_time && $mess_time > $last_update) {
        echo json_encode(array($mess_time, $mess));
    } else {
        echo json_encode(array($last_update, ''));
    }
    wp_die();
}
add_action('wp_ajax_vnaicontent_check_mess', 'vnaicontent_check_mess');
add_action('wp_ajax_nopriv_vnaicontent_check_mess', 'vnaicontent_check_mess');
