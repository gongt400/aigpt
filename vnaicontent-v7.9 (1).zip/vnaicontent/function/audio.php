<?php

class VnAIContentAudio
{
    private $options;

    public function create_audio($post_id)
    {
        set_time_limit(0);
        $this->options = get_option('vnaicontent_option');

        $permalink = get_permalink($post_id);

        $mess = '<span class="orange-text">Đang tạo audio ' . $this->options['audio_type'] . ' cho bài viết: ' . $permalink . '</span>';
        $this->log_mess($mess, false, true, 0);

        $title = get_post_field('post_title', $post_id);
        $content = get_post_field('post_content', $post_id);
        $text = $title . "\n\n" . $content;

        $url = get_post_meta($post_id, 'url', true);
        if (!empty($url) && isset($this->options['audio_use_prompt']) && !empty($this->options['audio_prompt'])) {
            require_once VNAICONTENT_PATH . 'function/crawler.php';
            $crawler = new VnAIContentCrawler();
            try {
                $content_crawler = $crawler->crawl($url);
                if (!empty($content_crawler)) {
                    $content = $content_crawler;
                }
            } catch (Exception $e) {
                $mess = '<span class="red-text">create_audio: Lỗi khi crawl: ' . $e->getMessage() . '</span>';
                $this->log_mess($mess, true, false, 0);
            }
        }

        if (isset($this->options['audio_use_prompt']) && !empty($this->options['audio_prompt'])) {
            require_once VNAICONTENT_PATH . 'function/create.php';
            $create = new VnAIContentCreatePost();
            $prompt = $this->options['audio_prompt'] . "\n\nBÀI VIẾT CẦN CHUYỂN ĐỔI:\n[" . $this->text_format($content) . "]";
            $text = $create->vnaicontent_type($this->options['type_ai'], $prompt, false, false, false, false, false, false, true);
        }

        if (empty($text)) {
            update_post_meta($post_id, 'audio', 'Error');
            $mess = '<span class="red-text">Không tạo được Audio ' . $this->options['audio_type'] . '! Nội dung không hợp lệ!</span>';
            $this->log_mess($mess, true, true, 0);
            return;
        }

        $text_full = $this->text_format($text);

        if ($this->options['audio_type'] == 'viettel') {
            $text_arr = $this->cut_str($text_full);
            if (!empty($this->options['viettel_api'])) {
                $data_full = $this->viettel($text_arr);
            } else {
                $data_full = $this->viettel_free($text_arr);
            }
        } elseif ($this->options['audio_type'] == 'fpt') {
            $text_arr = $this->cut_str($text_full, 4500);
            $data_full = $this->fpt($text_arr);
        } elseif ($this->options['audio_type'] == 'zalo') {
            $text_arr = $this->cut_str($text_full, 4500);
            $data_full = $this->zalo($text_arr);
        } elseif ($this->options['audio_type'] == 'google') {
            $text_arr = $this->cut_str($text_full, 2200);
            $data_full = $this->google($text_arr);
        } elseif ($this->options['audio_type'] == 'openai') {
            $text_arr = $this->cut_str($text_full, 3800);
            $data_full = $this->openai($text_arr);
        } elseif ($this->options['audio_type'] == 'azure_speech') {
            $text_arr = $this->cut_str($text_full, 4500);
            $data_full = $this->azure_speech($text_arr);
        } elseif ($this->options['audio_type'] == 'vbee') {
            $text_arr = $this->cut_str($text_full, 400);
            $data_full = $this->vbee($text_arr);
        } else {
            $text_arr = $this->cut_str($text_full, 3800);
            $data_full = $this->azure_openai($text_arr);
        }

        if (empty($data_full)) {
            update_post_meta($post_id, 'audio', 'Error');
            $mess = '<span class="red-text">Không tạo được Audio! Kết quả trả về từ ' . $this->options['audio_type'] . ' rỗng!</span>';
            $this->log_mess($mess, true, true, 1);
            return;
        }

        $upload_dir = wp_upload_dir();
        $audio_file = $upload_dir['path'] . '/' . $post_id . '.mp3';
        file_put_contents($audio_file, $data_full);

        $duration = $this->duration($audio_file);

        if ($duration['duration'] < 10) { //10s
            unlink($audio_file);
            update_post_meta($post_id, 'audio', 'Error');
            $mess = '<span class="red-text">Không tạo được Audio ' . $this->options['audio_type'] . '! File audio lỗi nên bị xóa!</span>';
            $this->log_mess($mess, true, true, 1);
            return;
        }

        $audio_url = $upload_dir['url'] . '/' . $post_id . '.mp3';
        $this->add_lib_media($post_id, $audio_file, $audio_url, $title);
        $this->add_schema_feed($post_id, $audio_file, $audio_url, $duration['iso']);
        update_post_meta($post_id, 'audio', $this->options['audio_type']);

        $mess = '<span class="green-text">Tạo audio ' . $this->options['audio_type'] . ' thành công cho bài viết <a target="_blank" href="' . $permalink . '">' . $permalink . '</a></span>';
        $this->log_mess($mess, false, true, 2);
    }

    private function vbee($text_arr)
    {
        $data_full = '';
        foreach ($text_arr as $index => $text) {
            $voice = $this->options['audio_voice_vbee'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_voice_vbee2'];
            }

            $mess = '<span class="orange-text">Đang xử lý audio Vbee phần ' . ($index + 1) . '/' . count($text_arr) . '</span>';
            $this->log_mess($mess, false, true, 0);

            $audio_url = $this->vbee_part($text_voice['text'], $voice);
            if (empty($audio_url)) {
                $mess = '<span class="red-text">Lỗi: Vbee không tạo được audio</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $audio_data = $this->wait_and_get_audio($audio_url);
            if (empty($audio_data)) {
                $mess = '<span class="red-text">Lỗi: Không thể tải file audio ' . $audio_url . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $data_full .= $audio_data;
        }

        return $data_full;
    }

    private function vbee_part($text, $voice)
    {
        $max_wait_time = 120;
        $start_time = current_time('timestamp');

        $data = array(
            'text' => $text,
            'voiceCode' => $voice,
            'speed' => 1
        );

        while (true) {
            $response = wp_remote_post('https://vbee.vn/api/v1/synthesis', array(
                'body'      => wp_json_encode($data),
                'headers'   => array(
                    'authorization'    => 'Bearer ' . $this->set_api_key($this->options['audio_vbee_token'], 'vbee_token_last'),
                    'content-type'     => 'application/json'
                ),
                'timeout'   => 60,
                'sslverify' => false
            ));

            $elapsed_time = current_time('timestamp') - $start_time;
            if ($elapsed_time >= $max_wait_time) {
                $mess = '<span class="red-text">Lỗi: Timeout reached while waiting for the audio link</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Lỗi: ' . $response->get_error_message() . '</span>';
                $this->log_mess($mess, true, false, 0);
                sleep(2);
                continue;
            }

            $result = wp_remote_retrieve_body($response);
            $response_data = json_decode($result, true);

            // Xử lý lỗi từ API - chỉ log lỗi không return  
            if (!empty($response_data['error_message'])) {
                $mess = '<span class="red-text">Lỗi: ' . $response_data['error_message'] . '</span>';
                $this->log_mess($mess, true, false, 0);
                sleep(2);
                continue;
            }

            if (json_last_error() === JSON_ERROR_NONE) {
                $request_id = isset($response_data['result']['request_id']) ? sanitize_text_field($response_data['result']['request_id']) : '';
                if (!empty($request_id)) {
                    $title = isset($response_data['result']['title']) ? sanitize_title($response_data['result']['title']) : '';
                    $slug = str_replace('-', '_', $title);
                    $audio_link = 'https://d2ija040460yo3.cloudfront.net/synthesis/' . date('Y/m/d') . '/' . $slug . '_' . $request_id . '.mp3';
                    return $audio_link;
                }
            }
            sleep(2);
        }
    }

    private function zalo($text_arr)
    {
        $data_full = '';
        foreach ($text_arr as $index => $text) {
            $voice = $this->options['audio_voice_zalo'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_voice_zalo2'];
            }

            $url = 'https://api.zalo.ai/v1/tts/synthesize';

            $body = array(
                'input' => $text_voice['text'],
                'speaker_id' => $voice
            );

            $args = array(
                'headers' => array(
                    'apikey' => $this->options['audio_zalo_api'],
                    'Content-Type' => 'application/x-www-form-urlencoded'
                ),
                'body' => $body,
                'timeout' => 60,
                'sslverify' => false
            );

            $mess = '<span class="orange-text">Đang xử lý audio Zalo phần ' . ($index + 1) . '/' . count($text_arr) . '</span>';
            $this->log_mess($mess, false, true, 0);

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Lỗi: ' . $response->get_error_message() . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $response_body = wp_remote_retrieve_body($response);
            $response_data = json_decode($response_body, true);

            if ($response_data['error_code'] !== 0) {
                $mess = '<span class="red-text">Lỗi: ' . ($response_data['error_message'] ?? 'Không rõ') . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $audio_url = $response_data['data']['url'];

            $audio_data = $this->wait_and_get_audio($audio_url);
            if (empty($audio_data)) {
                $mess = '<span class="red-text">Lỗi: Không thể tải file audio ' . $audio_url . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $data_full .= $audio_data;
        }

        return $data_full;
    }

    private function fpt($text_arr)
    {
        $data_full = '';
        foreach ($text_arr as $index => $text) {
            $voice = $this->options['audio_voice_fpt'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_voice_fpt2'];
            }

            $headers = array(
                'api_key' => $this->set_api_key($this->options['audio_fpt_api']),
                'voice' => $voice,
                'Cache-Control' => 'no-cache',
                'Content-Type' => 'application/json'
            );

            $mess = '<span class="orange-text">FPT Đang xử lý audio phần ' . ($index + 1) . '/' . count($text_arr) . '</span>';
            $this->log_mess($mess, false, true, 0);

            $response = wp_remote_post('https://api.fpt.ai/hmi/tts/v5', array(
                'headers' => $headers,
                'body' => $text_voice['text'],
                'timeout' => 60,
                'sslverify' => false
            ));

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Lỗi: ' . $response->get_error_message() . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $response_body = wp_remote_retrieve_body($response);
            $response_data = json_decode($response_body, true);

            if (!isset($response_data['error']) > 0) {
                $mess = '<span class="red-text">Lỗi: ' . ($response_data['message'] ?? 'Unknown error') . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $audio_url = $response_data['async'];

            $audio_data = $this->wait_and_get_audio($audio_url);
            if (empty($audio_data)) {
                $mess = '<span class="red-text">Lỗi: Không thể tải file audio ' . $audio_url . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $data_full .= $audio_data;
        }

        return $data_full;
    }

    private function wait_and_get_audio($url, $max_attempts = 24)
    {
        $attempt = 0;

        $response = wp_remote_get($url, array(
            'sslverify' => false,
            'timeout' => 30
        ));

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 && !empty(wp_remote_retrieve_body($response))) {
            return wp_remote_retrieve_body($response);
        }

        while ($attempt < $max_attempts) {
            $headers = get_headers($url, 1);

            if (isset($headers['Content-Length']) && intval($headers['Content-Length']) > 0) {

                $response = wp_remote_get($url, array(
                    'sslverify' => false,
                    'timeout' => 30
                ));

                if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 && !empty(wp_remote_retrieve_body($response))) {
                    return wp_remote_retrieve_body($response);
                }
            }

            sleep(5);
            $attempt++;
        }

        $mess = '<span class="red-text">Lỗi: không tải được file audio từ ' . $url . ' sau ' . ($attempt * 5) . ' s</span>';
        $this->log_mess($mess, true, false, 0);
        return '';
    }

    private function azure_openai($text_arr)
    {
        $data_full = '';
        $request_count = 0;
        $start_time = 0;

        foreach ($text_arr as $text) {
            $request_count++;
            if ($request_count === 1) {
                $start_time = microtime(true);
            }

            if ($request_count > 3) {
                $elapsed_time = microtime(true) - $start_time;
                if ($elapsed_time < 70) {
                    $wait_time = 70 - $elapsed_time;
                    sleep($wait_time);
                }
                $request_count = 1;
                $start_time = microtime(true);
            }

            $voice = $this->options['audio_voice_azure_openai'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_voice_azure_openai2'];
            }

            $body = array(
                'model' => 'tts-1',
                'input' => $text_voice['text'],
                'voice' => $voice,
                'response_format' => 'mp3'
            );

            $args = array(
                'body' => wp_json_encode($body),
                'headers' => array(
                    'api-key' => $this->options['audio_azure_openai_key'],
                    'Content-Type' => 'application/json'
                ),
                'timeout' => 60,
                'sslverify' => false
            );

            $response = wp_remote_post($this->options['audio_azure_openai_endpoint'], $args);

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Lỗi: ' . $response->get_error_message() . '</span>';
                $this->log_mess($mess, true, false, 2);
                return '';
            }

            $httpcode = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);

            if ($httpcode != 200) {
                $mess = '<span class="red-text">Lỗi: ' . $body . '</span>';
                $this->log_mess($mess, true, false, 2);
                return '';
            }

            $data_full .= $body;
        }

        return $data_full;
    }


    private function azure_speech($text_arr)
    {
        $data_full = '';
        foreach ($text_arr as $text) {
            $gender = $this->options['azure_speech_gender'];
            $voice = $this->options['audio_voice_azure_speech'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $gender = $this->options['azure_speech_gender2'];
                $voice = $this->options['audio_voice_azure_speech2'];
            }

            $url = 'https://' . $this->options['audio_azure_speech_region'] . '.tts.speech.microsoft.com/cognitiveservices/v1';
            $ssml_data = '<speak version="1.0" xml:lang="' . $this->options['audio_lang_azure_speech'] . '">
                            <voice xml:lang="' . $this->options['audio_lang_azure_speech'] . '" xml:gender="' . $gender . '" name="' . $voice . '">
                                ' . $text_voice['text'] . '
                            </voice>
                          </speak>';

            $headers = array(
                'Ocp-Apim-Subscription-Key' => $this->options['audio_azure_speech_api'],
                'Content-Type'              => 'application/ssml+xml',
                'X-Microsoft-OutputFormat'  => 'audio-16khz-128kbitrate-mono-mp3',
                'User-Agent'                => 'curl'
            );

            $response = wp_remote_post($url, array(
                'headers' => $headers,
                'body'    => $ssml_data,
                'timeout' => 60,
                'sslverify' => false
            ));

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Lỗi: ' . $response->get_error_message() . '</span>';
                $this->log_mess($mess, true, false, 2);
                return '';
            }

            $httpcode = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);

            if ($httpcode != 200) {
                $mess = '<span class="red-text">Lỗi: ' . $body . '</span>';
                $this->log_mess($mess, true, false, 2);
                return '';
            }

            $data_full .= $body;
        }

        return $data_full;
    }

    private function viettel($text_arr)
    {
        $data_full = '';
        foreach ($text_arr as $text) {
            $voice = $this->options['audio_voice_viettel'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_voice_viettel2'];
            }

            $url = 'https://viettelai.vn/tts/speech_synthesis';

            $body = array(
                'text' => $text_voice['text'],
                'voice' => $voice,
                'tts_return_option' => 3,
                'token' => $this->options['viettel_token'],
                'speed' => 1.0,
                'without_filter' => false
            );

            $args = array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'accept' => '*/*'
                ),
                'body' => json_encode($body),
                'timeout' => 60,
                'sslverify' => false
            );

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Lỗi: ' . $response->get_error_message() . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $httpcode = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);

            if ($httpcode != 200) {
                $error = json_decode($response_body, true);
                $mess = '<span class="red-text">Lỗi: ' . (isset($error['vi_message']) ? $error['vi_message'] : print_r($error, true)) . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }

            $data_full .= $response_body;
        }

        return $data_full;
    }

    private function viettel_free($text_arr)
    {
        $data_full = '';
        $headers = [
            'authority: viettelai.vn',
            'accept: text/plain, */*',
            'accept-encoding: gzip, deflate, br',
            'accept-language: en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
            'origin: https://viettelai.vn',
            'referer: https://viettelai.vn/dashboard/service/tts?tab=2',
            'sec-ch-ua: "Not=A?Brand";v="99", "Chromium";v="118"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: empty',
            'sec-fetch-mode: cors',
            'sec-fetch-site: same-origin',
            'Content-Type: application/json',
            'Cookie: WEBSVR=1; XSRF-TOKEN=eyJpdiI6Im5Lc0lVcFErekZ5dHJHOVRaaFVteFE9PSIsInZhbHVlIjoiRGxYVVU1VzBZYVdtWkdkR1BvcGRcL3ZYbjFualZIaWFONlwvXC9kY3pBT013R2RmbkpWZnhxeEQxVG1EZk04UitSSSIsIm1hYyI6ImUxMmFmMmFhYjQxM2JiZDcwNzFhNGVlZjBhZjExNTk3MjQ5YTg5ZDliM2Y1OTdkMmExMjFiMGE4MjNjMTI1ZTIifQ%3D%3D; viettel_ai_session=eyJpdiI6IjhOWE1aaVF5QVlOVkxXejMySU1vdWc9PSIsInZhbHVlIjoibkFPa1paSWh6dkF1VmdwQW9CZ2V6U1V0YkI2c2cxNE0ra2RYd29ERkk2VWxobHQxWWg4dzYwd28xUTRrMllEZiIsIm1hYyI6IjU5NmM2OGZkOGIyMDE1ZWNlYTUxODc2NDA1OWQ0MTZlYjBlOWE4ZmQ0ZDRlN2EyY2I2OGEzNmEwMzA1OTNkZDkifQ%3D%3D'
        ];

        if (!empty($this->options['viettel_proxy'])) {
            $arr_proxy = explode('|', $this->options['viettel_proxy']);
            $num_proxy = count($arr_proxy);
            $num_text = count($text_arr);

            if ($num_text < $num_proxy) {
                $arr_proxy = array_slice($arr_proxy, 0, $num_text);
            } else {
                while (count($arr_proxy) < $num_text) {
                    $arr_proxy[] = $arr_proxy[count($arr_proxy) % $num_proxy];
                }
            }
        }

        foreach ($text_arr as $key => $text) {
            $params = [
                'text' => $text,
                'voice' => $this->options['audio_voice_viettel'],
                'without_filter' => false,
                'speed' => 1.0,
                'tts_return_option' => 3,
            ];

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, 'https://viettelai.vn/tts/speech_synthesis');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            if (!empty($arr_proxy[$key])) {
                $proxy = explode(':', $arr_proxy[$key]);

                if (!empty($proxy[0]) && !empty($proxy[1])) {
                    curl_setopt($ch, CURLOPT_PROXY, $proxy[0]);
                    curl_setopt($ch, CURLOPT_PROXYPORT, $proxy[1]);
                }

                if (!empty($proxy[2]) && !empty($proxy[3])) {
                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy[2] . ':' . $proxy[3]);
                }
            }

            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            if ($response === false) {
                $error_msg = curl_error($ch);
                $mess = '<span class="red-text">Lỗi: ' . $error_msg . '</span>';
                $this->log_mess($mess, true, false, 0);
                curl_close($ch);
                return '';
            }

            curl_close($ch);

            if ($httpcode == 200) {
                $data_full .= $response;
                sleep(1);
            } else {
                $error = json_decode($response, true);
                $mess = '<span class="red-text">Lỗi: ' . (isset($error['vi_message']) ? $error['vi_message'] : 'Không rõ') . '</span>';
                $this->log_mess($mess, true, false, 0);
                return '';
            }
        }

        return $data_full;
    }

    private function google($text_arr)
    {
        $delay = [250, 500, 500, 500, 600, 250];
        $in = array(',', '.', '?', '!', ':', ';');
        $out = array(',<break time="' . $delay[0] . 'ms" />', '.<break time="' . $delay[1] . 'ms" />', '?<break time="' . $delay[2] . 'ms" />', '!<break time="' . $delay[3] . 'ms" />', ':<break time="' . $delay[4] . 'ms" />', ';<break time="' . $delay[5] . 'ms" />');

        $data_full = '';
        foreach ($text_arr as $text) {
            $voice = $this->options['audio_voice_gg'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_voice_gg2'];
            }
            $text = '<speak>' . str_replace($in, $out, $text_voice['text']) . '</speak>';
            $params = [
                'input' => [
                    'ssml' => $text
                ],
                'voice' => [
                    'languageCode' => $this->options['audio_lang_gg'],
                    'name' => $voice
                ],
                'audioConfig' => [
                    'audioEncoding' => 'MP3',
                    'pitch' => 0,
                    'speakingRate' => 1
                ]
            ];

            $data_string = wp_json_encode($params);
            $url = 'https://texttospeech.googleapis.com/v1beta1/text:synthesize?fields=audioContent&key=' . $this->options['audio_gg_api'];

            $response = wp_remote_post($url, [
                'method' => 'POST',
                'body' => $data_string,
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'timeout' => 60,
                'sslverify' => false,
            ]);

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Không tạo được Audio ' . $this->options['audio_type'] . '! (Error: ' . $response->get_error_message() . ')</span>';
                $this->log_mess($mess, true, false, 1);
                return '';
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if ($data !== null) {
                if (isset($data['audioContent']) && $data['audioContent'] != '') {
                    $data_full .= base64_decode($data['audioContent']);
                } elseif (isset($data['error']['message'])) {
                    $mess = '<span class="red-text">' . $data['error']['message'] . '</span>';
                    $this->log_mess($mess, true, false, 1);
                    return '';
                }
            } else {
                $mess = '<span class="red-text">Error decoding JSON</span>';
                $this->log_mess($mess, true, false, 1);
                return '';
            }
        }

        return $data_full;
    }

    private function openai($text_arr)
    {
        $data_full = '';
        foreach ($text_arr as $text) {
            $voice = $this->options['audio_openai_voice'];
            $text_voice = $this->text_voice($text);
            if ($text_voice['voice'] == 'voice2') {
                $voice = $this->options['audio_openai_voice2'];
            }

            $body = array(
                'model' => $this->options['audio_openai_model'],
                'input' => $text_voice['text'],
                'voice' => $voice
            );

            $url = !empty($this->options['audio_openai_endpoint']) ? $this->options['audio_openai_endpoint'] : 'https://api.openai.com/v1/audio/speech';

            $response = wp_remote_post($url, array(
                'body' => json_encode($body),
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $this->options['audio_openai_api']
                ),
                'timeout' => 60,
                'sslverify' => false
            ));

            if (is_wp_error($response)) {
                $mess = '<span class="red-text">Không tạo được Audio ' . $this->options['audio_type'] . '! (Error: ' . $response->get_error_message() . ')</span>';
                $this->log_mess($mess, true, false, 2);
                return '';
            } else {
                $response_body = wp_remote_retrieve_body($response);
                $check = json_decode($response_body, true);
                if (isset($check['error'])) {
                    $mess = '<span class="red-text">Error: ' . (isset($check['error']['message']) ? $check['error']['message'] : print_r($check['error'], true)) . '</span>';
                    $this->log_mess($mess, true, false, 2);
                    return '';
                } else {
                    $data_full .= $response_body;
                }
            }
        }

        return $data_full;
    }

    private function add_lib_media($post_id, $audio_file, $url, $title)
    {
        $attachment = array(
            'guid'           => $url,
            'post_author'    => 1,
            'post_mime_type' => 'audio/mpeg',
            'post_title'     => $title,
            'post_content'   => $title,
            'post_excerpt'   => $title,
            'post_status'    => 'inherit'
        );

        wp_insert_attachment($attachment, $audio_file, $post_id);
    }

    private function add_schema_feed($post_id, $audio_file, $audio_url, $iso)
    {
        if (file_exists($audio_file)) {
            $blog_posting_schema = get_post_meta($post_id, 'rank_math_schema_BlogPosting', true);
            if (empty($blog_posting_schema)) {
                $blog_posting_schema = [
                    'metadata' => [
                        'title' => 'Article',
                        'type' => 'template',
                        'isPrimary' => true
                    ],
                    '@type' => 'BlogPosting',
                    'headline' => '%seo_title%',
                    'description' => '%seo_description%',
                    'keywords' => '%keywords%',
                    'author' => [
                        '@type' => 'Person',
                        'name' => '%name%'
                    ]
                ];
                update_post_meta($post_id, 'rank_math_schema_BlogPosting', $blog_posting_schema);
            }

            $podcast_episode_schema = get_post_meta($post_id, 'rank_math_schema_PodcastEpisode', true);
            if (empty($podcast_episode_schema)) {
                $permalink = get_permalink($post_id);
                $thumbnail = get_the_post_thumbnail_url($post_id) ?: (isset($this->options['podcast_thumb']) ? $this->options['podcast_thumb'] : '');
                $thumbnail_url = !empty($thumbnail) ? $thumbnail : '%podcast_image%';
                $keyword = get_post_meta($post_id, 'keyword', true);
                $keyword_str = !empty($keyword) ? (ucwords($keyword) . ' - ') : '';
                $detail = 'Chi tiết: ';

                $site_lang = get_locale();
                if ($site_lang != 'vi') {
                    $detail = 'Detail: ';
                }

                $description = 'id' . $post_id . ' - ' . $keyword_str . $detail .  '<a target="_blank" href="' . $permalink . '">' . $permalink . '</a>';

                $podcast_episode_schema = [
                    'metadata' => [
                        'type' => 'template',
                        'isPrimary' => false,
                        'title' => 'Podcast Episode'
                    ],
                    '@type' => 'PodcastEpisode',
                    'name' => '%title%',
                    'description' => $description,
                    'author' => [
                        '@type' => 'Person',
                        'name' => '%post_author%'
                    ],
                    'datePublished' => '%date(Y-m-dTH:i:sP)%',
                    'dateModified' => '%modified(Y-m-dTH:i:sP)%',
                    'timeRequired' => $iso,
                    'url' => '%url%',
                    'thumbnailUrl' => $thumbnail_url,
                    'isFamilyFriendly' => true,
                    'associatedMedia' => [
                        '@type' => 'MediaObject',
                        'contentUrl' => $audio_url
                    ],
                    'partOfSeason' => [
                        '@type' => 'PodcastSeason'
                    ]
                ];

                update_post_meta($post_id, 'rank_math_schema_PodcastEpisode', $podcast_episode_schema);
            }
        }
    }

    private function duration($audio_file)
    {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        $time = 0;

        $audio_metadata = wp_read_audio_metadata($audio_file);

        if (!empty($audio_metadata) && !isset($audio_metadata['error']) && isset($audio_metadata['length']) && $audio_metadata['length'] > 0) {
            $time = $audio_metadata['length'];
        }

        if ($time <= 0) {
            return array('iso' => 'PT0S', 'duration' => 0);
        }

        $units = array(
            "Y" => 365 * 24 * 3600,
            "D" =>     24 * 3600,
            "H" =>        3600,
            "M" =>          60,
            "S" =>           1,
        );

        $iso = "P";
        $istime = false;

        foreach ($units as $unitName => &$unit) {
            $quot  = intval($time / $unit);
            $unit  = $quot;
            if ($unit > 0) {
                if (!$istime && in_array($unitName, array("H", "M", "S"))) {
                    $iso .= "T";
                    $istime = true;
                }
                $iso .= strval($unit) . $unitName;
            }
        }
        return array('iso' => $iso, 'duration' => $time);
    }

    private function cut_str($string, $length = 300)
    {
        $result = [];
        if (empty($string)) {
            return [];
        }

        $pattern = '/(\[voice\d+\])(.*?)(?=\[\/voice\d+\])/s';
        preg_match_all($pattern, $string, $matches);

        if (!empty($matches[0])) {
            if (preg_match('/\[voice1\]/', $string) && preg_match('/\[voice2\]/', $string)) {
                $result = $matches[0];
            } else {
                return [];
            }
        } else {
            //viettel free 300, viettel 2000, fpt 4500, google 2200, azure 4500
            $delimiter = '.;?!';
            $words = explode(' ', $string);
            $cur_part = '';

            foreach ($words as $word) {
                $cur_part .= $word . ' ';
                if (strlen($cur_part) >= $length && strpos($delimiter, substr($cur_part, -2, 1)) !== false) {
                    $result[] = trim($cur_part);
                    $cur_part = '';
                }
            }

            if (!empty($cur_part)) {
                $result[] = trim($cur_part);
            }
        }
        return $result;
    }

    private function text_format($content)
    {
        $pattern = '/(\[voice\d+\])(.*?)(?=\[\/voice\d+\])/s';
        preg_match_all($pattern, $content, $matches);
        if (empty($matches[0])) {
            $content = preg_replace('/<img[^>]*>\s*<em>.*?<\/em>/is', '', $content);
            $content = preg_replace('/<em class="cap-ai">.*?<\/em>/is', '', $content);
            $content = wp_strip_all_tags(strip_shortcodes($content));
            $content = preg_replace('/[\x{10000}-\x{10FFFF}]/u', '', $content);
            $lines = preg_split('/(\r\n|\r|\n)/', $content);
            foreach ($lines as &$line) {
                $line = rtrim($line);
                if (substr($line, -1) !== '.' || substr($line, -1) !== '?' || substr($line, -1) !== '!') {
                    $line .= '.';
                }
            }
            return implode(' ', $lines);
        }
        return $content;
    }

    private function text_voice($text)
    {
        $result = array();
        if (strpos($text, "[voice1]") !== false) {
            $result = array('voice' => 'voice1', 'text' => trim(str_replace("[voice1]", "", $text)));
        } elseif (strpos($text, "[voice2]") !== false) {
            $result = array('voice' => 'voice2', 'text' => trim(str_replace("[voice2]", "", $text)));
        } else {
            $result = array('voice' => '', 'text' => $text);
        }

        return $result;
    }

    private function set_api_key($api_key_str, $type_api_last = 'fpt_api_last')
    {
        $api_key_arr = explode('|', $api_key_str);
        if (count($api_key_arr) == 1) {
            $api_key = $api_key_arr[0];
        } else {
            $api_key_last = get_option($type_api_last, '');
            if ($api_key_last == '') {
                $api_key = $api_key_arr[0];
            } else {
                $key = array_search($api_key_last, $api_key_arr);
                if ($key !== false) {
                    $next_key = $key + 1;
                    if ($next_key < count($api_key_arr)) {
                        $api_key = $api_key_arr[$next_key];
                    } else {
                        $api_key = $api_key_arr[0];
                    }
                } else {
                    $api_key = $api_key_arr[0];
                }
            }
            update_option($type_api_last, $api_key);
        }

        return $api_key;
    }

    private function log_mess($mess, $on_log = true, $update_mess = false, $sleep = 0)
    {
        if ($update_mess) {
            set_transient('vnaicontent_mess', $mess, 30 * MINUTE_IN_SECONDS);
            set_transient('vnaicontent_mess_time', time(), 30 * MINUTE_IN_SECONDS);
            if ($sleep > 0) {
                sleep($sleep);
            }
        }

        if (isset($this->options['log']) && $on_log) {
            $log_file = VNAICONTENT_PATH . 'log.txt';
            if (!file_exists($log_file)) {
                touch($log_file);
                chmod($log_file, 0644);
            }
            file_put_contents($log_file, '[' . current_datetime()->format('d-m-Y H:i') . '] ' . wp_strip_all_tags($mess) . "\n", FILE_APPEND | LOCK_EX);
        }
    }
}
