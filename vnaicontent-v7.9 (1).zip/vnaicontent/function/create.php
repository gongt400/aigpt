<?php
class VnAIContentCreatePost
{
    private $options;
    private $unsuitable_keywords = [];
    private $failed_keywords = [];
    private $actived_keywords = [];

    public function __construct()
    {
        $this->options = get_option('vnaicontent_option');
    }

    public function create($type_ai, $post_id = '', $ajax = array())
    {
        set_time_limit(0);
        $in = array(
            'token'   => $this->options['user_key'],
            'lang'    => $this->options['lang'],
            'num_img' => $this->options['num_img']
        );
        $out = $this->vnaicontent_user($in);
        if (!empty($out)) {
            if (isset($out['end_time'])) {
                $current_time = $this->get_current_time();
                update_option('vnaicontent_end_time', $out['end_time']);
                set_transient('vnaicontent_mess_time', $current_time, 30 * MINUTE_IN_SECONDS);

                if (isset($out['run_last'])) {
                    $run_last = date('Y-m-d', strtotime($out['run_last']));
                    $current_date = date('Y-m-d', $current_time);

                    if (isset($out['user_run'])) {
                        set_transient('vnaicontent_user_run', $out['user_run'], 24 * HOUR_IN_SECONDS);
                    }

                    if ($out['end_time'] == 4 && $current_date === $run_last) {
                        if (!empty($ajax)) {
                            $mess = '<span class="red-text">Tạo tiêu đề thất bại! Đã hết ' . $out['free'] . ' lần free của ngày hôm nay</span>';
                            $result = array('error' => $mess);
                            echo json_encode($result);
                            die();
                        }
                        return;
                    }

                    if ($out['end_time'] == 5 && $current_date !== $run_last) {
                        set_transient('vnaicontent_user_run', 0, 24 * HOUR_IN_SECONDS);
                    }
                }
            }

            if (isset($out['free'])) {
                update_option('vnaicontent_free', $out['free']);
            }

            if (isset($out['warning'])) {
                update_option('vnaicontent_warning', $out['warning']);
            }

            if (isset($out['p']) && $out['p'] != '') {
                if ($type_ai != '') {
                    if (!empty($ajax)) {
                        $this->create_post_ajax($type_ai, $out['p'], $out['p_l'], $out['p2'], $out['pi'], $out['pi_ajax'], $ajax);
                    } else {
                        $mess = '<span class="orange-text">Đang đọc danh sách keyword...</span>';
                        $this->log_mess($mess, false, true, 0);
                        $this->create_post($type_ai, $out['p'], $out['p_l'], $out['p2'], $out['pi']);
                    }
                } else {
                    $this->create_cron_img($post_id, $out['pi_ajax']);
                }
            }
        }
    }

    private function create_post($type_ai, $p, $p_l, $p2, $pi = '', $loop_count = 0, $keywords = array(), $rand_cate_id = null)
    {
        $loop_run = $this->options['loop_run'];
        if ($loop_count >= $loop_run) {
            $mess = '<span class="orange-text">Đã chạy ' . $loop_run . ' lần liên tiếp và thất bại, vui lòng đợi phiên cronjob tiếp theo</span>';
            $this->log_mess($mess, false, true, 0);
            $this->write_keyword_batches($rand_cate_id);
            return false;
        }

        if ($loop_count == 0) {
            $cates = get_categories(array('hide_empty' => false));
            $cate_id_arr = array();
            foreach ($cates as $cate) {
                $file_path = VNAICONTENT_DATA . 'keyword_' . $cate->cat_ID . '.txt';
                if (file_exists($file_path)) {
                    $file_content = file_get_contents($file_path);
                    if (trim($file_content) !== '') {
                        $cate_id_arr[] = $cate->cat_ID;
                    }
                }
            }

            if (empty($cate_id_arr)) {
                $mess = '<span class="red-text">Không có keyword. Vui lòng nhập danh sách keyword cho các danh mục (1)</span>';
                $this->log_mess($mess, false, true, 0);
                $this->re_run_move_keyword();
                return false;
            }

            $rand_cate_id = $cate_id_arr[array_rand($cate_id_arr)];
            $keyword_txt = VNAICONTENT_DATA . 'keyword_' . $rand_cate_id . '.txt';
            $keyword_value = file_exists($keyword_txt) ? file_get_contents($keyword_txt) : '';
            $keyword_arr = explode("\n", $keyword_value);
            $keyword_arr = array_filter(array_map('trim', $keyword_arr));
            $keyword_arr = array_unique($keyword_arr);

            if (empty($keyword_arr)) {
                $mess = '<span class="red-text">Không có keyword. Vui lòng nhập danh sách keyword cho danh mục đã chọn (2)</span>';
                $this->log_mess($mess, false, true, 0);
                return false;
            }

            $num_select_keyword = min($loop_run, count($keyword_arr));

            if ($num_select_keyword === 0) {
                $keywords = [];
            } else {
                shuffle($keyword_arr);
                $keywords = array_slice($keyword_arr, 0, $num_select_keyword);
            }
        }

        if (empty($keywords)) {
            $mess = '<span class="red-text">Đã hết keyword. Vui lòng thêm keyword mới.</span>';
            $this->log_mess($mess, false, true, 0);
            $this->write_keyword_batches($rand_cate_id);
            return false;
        }

        $keyword = array_shift($keywords);

        global $wpdb;
        $dup_keyword = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT post_id FROM ' . $wpdb->prefix . 'postmeta WHERE meta_key = %s AND meta_value = %s',
                'keyword',
                $keyword
            )
        );

        if (!empty($dup_keyword)) {
            $this->failed_keywords[] = $keyword;
            $mess = '<span class="red-text">Thất bại! keyword "' . $keyword . '" đã tạo bài viết rồi! Đang chuyển sang keyword tiếp theo...</span>';
            $this->log_mess($mess, false, true, 0);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        $topic_cate = get_term_meta($rand_cate_id, 'topic', true);
        if (!empty($topic_cate)) {
            $prompt_check = 'Là chuyên gia nghiên cứu từ khóa có kiến thức sâu rộng về SEO và ngôn ngữ học. Nhiệm vụ của bạn là xác định xem từ khóa "' . $keyword . '" có phù hợp để sử dụng làm từ khóa chính tạo ra bài viết bằng tiếng ' . $this->options['lang'] . ' về ' . $topic_cate . ' hay không. Trả lời: Y nghĩa là có phù hợp, N nghĩa là KHÔNG phù hợp. Không giải thích gì thêm.';

            $check_keyword = strtolower(trim($this->vnaicontent_type($type_ai, $prompt_check, false, false, true)));

            if (empty($check_keyword)) {
                $mess = '<span class="orange-text">' . $type_ai . ' không kiểm tra được keyword "' . $keyword . '". Bỏ qua kiểm tra, đang tạo bài viết...</span>';
            } elseif ($check_keyword === 'n') {
                $this->unsuitable_keywords[] = $keyword;
                $mess = '<span class="red-text">' . $type_ai . ' đã kiểm tra keyword "' . $keyword . '" và thấy KHÔNG PHÙ HỢP. Đang chuyển sang keyword tiếp theo...</span>';
                $this->log_mess($mess, false, true, 0);
                return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
            } elseif ($check_keyword === 'y') {
                $mess = '<span class="green-text">' . $type_ai . ' đã kiểm tra keyword "' . $keyword . '" và thấy PHÙ HỢP. Đang tạo bài viết...</span>';
            } else {
                $mess = '<span class="orange-text">' . $type_ai . ' không kiểm tra được keyword "' . $keyword . '". Bỏ qua kiểm tra, đang tạo bài viết...</span>';
            }
            $this->log_mess($mess, false, true, 0);
        }

        if ($this->handle_lock($keyword)) {
            $mess = '<span class="orange-text">Từ khóa "' . $keyword . '" đang được xử lý bởi tiến trình khác, vui lòng đợi...</span>';
            $this->log_mess($mess, true, true, 0);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        $ai_as_cate = get_term_meta($rand_cate_id, 'ai_as', true);
        $ai_as = !empty($ai_as_cate) ? $ai_as_cate : $this->options['ai_as'];

        $prompt_cate = get_term_meta($rand_cate_id, 'prompt', true);
        $prompt_cate_select = !empty($prompt_cate) ? $prompt_cate : $this->options['prompt'];

        $list_post_keyword = $this->list_post_keyword($keyword, $rand_cate_id);
        if (!empty($list_post_keyword)) {
            $p_l = str_replace('[links]', $list_post_keyword, $p_l);
        } else {
            $p_l = '';
        }

        $user_prompt = preg_replace('/-*\s*\[internal_links\]/', $p_l, $prompt_cate_select);

        $prompt = $ai_as . str_replace('[keyword]', $keyword, $p) . $user_prompt . (!empty($this->options['img_by']) ? $pi : '') . $p2;

        $content = $this->vnaicontent_type($type_ai, $prompt);

        if (empty($content)) {
            $this->failed_keywords[] = $keyword;
            $mess = '<span class="red-text">Tạo bài viết thất bại! Kết quả trả về từ ' . $type_ai . ' rỗng! Đang chạy lượt tiếp theo...</span>';
            $this->log_mess($mess, false, true, 0);
            $this->handle_lock($keyword, true);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        $check_content_m = $this->check_content_m($content);

        if (empty($check_content_m)) {
            $this->failed_keywords[] = $keyword;
            $this->handle_lock($keyword, true);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        $content_m_img = $this->content_m_img($check_content_m['content'], $this->options['img_by']);

        $imgs_param = $content_m_img['imgs_param'];

        if (isset($this->options['not_img']) && empty($imgs_param)) {
            $this->failed_keywords[] = $keyword;
            $mess = '<span class="red-text">' . $type_ai . ' tạo bài viết thất bại! Bài viết bị loại bỏ do không có ảnh</span>';
            $this->log_mess($mess, false, true, 0);
            $this->handle_lock($keyword, true);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        $post_title = $check_content_m['title'];
        $content_img_tag = $this->content_img_tag($content_m_img['content']);

        $row = array(
            'post_title'     => $post_title,
            'post_name'      => $this->convert_to_slug($keyword),
            'post_content'   => $content_img_tag,
            'post_status'    => isset($this->options['draft']) ? 'draft' : 'publish',
            'post_author'    => isset($this->options['user']) ? $this->options['user'] : 1,
            'post_type'      => 'post',
            'post_category'  => array($rand_cate_id),
            'meta_input'     => array(
                'type_ai' => $type_ai,
                'keyword' => $keyword,
                'rank_math_focus_keyword' => $keyword
            )
        );

        $post_id = wp_insert_post($row);
        if (is_wp_error($post_id)) {
            $this->failed_keywords[] = $keyword;
            $mess = '<span class="red-text">' . $type_ai . ' tạo bài viết thất bại! Lỗi khi insert post: ' . $post_id->get_error_message() . '</span>';
            $this->log_mess($mess, false, true, 0);
            $this->handle_lock($keyword, true);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        $add_lib_media_all = $this->add_lib_media_all($post_id, $imgs_param);
        if (isset($this->options['not_img']) && $add_lib_media_all === false) {
            $this->remove_post_permanently($post_id);
            $this->failed_keywords[] = $keyword;
            $mess = '<span class="red-text">' . $type_ai . ' tạo bài viết thất bại! Bài viết bị loại bỏ do không có ảnh (Lỗi khi thêm ảnh vào thư viện media)</span>';
            $this->log_mess($mess, false, true, 0);
            $this->handle_lock($keyword, true);
            return $this->create_post($type_ai, $p, $p_l, $p2, $pi, $loop_count + 1, $keywords, $rand_cate_id);
        }

        if (!empty($this->options['audio_type'])) {
            require_once VNAICONTENT_PATH . 'function/audio.php';
            $audio = new VnAIContentAudio();
            $audio->create_audio($post_id);
        }

        $this->actived_keywords[] = $keyword;
        $this->write_keyword_batches($rand_cate_id);
        $mess = '<span class="green-text">' . $type_ai . ' tạo bài viết thành công: <a target="_blank" href="' . get_permalink($post_id) . '">' . $post_title . '</a></span>';
        $this->log_mess($mess, false, true, 5);
        $this->handle_lock($keyword, true);

        return true;
    }

    private function re_run_move_keyword()
    {
        $cates = get_categories(array('hide_empty' => false));
        $valid_cates_miss = [];
        $valid_cates_removed = [];
        $re_run = false;
        $num_re_run = get_option('num_re_run', 0);

        if (isset($this->options['re_run_keyword_miss'])) {
            foreach ($cates as $cate) {
                $keyword_miss_txt = VNAICONTENT_DATA . 'keyword_miss_' . $cate->cat_ID . '.txt';
                if (file_exists($keyword_miss_txt)) {
                    $content = file_get_contents($keyword_miss_txt);
                    if (trim($content) !== '') {
                        $valid_cates_miss[] = $cate->cat_ID;
                    }
                }
            }
        }

        if (isset($this->options['re_run_keyword_remove'])) {
            foreach ($cates as $cate) {
                $keyword_post_removed_txt = VNAICONTENT_DATA . 'keyword_post_removed_' . $cate->cat_ID . '.txt';
                if (file_exists($keyword_post_removed_txt)) {
                    $content = file_get_contents($keyword_post_removed_txt);
                    if (trim($content) !== '') {
                        $valid_cates_removed[] = $cate->cat_ID;
                    }
                }
            }
        }

        if (!empty($valid_cates_miss)) {
            foreach ($valid_cates_miss as $id) {
                $keyword_txt                = VNAICONTENT_DATA . 'keyword_' . $id . '.txt';

                $keyword_miss_txt           = VNAICONTENT_DATA . 'keyword_miss_' . $id . '.txt';
                $keyword_miss_value         = file_exists($keyword_miss_txt) ? file_get_contents($keyword_miss_txt) : '';
                $keyword_miss_arr           = explode("\n", $keyword_miss_value);

                $write_file = $this->append_keywords_to_file($keyword_txt, $keyword_miss_arr);
                if ($write_file !== false && file_exists($keyword_miss_txt)) {
                    unlink($keyword_miss_txt);
                    $re_run = true;
                }
            }
        }

        if (!empty($valid_cates_removed)) {
            foreach ($valid_cates_removed as $id) {
                $keyword_txt                = VNAICONTENT_DATA . 'keyword_' . $id . '.txt';

                $keyword_post_removed_txt   = VNAICONTENT_DATA . 'keyword_post_removed_' . $id . '.txt';
                $keyword_post_removed_value = file_exists($keyword_post_removed_txt) ? file_get_contents($keyword_post_removed_txt) : '';
                $keyword_post_removed_arr   = explode("\n", $keyword_post_removed_value);

                $write_file = $this->append_keywords_to_file($keyword_txt, $keyword_post_removed_arr);
                if ($write_file !== false && file_exists($keyword_post_removed_txt)) {
                    unlink($keyword_post_removed_txt);
                    $re_run = true;
                }
            }
        }

        if ($re_run !== false) {
            $num_re_run++;
            update_option('num_re_run', $num_re_run);
            $this->log_mess('<span class="green-text">Hết keyword, đã thực hiện nhập lại keyword thành công. Đang chuẩn bị chạy lại lần thứ ' . $num_re_run . '</span>', true, true, $sleep = 5);
        }
    }

    private function create_post_ajax($type_ai, $p, $p_l, $p2, $pi = '', $pi_ajax = '', $ajax = array())
    {
        if (empty($ajax['keyword'])) {
            $mess = '<span class="red-text">Lỗi ajax!</span>';
            $this->log_mess($mess, true, false, 0);
            $result = array('error' => $mess);
            echo json_encode($result);
            die();
        }

        $ajax_cmd       = $ajax['cmd'];
        $ajax_img_by    = $ajax['img_by'];
        $ajax_keyword   = $ajax['keyword'];
        $ajax_post_id   = $ajax['post_id'];
        $ajax_content   = $ajax['content'];
        $ajax_num_title = $ajax['num_title'];
        $ajax_cat       = $ajax['cat'];

        $keyword_txt        = VNAICONTENT_DATA . 'keyword_' . $ajax_cat . '.txt';
        $keyword_value      = file_exists($keyword_txt) ? file_get_contents($keyword_txt) : '';
        $keyword_arr        = explode("\n", $keyword_value);
        $keyword_miss_txt   = VNAICONTENT_DATA . 'keyword_miss_' . $ajax_cat . '.txt';
        $keyword_active_txt = VNAICONTENT_DATA . 'keyword_active_' . $ajax_cat . '.txt';

        $ai_as_cate = get_term_meta($ajax_cat, 'ai_as', true);
        $ai_as = !empty($ai_as_cate) ? $ai_as_cate : $this->options['ai_as'];

        if ($ajax_cmd == 'create_title') { //create_title
            if (empty($ajax_content) || $ajax_num_title < 1) {
                $mess = '<span class="red-text">Tạo tiêu đề thất bại!</span>';
                $this->log_mess($mess, true, false, 0);
                $result = array('error' => $mess);
                echo json_encode($result);
                die();
            }

            $prompt_title = $ajax_num_title . ' tiêu đề ' . (($ajax_num_title == 1) ? 'duy nhất ' : '');
            $prompt = $ai_as . ". Dựa vào [bài viết] mà tôi cung cấp bên dưới hãy liệt kê " . $prompt_title . "bằng tiếng " . $this->options['lang'] . " ngắn gọn, hấp dẫn nhắm đến từ khóa \"" . $ajax_keyword . "\". Lưu ý: Tiêu đề không được chứa các hashtag, icon, mặt cười, hoặc các ký tự đặc biệt. Hãy bắt đầu trả lời của bạn bằng một danh sách không đánh số thứ tự, không cần giải thích thêm.\n\nDưới đây là nội dung [bài viết]:\n\n" . str_replace("\\", "", sanitize_textarea_field($ajax_content));
            $title = $this->vnaicontent_type($type_ai, $prompt, true);
            $result = array('title' => $title, 'error' => '');
            echo json_encode($result);
            die();
        } else {

            if ($ajax_post_id == '') {
                global $wpdb;
                $dup_keyword = $wpdb->get_row(
                    $wpdb->prepare(
                        'SELECT post_id FROM ' . $wpdb->prefix . 'postmeta WHERE meta_key = %s AND meta_value = %s',
                        'keyword',
                        $ajax_keyword
                    )
                );

                if (!empty($dup_keyword)) {
                    $this->write_txt($ajax_keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                    $mess = '<span class="red-text">Thất bại! keyword này đã có bài viết rồi!</span>';
                    $this->log_mess($mess, true, false, 0);
                    $result = array('error' => $mess);
                    echo json_encode($result);
                    die();
                }
            }

            $ajax_content = str_replace('\\"', '"', $ajax_content);

            $content_remove_imgs = $this->content_remove_imgs($ajax_post_id, $ajax_content);

            if ($ajax_cmd == 'create_img') { //create_img
                if ($ajax_img_by != '') {
                    $prompt = $pi_ajax . $content_remove_imgs;
                    $content = $this->vnaicontent_type($type_ai, $prompt, true);

                    if (empty($content)) {
                        $mess = '<span class="red-text">Tạo ảnh thất bại! AI không chèn được ảnh (1)</span>';
                        $result = array('error' => $mess);
                        echo json_encode($result);
                        die();
                    }

                    $count_word = $this->count_word($content);
                    if (!preg_match('/[.!?;。！？]\s*$/u', trim($content)) || $count_word < 50) {
                        $mess = '<span class="red-text">Tạo ảnh thất bại! AI không chèn được ảnh (2)</span>';
                        $result = array('error' => $mess);
                        echo json_encode($result);
                        die();
                    }

                    $content_m_img = $this->content_m_img($content, $ajax_img_by);

                    $imgs_param = $content_m_img['imgs_param'];

                    if (empty($imgs_param)) {
                        $mess = '<span class="red-text">Tạo ảnh thất bại!</span>';
                        $result = array('error' => $mess);
                        echo json_encode($result);
                        die();
                    }

                    $content_img_tag = $this->content_img_tag($content_m_img['content']);
                    $add_lib_media_all = $this->add_lib_media_all($ajax_post_id, $imgs_param);

                    if ($add_lib_media_all === false) {
                        $mess = '<span class="red-text">Tạo ảnh thất bại! (2)</span>';
                        $result = array('error' => $mess);
                        echo json_encode($result);
                        die();
                    }

                    $result = array('content' => $content_img_tag, 'error' => '');
                    echo json_encode($result);
                    die();
                }
            } else { //create_all, create_content
                $prompt_cate = get_term_meta($ajax_cat, 'prompt', true);
                $prompt_cate_select = !empty($prompt_cate) ? $prompt_cate : $this->options['prompt'];

                $list_post_keyword = $this->list_post_keyword($ajax_keyword, $ajax_cat);
                if (!empty($list_post_keyword)) {
                    $p_l = str_replace('[links]', $list_post_keyword, $p_l);
                } else {
                    $p_l = '';
                }

                $user_prompt = preg_replace('/-*\s*\[internal_links\]/', $p_l, $prompt_cate_select);
                $prompt = $ai_as . str_replace('[keyword]', $ajax_keyword, $p) . $user_prompt . (!empty($ajax_img_by) ? $pi : '') . $p2;
                $content = $this->vnaicontent_type($type_ai, $prompt, true);

                if (empty($content)) {
                    $this->write_txt($ajax_keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                    $mess = '<span class="red-text">Tạo bài viết thất bại! Kết quả trả về từ ' . $type_ai . ' rỗng!</span>';
                    $result = array('error' => $mess);
                    echo json_encode($result);
                    die();
                }

                $check_content_m = $this->check_content_m($content);

                if (empty($check_content_m)) {
                    $this->write_txt($ajax_keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                    $mess = '<span class="red-text">Tạo bài viết thất bại! Nội dung không hợp lệ!</span>';
                    $result = array('error' => $mess);
                    echo json_encode($result);
                    die();
                }

                $content_m_img = $this->content_m_img($check_content_m['content'], $ajax_img_by);
                $content_img_tag = $this->content_img_tag($content_m_img['content']);
                $imgs_param_json = json_encode($content_m_img['imgs_param']);
                set_transient('imgs_param', $imgs_param_json, 2 * HOUR_IN_SECONDS);

                if ($ajax_cmd == 'create_all') { //create_all
                    $result = array('title' => $check_content_m['title'], 'content' => $content_img_tag, 'error' => '');
                } else { //create_content
                    $result = array('content' => $content_img_tag, 'error' => '');
                }
                echo json_encode($result);
                die();
            }
        }
    }

    public function save_post_ajax($ajax = array())
    {
        if (!empty($ajax) && isset($ajax['keyword']) && $ajax['keyword'] != '') {
            $cmd       = $ajax['cmd'];
            $post_id   = $ajax['post_id'];
            $type_ai   = $ajax['type_ai'];
            $img_by    = $ajax['img_by'];
            $keyword   = $ajax['keyword'];
            $slug      = $ajax['slug'];
            $title     = $ajax['title'];
            $content   = $ajax['content'];
            $num_title = $ajax['num_title'];
            $cat       = $ajax['cat'];

            $keyword_txt        = VNAICONTENT_DATA . 'keyword_' . $cat . '.txt';
            $keyword_value      = file_exists($keyword_txt) ? file_get_contents($keyword_txt) : '';
            $keyword_arr        = explode("\n", $keyword_value);
            $keyword_miss_txt   = VNAICONTENT_DATA . 'keyword_miss_' . $cat . '.txt';
            $keyword_active_txt = VNAICONTENT_DATA . 'keyword_active_' . $cat . '.txt';

            if (empty($keyword) || empty($slug) || empty($title) || empty($content)) {
                $this->write_txt($keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                $mess = '<span class="red-text">Thất bại! Lỗi ajax!</span>';
                $this->log_mess($mess);
                $result = array('status' => 'error', 'mess' => $mess);
                echo json_encode($result);
                die();
            }

            if ($this->handle_lock($keyword)) {
                $mess = '<span class="orange-text">Không thể lưu bài viết, từ khóa "' . $keyword . '" đang được xử lý bởi tiến trình khác. Vui lòng đợi 1 lát rồi thực hiện lưu lại</span>';
                $this->log_mess($mess);
                $result = array('status' => 'error', 'mess' => $mess);
                echo json_encode($result);
                die();
            }

            $row = array(
                'post_title'     => $title,
                'post_name'      => $slug,
                'post_content'   => $content,
                'post_status'    => ($cmd == 'save_draft') ? 'draft' : 'publish',
                'post_author'    => isset($this->options['user']) ? $this->options['user'] : 1,
                'post_type'      => 'post',
                'meta_input'     => array(
                    'type_ai' => $type_ai,
                    'keyword' => $keyword,
                    'rank_math_focus_keyword' => $keyword
                )
            );

            if (!empty($cat)) {
                $row['post_category'] = array($cat);
            }

            $imgs_param = array();
            $imgs_param_json = get_transient('imgs_param');
            if ($imgs_param_json !== false) {
                $imgs_param = json_decode($imgs_param_json, true);
            }

            if ($post_id > 0) {
                $row['ID'] = $post_id;

                $update = wp_update_post($row, true);
                if (is_wp_error($update)) {
                    $this->write_txt($keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                    $this->handle_lock($keyword, true);
                    $mess = '<span class="red-text">Lỗi khi update post: ' . get_permalink($post_id) . ' | ' . $update->get_error_message() . '</span>';
                    $this->log_mess($mess);
                    $result = array('status' => 'error', 'mess' => $mess);
                    echo json_encode($result);
                    die();
                }

                if (!empty($imgs_param)) {
                    $add_lib_media_all = $this->add_lib_media_all($post_id, $imgs_param);
                    delete_transient('imgs_param');
                }

                $this->write_txt($keyword, $keyword_txt, $keyword_arr, $keyword_active_txt);
                $this->handle_lock($keyword, true);
                $result = array('status' => 'ok', 'mess' => get_edit_post_link($post_id));
                echo json_encode($result);
                die();
            } else {
                global $wpdb;
                $dup_keyword = $wpdb->get_row(
                    $wpdb->prepare(
                        'SELECT post_id FROM ' . $wpdb->prefix . 'postmeta WHERE meta_key = %s AND meta_value = %s',
                        'keyword',
                        $keyword
                    )
                );

                if (!empty($dup_keyword)) {
                    $this->write_txt($keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                    $this->handle_lock($keyword, true);
                    $mess = '<span class="red-text">Thất bại! keyword này đã có bài viết rồi!</span>';
                    $this->log_mess($mess);
                    $result = array('status' => 'error', 'mess' => $mess);
                    echo json_encode($result);
                    die();
                }

                $post_id = wp_insert_post($row);
                if (is_wp_error($post_id)) {
                    $this->write_txt($keyword, $keyword_txt, $keyword_arr, $keyword_miss_txt);
                    $this->handle_lock($keyword, true);
                    $mess = '<span class="red-text">Lỗi khi insert post: ' . $post_id->get_error_message() . '</span>';
                    $this->log_mess($mess);
                    $result = array('status' => 'error', 'mess' => $mess);
                    echo json_encode($result);
                    die();
                }

                if (!empty($imgs_param)) {
                    $add_lib_media_all = $this->add_lib_media_all($post_id, $imgs_param);
                    delete_transient('imgs_param');
                }

                $this->write_txt($keyword, $keyword_txt, $keyword_arr, $keyword_active_txt);
                $this->handle_lock($keyword, true);
                $result = array('status' => 'ok', 'mess' => get_edit_post_link($post_id));
                echo json_encode($result);
                die();
            }
        }
    }

    public function create_tag($post_id)
    {
        $tags = array();

        $num_tag = $this->options['num_tag'];
        if ($this->options['num_tag'] == 99) {
            $num_tag = 'các';
        }

        $exclude_tag = '';
        if (!empty($this->options['exclude_tag'])) {
            $exclude_tag_array = array_map(function ($tag) {
                return '"' . trim($tag) . '"';
            }, explode(',', strtolower($this->options['exclude_tag'])));

            $exclude_tag = ' và không bao gồm ' . implode(', ', $exclude_tag_array);
        }

        $content = wp_strip_all_tags(get_post_field('post_content', $post_id));
        $prompt = "Hãy phân tích kỹ bài viết sau và trả về duy nhất danh sách " . $num_tag . " tags phù hợp nhất, phân tách bằng dấu phẩy, sắp xếp từ cao xuống thấp. Các tags phải có ít nhất 2 từ" . $exclude_tag . ", và phải được viết bằng chữ thường. Không kèm theo bất kỳ giải thích hay thông tin phụ nào.\n\nFormat trả lời: tag1, tag2, tag3,...\n\nBài viết:\n" . $content;

        $tags_str = $this->vnaicontent_type($this->options['type_ai'], $prompt, false, false, false, false, true);

        if (!empty($tags_str)) {
            $tags_str = strtolower($tags_str);
            $tags = array_map('trim', explode(',', $tags_str));
            $tags = array_filter($tags);
        }

        return $tags;
    }

    public function create_des($post_id)
    {
        $excerpt = '';
        $prompt_ext = '';

        $keyword = get_post_meta($post_id, 'keyword', true);
        if (!empty($keyword)) {
            $prompt_ext = "- KEYWORD: Must naturally include the keyword \"" . $keyword . "\"\n";
        }

        $content = wp_strip_all_tags(get_post_field('post_title', $post_id) . '. ' . get_post_field('post_content', $post_id));

        $prompt = "Create an SEO-optimized meta description for the following article:\n\nREQUIREMENTS:\n- IMPORTANT: The meta description MUST be written in the EXACT SAME LANGUAGE as the article content\n- LENGTH: Strictly 150-160 characters (including spaces)\n- STRUCTURE: Maximum 2 concise sentences\n" . $prompt_ext . "- OPTIMIZE: Must be compelling in search results and maximize CTR\n- CONTENT: Capture the most important main point\n- AVOID: promotional language, marketing terms\n- MUST BE: clear, concise, focused, natural language\n- RETURN: Only the meta description, no explanations\n\nArticle content:\n" . $content;

        $excerpt = $this->vnaicontent_type($this->options['type_ai'], $prompt, false, false, false, false, false, true);

        return $excerpt;
    }

    private function create_cron_img($post_id, $pi_ajax)
    {
        if ($this->options['img_by'] == 'openai' && $this->options['openai_api_key_img'] == '') {
            $this->log_mess('create_cron_img: Không có OpenAI API', true, false, 0);
            return false;
        } elseif ($this->options['img_by'] == 'cloudflare' && $this->options['cf_acc_token'] == '') {
            $this->log_mess('create_cron_img: Không có Cloudflare API token', true, false, 0);
            return false;
        } elseif ($this->options['img_by'] == 'huggingface' && $this->options['huggingface_token'] == '') {
            $this->log_mess('create_cron_img: Không có HuggingFace token', true, false, 0);
            return false;
        } elseif ($this->options['img_by'] == 'google' && $this->options['gg_search_api_img'] == '') {
            $this->log_mess('create_cron_img: Không có google Custom Search API', true, false, 0);
            return false;
        }

        $mess = '<span class="orange-text">Đang tạo ảnh (' . $this->options['img_by'] . ') cho bài viết: '  . get_permalink($post_id) . '</span>';
        $this->log_mess($mess, false, true, 0);

        $keyword = get_post_meta($post_id, 'keyword', true);
        if ($this->handle_lock($keyword)) {
            $mess = '<span class="red-text">Tạo ảnh thất bại, bài viết này đang được xử lý bởi tiến trình khác.</span>';
            $this->log_mess($mess, true, false, 0);
            return false;
        }

        $content = get_post_field('post_content', $post_id);
        $content = str_replace('\\"', '"', $content);
        $content_remove_imgs = $this->content_remove_imgs($post_id, $content);

        $prompt = $pi_ajax . $content_remove_imgs;

        if ($this->options['gemini_api_key'] != '') {
            $type_ai = 'gemini';
        } else {
            if ($this->options['openai_api_key'] != '') {
                $type_ai = 'openai';
            } else {
                if ($this->options['claude_api_key'] != '') {
                    $type_ai = 'claude';
                } else {
                    $mess = '<span class="red-text">create_cron_img: Không có api gemini, openai, claude để thực hiện lệnh tạo ảnh</span>';
                    $this->log_mess($mess, true, true, 0);
                    $this->handle_lock($keyword, true);
                    return false;
                }
            }
        }

        $content = $this->vnaicontent_type($type_ai, $prompt, true);

        if (empty($content)) {
            $mess = '<span class="red-text">create_cron_img: Tạo ảnh thất bại! AI không chèn được ảnh (1)</span>';
            $this->log_mess($mess, false, true, 0);
            update_post_meta($post_id, 'img_by', 'error');
            $this->handle_lock($keyword, true);
            return false;
        }

        $count_word = $this->count_word($content);
        if (!preg_match('/[.!?;。！？]\s*$/u', trim($content)) || $count_word < 50) {
            $mess = '<span class="red-text">create_cron_img: Tạo ảnh thất bại! AI không chèn được ảnh (2)</span>';
            $this->log_mess($mess, false, true, 0);
            update_post_meta($post_id, 'img_by', 'error');
            $this->handle_lock($keyword, true);
            return false;
        }

        $content_m_img = $this->content_m_img($content, $this->options['img_by']);

        $imgs_param = $content_m_img['imgs_param'];

        if (empty($imgs_param)) {
            $mess = '<span class="red-text">create_cron_img: Tạo ảnh thất bại!</span>';
            $this->log_mess($mess, false, true, 0);
            update_post_meta($post_id, 'img_by', 'error');
            $this->handle_lock($keyword, true);
            return false;
        }

        $content_img_tag = $this->content_img_tag($content_m_img['content']);
        $add_lib_media_all = $this->add_lib_media_all($post_id, $imgs_param);

        if ($add_lib_media_all === false) {
            $mess = '<span class="red-text">create_cron_img: Tạo ảnh thất bại! (2)</span>';
            $this->log_mess($mess, false, true, 0);
            update_post_meta($post_id, 'img_by', 'error');
            $this->handle_lock($keyword, true);
            return false;
        }

        $row = array(
            'ID' => $post_id,
            'post_content' => $content_img_tag,
            'meta_input' => array(
                'img_by' => $this->options['img_by']
            )
        );

        $update = wp_update_post($row, true);
        if (is_wp_error($update)) {
            $mess = '<span class="red-text">create_cron_img: Tạo ảnh thất bại! Lỗi khi cập nhập bài viết: ' . $update->get_error_message() . '</span>';
            $this->log_mess($mess, false, true, 0);
            update_post_meta($post_id, 'img_by', 'error');
        }

        $permalink = get_permalink($post_id);
        $mess = '<span class="green-text">Tạo ảnh thành công! <a target="_blank" href="'  . $permalink . '">'  . $permalink . '</a></span>';
        $this->log_mess($mess, false, true, 0);
        $this->handle_lock($keyword, true);
        return true;
    }

    private function content_remove_imgs($post_id, $content)
    {
        if (preg_match_all('/<img[^>]+src="([^">]+)"/i', $content, $matches)) {
            $image_urls = $matches[1];

            foreach ($image_urls as $image_url) {
                $file_path = str_replace(site_url(), ABSPATH, $image_url);
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
        }

        $attachments = get_attached_media('image', $post_id);
        foreach ($attachments as $attachment) {
            $attachment_metadata = wp_get_attachment_metadata($attachment->ID);
            $file_path = get_attached_file($attachment->ID);

            wp_delete_attachment($attachment->ID, true);
            if (file_exists($file_path)) {
                unlink($file_path);
            }

            if (isset($attachment_metadata['sizes'])) {
                foreach ($attachment_metadata['sizes'] as $size_info) {
                    $thumbnail_file = dirname($file_path) . '/' . $size_info['file'];
                    if (file_exists($thumbnail_file)) {
                        unlink($thumbnail_file);
                    }
                }
            }
        }

        $content = preg_replace('/<img[^>]*>\s*<em[^>]*>[^<]*<\/em>/', '', $content);
        $content = preg_replace('/<img[^>]*>/', '', $content);

        return preg_replace('/<[^\/>]*>\s*<\/[^>]*>/', '', $content);
    }

    private function content_m_img($content_m, $img_by)
    {
        $imgs_param = [];
        if (empty($img_by)) {
            return array('content' => $content_m, 'imgs_param' => $imgs_param);
        }

        // [image-n|filename|filetitle|prompt]
        preg_match_all('/\[image-(\d+)\|(.*?)\]/', $content_m, $matches, PREG_SET_ORDER);

        $img_arr = [];
        foreach ($matches as $match) {
            $index = $match[1];
            $str = $match[2];
            $img_parts = explode('|', $str);

            if (count($img_parts) === 3 && !empty($img_parts[0]) && !empty($img_parts[1]) && !empty($img_parts[2])) {
                $img_arr[$index] = $img_parts;
            } else {
                $content_m = preg_replace('/\[image-' . $index . '\|.*?\]/', '', $content_m);
            }
        }

        if (empty($img_arr)) {
            $this->log_mess('Chế độ tạo ảnh đã bật nhưng ' . $img_by . ' ngáo, không thực hiện tạo ảnh', true, true, 0);
            return array('content' => $content_m, 'imgs_param' => $imgs_param);
        }

        $has_img = false;
        foreach ($img_arr as $key => $img) {
            $filename = $img[0];
            $filetitle = $img[1];
            $prompt = $img[2];

            if ($img_by == 'google') {
                $prompt = $filetitle;
            }

            $created_image = $this->create_img($prompt, $img_by, $filename, $filetitle);

            if (!empty($created_image)) {
                $content_m = preg_replace(
                    '/\[image-' . $key . '\|.*?\]/',
                    '![' . $created_image['alt'] . '](' . $created_image['src'] . '){width=' . $created_image['width'] . ' height=' . $created_image['height'] . '}',
                    $content_m
                );
                $imgs_param[] = array('path' => $created_image['path'], 'attachment' => $created_image['attachment']);
                $has_img = true;
            } else {
                $content_m = preg_replace(
                    '/\[image-' . $key . '\|.*?\]/',
                    '',
                    $content_m
                );
            }
        }

        if ($has_img === false) {
            $this->log_mess($img_by . ' tạo ảnh thất bại', true, true, 0);
        }

        return array('content' => $content_m, 'imgs_param' => $imgs_param);
    }

    private function create_img($prompt, $img_by, $filename, $filetitle)
    {
        if ($img_by == '') {
            $img_by = $this->options['img_by'];
        }

        if ($img_by == 'openai') {
            return $this->create_img_openai($prompt, $filename, $filetitle);
        } elseif ($img_by == 'cloudflare') {
            return $this->create_img_cf($prompt, $filename, $filetitle);
        } elseif ($img_by == 'huggingface') {
            return $this->create_img_huggingface($prompt, $filename, $filetitle);
        } else {
            return $this->create_img_gg_search($filename, $filetitle);
        }
    }

    private function create_img_gg_search($filename, $filetitle)
    {
        $img_arr = array();

        $api_key = $this->set_api_key($this->options['gg_search_api_img'], 'gg_search_api_img_last');
        $cx = '805a95738eb6f48fc';
        $domain_img = '';
        $country_img = '';
        $lang_img = '';
        $country_publish_img = '';

        if ($this->options['domain_img'] != '') {
            $domain_img = '&siteSearch=' . trim($this->options['domain_img']) . '&siteSearchFilter=i';
        }
        if ($this->options['gg_search_img_country'] != '') {
            $country_img = '&gl=' . $this->options['gg_search_img_country'];
        }
        if ($this->options['gg_search_img_lang'] != '') {
            $lang_img = '&hl=' . $this->options['gg_search_img_lang'];
        }
        if ($this->options['gg_search_img_country_publish'] != '') {
            $country_publish_img = '&cr=' . $this->options['gg_search_img_country_publish'];
        }

        $param_ext = $domain_img . $country_img . $lang_img . $country_publish_img;


        $url = 'https://customsearch.googleapis.com/customsearch/v1?q=' . urlencode($filetitle) . '&cx=' . urlencode($cx) . '&key=' . $api_key . '&imgType=photo&filter=1' . $param_ext;

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Accept' => 'application/json',
                    'Accept-Encoding' => 'gzip',
                ),
                'timeout' => 90,
                'sslverify' => false
            )
        );

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">create_img_gg_search: Google custom search không phản hồi: ' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, false, 0);
            return $img_arr;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['error'])) {
            $mess = '<span class="red-text">create_img_gg_search: Không tải được ảnh từ Google ' . $data['error']['message'] . ' (code: ' . $data['error']['code'] . ') (Google custom search API key: ' . $api_key . ')</span>';
            $this->log_mess($mess, true, false, 0);
            return $img_arr;
        }

        $imgs = [];
        $check_dup_img = [];
        if (isset($data['items'])) {
            foreach ($data['items'] as $item) {
                if (isset($item['pagemap']['cse_image'][0]['src'])) {
                    $src = $item['pagemap']['cse_image'][0]['src'];
                    if (!in_array($src, $check_dup_img)) {
                        $imgs[] = $src;
                        $check_dup_img[] = $src;
                    }
                }
            }
        }

        if (empty($imgs)) {
            $this->log_mess('create_img_gg_search: Không tìm được ảnh', true, false, 0);
            return $img_arr;
        }

        foreach ($imgs as $src) {
            $img_info = $this->get_img_info($src, true);

            if (empty($img_info['data'])) {
                $this->log_mess('create_img_gg_search: Không có dữ liệu ảnh để lưu.', true, false, 0);
                return $img_arr;
            }

            $w = $img_info[0] ?? 0;
            $h = $img_info[1] ?? 0;

            if ($w < 400 || $h < 200) {
                $this->log_mess('create_img_gg_search: Kích thước ảnh quá nhỏ', true, false, 0);
                return $img_arr;
            }

            $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
            $file_name = $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;
            $upload_dir = wp_upload_dir();
            $path = $upload_dir['path'] . '/' . $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;

            if (file_put_contents($path, $img_info['data']) !== false) {
                $width = (isset($this->options['resize_img']) && $this->options['resize_img'] != 0) ? $this->options['resize_img'] : $w;
                $img_arr = $this->save_img($path, $width, $file_name, $filetitle);
                return $img_arr;
            } else {
                $this->log_mess('create_img_gg_search: Lỗi! Không lưu được file ảnh vào: ' . $path, true, false, 0);
            }
        }

        return $img_arr;
    }

    private function create_img_huggingface($prompt, $filename, $filetitle)
    {
        $img_arr = array();

        $huggingface_token = $this->set_api_key($this->options['huggingface_token'], 'huggingface_token_last');

        $url = 'https://api-inference.huggingface.co/models/' . $this->options['huggingface_model_img'];

        $response = wp_remote_post($url, array(
            'body'      => json_encode(array('inputs' => $prompt)),
            'headers'   => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $huggingface_token
            ),
            'timeout' => 90,
            'sslverify' => false
        ));

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">create_img_huggingface: Huggingface không phản hồi:' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, false, 0);
            return $img_arr;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $response_body = wp_remote_retrieve_body($response);
            $this->log_mess('Response error: ' . $response_body, true, false, 0);
            return $img_arr;
        }

        $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
        $file_name = $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;
        $upload_dir = wp_upload_dir();
        $path = $upload_dir['path'] . '/' . $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;

        $response_body = wp_remote_retrieve_body($response);

        $decoded_body = json_decode($response_body, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded_body['error'])) {
            $this->log_mess('create_img_huggingface: API Error: ' . $decoded_body['error'], true, false, 0);
            unset($response_body);
            return $img_arr;
        }

        $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
        $file_name = $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;
        $upload_dir = wp_upload_dir();
        $path = $upload_dir['path'] . '/' . $file_name;

        if (file_put_contents($path, $response_body) !== false) {
            $image_info = @getimagesize($path);
            if ($image_info === false) {
                $this->log_mess('create_img_huggingface: Không tính được kích thước ảnh.', true, false, 0);
                unlink($path);
                return $img_arr;
            }

            $width = (isset($this->options['resize_img']) && $this->options['resize_img'] != 0) ? $this->options['resize_img'] : $image_info[0];
            $img_arr = $this->save_img($path, $width, $file_name, $filetitle);
        } else {
            $this->log_mess('create_img_huggingface: Lỗi! Không lưu được file ảnh vào: ' . $path, true, false, 0);
        }

        unset($response_body);
        return $img_arr;
    }

    private function create_img_cf($prompt, $filename, $filetitle)
    {
        $img_arr = array();

        $cf_acc_token = $this->set_api_key($this->options['cf_acc_token'], 'cf_acc_token_last');
        $cf_acc_token_arr = explode('@', trim($cf_acc_token));

        $url = 'https://api.cloudflare.com/client/v4/accounts/' . $cf_acc_token_arr[0] . '/ai/run/' . $this->options['cf_model_img'];

        $args = array(
            'body' => json_encode(array('prompt' => $prompt)),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $cf_acc_token_arr[1]
            ),
            'timeout' => 90,
            'sslverify' => false
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">create_img_cf: Cloudflare không phản hồi: ' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, true, 0);
            return $img_arr;
        }

        if (wp_remote_retrieve_response_code($response) !== 200) {
            $this->log_mess('create_img_cf: Response code is not 200', true, false, 0);
            return $img_arr;
        }

        $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
        $file_name = $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;
        $upload_dir = wp_upload_dir();
        $path = $upload_dir['path'] . '/' . $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;

        $tmp = wp_remote_retrieve_body($response);

        if (file_put_contents($path, $tmp) !== false) {
            $image_info = @getimagesize($path);
            if ($image_info === false) {
                $this->log_mess('create_img_cf: Không tính được size ảnh', true, false, 0);
                unset($tmp);
                return $img_arr;
            }
            $width = (isset($this->options['resize_img']) && $this->options['resize_img'] != 0) ? $this->options['resize_img'] : $image_info[0];
            $img_arr = $this->save_img($path, $width, $file_name, $filetitle);
        } else {
            $this->log_mess('create_img_cf: Lỗi! Không lưu được file ảnh vào: ' . $path, true, false, 0);
        }

        unset($tmp);
        return $img_arr;
    }

    private function create_img_openai($prompt, $filename, $filetitle)
    {
        $img_arr = array();

        $api_key = $this->set_api_key($this->options['openai_api_key_img'], 'openai_api_key_img_last');

        $request_body = array(
            'model' => $this->options['openai_model_img'],
            'prompt' => $prompt,
            'n' => 1,
            'response_format' => 'b64_json'
        );

        $url = !empty($this->options['openai_img_endpoint']) ? $this->options['openai_img_endpoint'] : 'https://api.openai.com/v1/images/generations';

        $args = array(
            'body' => json_encode($request_body),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . trim($api_key)
            ),
            'timeout' => 90,
            'sslverify' => false
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">create_img_openai: Cloudflare không phản hồi: ' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, true, 0);
            return $img_arr;
        }

        if (wp_remote_retrieve_response_code($response) !== 200) {
            $this->log_mess('create_img_openai: Response code is not 200', true, false, 0);
            return $img_arr;
        }

        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body, true);

        if (!isset($result['data'][0]['b64_json'])) {
            $this->log_mess('create_img_openai: Tạo ảnh thất bại', true, false, 0);
            return $img_arr;
        }

        $tmp = base64_decode($result['data'][0]['b64_json']);

        $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
        $file_name = $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;
        $upload_dir = wp_upload_dir();
        $path = $upload_dir['path'] . '/' . $filename . '-' . substr(uniqid(), 0, 6) . '.' . $format_img;

        if (file_put_contents($path, $tmp) !== false) {
            $image_info = @getimagesize($path);
            if ($image_info === false) {
                $this->log_mess('create_img_openai: Không tính được size ảnh', true, false, 0);
                unset($tmp);
                return $img_arr;
            }
            $width = (isset($this->options['resize_img']) && $this->options['resize_img'] != 0) ? $this->options['resize_img'] : $image_info[0];
            $img_arr = $this->save_img($path, $width, $file_name, $filetitle);
        } else {
            $this->log_mess('create_img_openai: Lỗi! Không lưu được file ảnh vào: ' . $path, true, false, 0);
        }

        unset($tmp);
        return $img_arr;
    }

    private function save_img($path, $resized_width, $file_name, $filetitle)
    {
        $result = array();

        // Xác định loại ảnh
        $image_type = function_exists('exif_imagetype') ? exif_imagetype($path) : (getimagesize($path)[2] ?? false);
        if ($image_type === IMAGETYPE_JPEG) {
            $image_create_func = 'imagecreatefromjpeg';
        } elseif ($image_type === IMAGETYPE_PNG) {
            $image_create_func = 'imagecreatefrompng';
        } elseif ($image_type === IMAGETYPE_WEBP && function_exists('imagecreatefromwebp')) {
            $image_create_func = 'imagecreatefromwebp';
        } else {
            $image_create_func = null;
        }

        if (!$image_create_func || !function_exists($image_create_func)) {
            $this->log_mess('save_img: Unsupported or invalid image format', true, false, 0);
            return $result;
        }

        $image = $image_create_func($path);

        if (!$image) {
            $this->log_mess('save_img: Failed to create image resource', true, false, 0);
            return $result;
        }

        $original_width = imagesx($image);
        $original_height = imagesy($image);

        if ($original_width <= 0 || $original_height <= 0) {
            $this->log_mess('save_img: Invalid image dimensions', true, false, 0);
            imagedestroy($image);
            return $result;
        }

        $new_height = round(($resized_width / $original_width) * $original_height);

        $resized_image = imagescale($image, $resized_width, $new_height);

        if (!$resized_image) {
            $this->log_mess('save_img: Failed to resize image', true, false, 0);
            imagedestroy($image);
            return $result;
        }

        if ($image_type === IMAGETYPE_JPEG) {
            $save_func = 'imagejpeg';
        } elseif ($image_type === IMAGETYPE_PNG) {
            $save_func = 'imagepng';
        } elseif ($image_type === IMAGETYPE_WEBP) {
            $save_func = 'imagewebp';
        } else {
            $save_func = null;
        }

        if (!$save_func || !function_exists($save_func) || !$save_func($resized_image, $path)) {
            $this->log_mess('save_img: Failed to save resized image', true, false, 0);
            imagedestroy($image);
            imagedestroy($resized_image);
            return $result;
        }

        imagedestroy($image);
        imagedestroy($resized_image);

        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }

        $upload_dir = wp_upload_dir();
        $url = $upload_dir['url'] . '/' . $file_name;
        $filetype = wp_check_filetype($file_name);
        $attachment = array(
            'guid'           => $url,
            'post_mime_type' => $filetype['type'],
            'post_title'     => $filetitle,
            'post_content'   => $filetitle,
            'post_excerpt'   => $filetitle,
            'post_status'    => 'inherit',
            'post_author'    => $this->options['user'] ?? 1,
        );

        return array(
            'src'        => $url,
            'alt'        => $filetitle,
            'path'       => $path,
            'width'      => $resized_width,
            'height'     => $new_height,
            'attachment' => $attachment,
        );
    }

    private function get_img_info($url, $get_data = false)
    {
        $response = wp_remote_get($url, array(
            'timeout' => 90,
            'sslverify' => false,
            'headers' => array(
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            )
        ));

        if (is_wp_error($response)) {
            $this->log_mess('get_img_info: Không kết nối được ảnh nguồn. Error: ' . $response->get_error_message(), true, false, 0);
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $this->log_mess("get_img_info: Không kết nối được ảnh nguồn. Response code: $code", true, false, 0);
            return false;
        }

        $body = wp_remote_retrieve_body($response);

        $info_img = @getimagesize($url);
        if ($info_img === false) {
            $info_img = @getimagesizefromstring($body);
        }

        if ($info_img === false) {
            $this->log_mess('get_img_info: Không thể lấy kích thước ảnh nguồn: ' . $url, true, false, 0);
            return false;
        }

        if ($get_data) {
            $info_img['data'] = $body;
        }

        return $info_img;
    }

    private function add_lib_media_all($post_id, $imgs_param)
    {
        if (empty($imgs_param)) {
            return false;
        }

        $status = false;
        $has_thumb = false;
        foreach ($imgs_param as  $param) {
            $path = $param['path'];
            $attachment = $param['attachment'];
            $alt = $attachment['post_title'];

            $attachment_id = wp_insert_attachment($attachment, $path, $post_id);
            if (!is_wp_error($attachment_id)) {
                if (!has_post_thumbnail($post_id)) {
                    set_post_thumbnail($post_id, $attachment_id);
                    $attach_data = wp_generate_attachment_metadata($attachment_id, $path);
                    $has_thumb = true;
                } else {
                    $attach_data = $this->custom_generate_attachment_metadata($attachment_id, $path);
                }

                wp_update_attachment_metadata($attachment_id, $attach_data);
                update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
                $status = true;
            } else {
                $this->log_mess('add_lib_media_all: Lỗi khi thêm ảnh vào thư viện media: ' . $attachment_id->get_error_message(), true, false, 0);
            }
        }

        if ($status === false) {
            update_post_meta($post_id, 'img_by', 'error');
            $this->log_mess('add_lib_media_all: Bài viết có ảnh nhưng không add được vào thư viện media cho bài viết: ' . get_permalink($post_id), true, false, 0);
            return false;
        }

        if ($has_thumb === false) {
            update_post_meta($post_id, 'img_by', 'error');
            $this->log_mess('add_lib_media_all: Bài viết có ảnh nhưng không tạo được thumbnail', true, false, 0);
            return false;
        }

        update_post_meta($post_id, 'img_by', $this->options['img_by']);

        return true;
    }

    private function content_img_tag($content_m)
    {
        require_once VNAICONTENT_PATH . 'lib/Parsedown.php';
        $parser = new Parsedown();
        $html = $parser->text(trim($content_m));

        $pattern = '/<img([^>]*)>(\{width=(\d+(\.\d+)?)\s+height=(\d+(\.\d+)?)\})?/i';

        $replacement = function ($matches) {
            $att = $matches[1];
            $has_size = !empty($matches[2]);
            $width = $has_size ? round($matches[3], 1) : null;
            $height = $has_size ? round($matches[5], 1) : null;

            if ($has_size) {
                $att .= ' width="' . $width . '" height="' . $height . '"';
            }

            $new_img_tag = '<img' . $att . ' />';

            if (preg_match('/alt="([^"]*)"/', $att, $altMatch)) {
                $altText = trim($altMatch[1]);
                if (!empty($altText)) {
                    $new_img_tag .= '<em class="cap-ai">' . htmlspecialchars($altText) . '</em>';
                }
            }

            return $new_img_tag;
        };

        $result = preg_replace_callback($pattern, $replacement, $html);
        return $result;
    }

    private function custom_generate_attachment_metadata($attachment_id, $file)
    {
        $metadata = array();

        $metadata['file'] = _wp_relative_upload_path($file);

        $image_size = getimagesize($file);
        if ($image_size) {
            $metadata['width'] = $image_size[0];
            $metadata['height'] = $image_size[1];
        }

        $metadata['image_meta'] = wp_read_image_metadata($file);

        return $metadata;
    }

    public function set_api_key($api_key_str, $type_api_key_last = 'gemini_api_key_last')
    {
        $api_key_arr = explode('|', $api_key_str);
        if (count($api_key_arr) == 1) {
            $api_key = $api_key_arr[0];
        } else {
            $api_key_last = get_option($type_api_key_last, '');
            if ($api_key_last == '') {
                $api_key = $api_key_arr[0];
            } else {
                $key = array_search($api_key_last, $api_key_arr);
                if ($key !== false) {
                    $next_key = $key + 1;
                    if ($next_key < count($api_key_arr)) {
                        $api_key = $api_key_arr[$next_key];
                    } else {
                        $api_key = $api_key_arr[0];
                    }
                } else {
                    $api_key = $api_key_arr[0];
                }
            }
            update_option($type_api_key_last, $api_key);
        }

        return $api_key;
    }

    private function list_post_keyword($keyword, $cat)
    {
        $args = array(
            's' => $keyword,
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'cat' => $cat
        );

        $query = new WP_Query($args);
        $post_links = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $meta_keyword = get_post_meta(get_the_ID(), 'keyword', true);
                $rankmath_keyword = get_post_meta(get_the_ID(), 'rank_math_focus_keyword', true);
                $rankmath_keyword = !empty($rankmath_keyword) ? explode(',', $rankmath_keyword)[0] : '';

                if (!empty($meta_keyword)) {
                    $anchor_text = $meta_keyword;
                } elseif (!empty($rankmath_keyword)) {
                    $anchor_text = $rankmath_keyword;
                } else {
                    $anchor_text = get_the_title();
                }
                $post_links[] = '[' . esc_html($anchor_text) . '](' . esc_url(get_permalink()) . ')';
            }
            wp_reset_postdata();
        }
        return !empty($post_links) ? implode(', ', $post_links) : '';
    }

    private function check_content_m($content)
    {
        $result = array();
        $title = '';

        $content = preg_replace('/(\s*(\[[^\]]+\]|\#{1,6}\s+[^\n]+)\s*)+$/', '', $content);

        if (!preg_match('/[.!?;。！？]\s*$/u', trim($content))) {
            $mess = '<span class="red-text">check_content_m: AI đã dừng tạo bài giữa chừng</span>';
            $this->log_mess($mess, true, true, 0);
            return $result;
        }

        preg_match_all('/^# (.+)$/m', $content, $h1matches);
        preg_match_all('/^## (.+)$/m', $content, $h2matches);
        preg_match_all('/^### .+$/m', $content, $h3matches);

        if (count($h1matches[0]) == 1) {
            $title = $h1matches[1][0];
            $h1Pos = strpos($content, $h1matches[0][0]);
        } elseif (count($h2matches[0]) == 1 && count($h3matches[0]) >= 2) {
            $content = preg_replace_callback('/^(#{1,5}) /m', function ($match) {
                return substr($match[1], 0, -1) . ' ';
            }, $content);

            preg_match('/^# (.+)$/m', $content, $newH1Match);
            if (!empty($newH1Match)) {
                $title = $newH1Match[1];
                $h1Pos = strpos($content, $newH1Match[0]);
            }
        } else {
            $mess = '<span class="red-text">check_content_m: Bài viết có cấu trúc không hợp lệ (không có tiêu đề, không có heading)</span>';
            $this->log_mess($mess, true, true, 0);
            return $result;
        }

        if (isset($h1Pos)) {
            $textBeforeH1 = substr($content, 0, $h1Pos);
            if (trim($textBeforeH1) !== '') {
                $content = substr($content, $h1Pos);
            }
            $content = preg_replace('/^# .+$/m', '', $content, 1);
            $content = ltrim($content);
        }

        if (isset($this->options['min_word']) && $this->options['min_word'] > 0) {
            $count_word = $this->count_word($content);
            if ($count_word < $this->options['min_word']) {
                $mess = '<span class="red-text">Tạo bài viết thất bại! Số lượng từ ' . $count_word . ' nhỏ hơn yêu cầu tối thiểu ' . $this->options['min_word'] . ' từ</span>';
                $this->log_mess($mess, true, true, 0);
                return $result;
            }
        }

        $non_space_chars = preg_replace('/\s+/', '', $content);
        if (mb_strlen($non_space_chars) < 1000) {
            $mess = '<span class="red-text">check_content_m: Nội dung bài viết không hợp lệ (quá ngắn)</span>';
            $this->log_mess($mess, true, true, 0);
            return $result;
        }

        if (empty($title)) {
            $mess = '<span class="red-text">check_content_m: Tạo bài viết thất bại! Không có tiêu đề</span>';
            $this->log_mess($mess, true, true, 0);
            return $result;
        }

        return array('title' => $title, 'content' => $content);
    }

    private function convert_to_slug($string)
    {
        if (class_exists('Transliterator')) {
            $transliterator = Transliterator::create('Any-Latin; Latin-ASCII; [\u0100-\u7fff] remove');
            $string = $transliterator->transliterate($string);
        }
        $slug = sanitize_title($string);
        return $slug;
    }

    private function remove_post_permanently($post_id)
    {
        $attachments = get_attached_media('', $post_id);
        foreach ($attachments as $attachment) {
            wp_delete_attachment($attachment->ID, true);
        }
        wp_delete_post($post_id, true);
    }

    private function count_word($content)
    {
        $content = strip_shortcodes($content);
        $content = wp_strip_all_tags($content);
        $content = html_entity_decode($content);
        $content = trim($content);
        return str_word_count($content);
    }

    public function vnaicontent_user($in)
    {
        $data = array();
        $home_arr = parse_url(home_url());
        $domain = $home_arr['host'];

        $url = 'https://vngpt.pro/api-test/';
        //$url = 'https://vngpt.pro/api-v2/';
        if (!empty($in['topic']) && !empty($in['tool'])) {
            $url = 'https://vngpt.pro/api-tool/';
        }

        $response = wp_remote_post($url, array(
            'body' => $in,
            'headers' => array(
                'Referer' => $domain,
            ),
            'timeout' => 90,
            'sslverify' => false
        ));

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">vnaicontent_user: ' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, true, 0);
        } else {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
        }

        return $data;
    }

    public function vnaicontent_type($type_ai, $p, $ajax = false, $filter_keyword = false, $topic = false, $create_prompt = false, $create_tag = false, $create_des = false, $create_text_tts = false)
    {
        if ($type_ai == 'gemini') {
            $api_key_str = $this->options['gemini_api_key'];
        } elseif ($type_ai == 'openai') {
            $api_key_str = $this->options['openai_api_key'];
        } elseif ($type_ai == 'claude') {
            $api_key_str = $this->options['claude_api_key'];
        } else {
            $api_key_str = 'abacus không cần api :D';
        }

        if (empty($api_key_str)) {
            $mess = '<span class="red-text">Không có ' . $type_ai . ' API key</span>';
            $this->log_mess($mess, true, true, 0);
            return false;
        }

        $api_key = $this->set_api_key($api_key_str, $type_ai . '_api_key_last');

        if ($topic) {
            $mess = '<span class="orange-text">' . $type_ai . ' đang kiểm tra keyword ...</span>';
        } else {
            if (!$ajax && !$filter_keyword && !$create_prompt && !$create_tag && !$create_des && !$create_text_tts) {
                $mess = '<span class="orange-text">' . $type_ai . ' đang tạo bài viết ...</span>';
            }
        }

        if (!empty($mess)) {
            $this->log_mess($mess, false, true, 2);
        }

        if ($type_ai == 'gemini') {
            return $this->vnaicontent_gemini($p, $api_key);
        } elseif ($type_ai == 'openai') {
            return $this->vnaicontent_openai($p, $api_key);
        } elseif ($type_ai == 'claude') {
            return $this->vnaicontent_claude($p, $api_key);
        } elseif ($type_ai == 'azure') {
            return $this->vnaicontent_azure($p);
        } elseif ($type_ai == 'abacus') {
            return $this->vnaicontent_abacus($p);
        } else {
            return false;
        }
    }

    public function vnaicontent_azure($p)
    {
        $content = '';
        $body = array(
            'messages' => array(
                array('role' => 'user', 'content' => $p)
            )
        );

        $args = array(
            'body' => wp_json_encode($body),
            'headers' => array(
                'api-key' => $this->options['azure_openai_key'],
                'Content-Type' => 'application/json'
            ),
            'timeout' => 300,
            'sslverify' => false
        );

        $response = wp_remote_post($this->options['azure_openai_text_endpoint'], $args);

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">vnaicontent_azure: ' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, true, 0);
        } else {
            $result = wp_remote_retrieve_body($response);
            $data = json_decode($result, true);

            if (isset($data['choices'][0]['message']['content'])) {
                $content = $data['choices'][0]['message']['content'];
            } else {
                $mess = '<span class="red-text">vnaicontent_azure: ' . $result . '</span>';
                $this->log_mess($mess, true, false, 0);
            }
        }

        return $content;
    }

    public function vnaicontent_abacus($p)
    {
        $data = '';

        $deploymentToken = $this->options['abacus_token'];
        $deploymentId = $this->options['abacus_model'];

        $url = 'https://thienvt.abacus.ai/api/getChatResponse?deploymentToken=' . $deploymentToken . '&deploymentId=' . $deploymentId;

        $body = array(
            'messages' => array(
                array(
                    'is_user' => true,
                    'text' => $p
                )
            ),
            'llmName' => null,
            'numCompletionTokens' => null,
            'systemMessage' => null,
            'temperature' => 0.0,
            'filterKeyValues' => null,
            'searchScoreCutoff' => null,
            'chatConfig' => null
        );

        $args = array(
            'body'        => json_encode($body),
            'headers'     => array(
                'Content-Type' => 'application/json',
            ),
            'data_format' => 'body',
            'timeout' => 300,
            'sslverify' => false
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">vnaicontent_abacus: ' . $response->get_error_message() . '</span>';
            $this->log_mess($mess, true, true, 0);
        } else {
            $result = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($result['error'])) {
                $mess = '<span class="red-text">vnaicontent_abacus: ' . $result['error'] . '</span>';
                $this->log_mess($mess, true, true, 0);
            } else {
                if (!empty($result['result']['messages'][1]['text'])) {
                    $data = $result['result']['messages'][1]['text'];
                }
            }
        }

        return $data;
    }

    public function vnaicontent_claude($p, $api_key)
    {
        $data = '';

        $request_body = array(
            'model' => $this->options['claude_model'],
            'max_tokens' => 4096,
            'messages' => array(
                array('role' => 'user', 'content' => $p)
            )
        );

        $url = !empty($this->options['claude_endpoint']) ? $this->options['claude_endpoint'] : 'https://api.anthropic.com/v1/messages';

        $response = wp_remote_post(
            $url,
            array(
                'body' => json_encode($request_body),
                'headers' => array(
                    'x-api-key' =>  trim($api_key),
                    'anthropic-version' => '2023-06-01',
                    'Content-Type' => 'application/json'
                ),
                'timeout' => 300,
                'sslverify' => false
            )
        );

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">vnaicontent_claude: ' . $response->get_error_message() . ' (api_key: ' . $api_key . ')</span>';
            $this->log_mess($mess, true, false, 0);
        } else {
            $result = json_decode(wp_remote_retrieve_body($response), true);

            if (isset($result['error'])) {
                $error_message = !empty($result['error']['message']) ? $result['error']['message'] : (is_string($result['error']) ? $result['error'] : 'Unknown error');
                $mess = '<span class="red-text">claude: ' . $error_message . ' (api_key: ' . $api_key . ')</span>';
                $this->log_mess($mess, true, false, 0);
            } elseif (isset($result['content'][0]['text'])) {
                $data = $result['content'][0]['text'];
            } else {
                $mess = '<span class="red-text">vnaicontent_claude: Unexpected response format (api_key: ' . $api_key . ')</span>';
                $this->log_mess($mess, true, false, 0);
            }
        }

        return $data;
    }

    public function vnaicontent_openai($p, $api_key)
    {
        $model = $this->options['openai_model'];
        if ($this->options['type_ai'] == 'claude') {
            $model = $this->options['claude_model'];
        }

        $data = '';

        $request_body = array(
            'model' => $model,
            'messages' => array(
                array('role' => 'user', 'content' => $p)
            )
        );

        $url = !empty($this->options['openai_endpoint']) ? $this->options['openai_endpoint'] : 'https://api.openai.com/v1/chat/completions';

        $response = wp_remote_post(
            $url,
            array(
                'body' => json_encode($request_body),
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . trim($api_key),
                ),
                'timeout' => 300,
                'sslverify' => false,
            )
        );

        if (is_wp_error($response)) {
            $mess = '<span class="red-text">vnaicontent_openai: ' . $response->get_error_message() . ' (api_key: ' . $api_key . ')</span>';
            $this->log_mess($mess, true, false, 0);
        } else {
            $result = json_decode(wp_remote_retrieve_body($response), true);

            if (isset($result['error'])) {
                $error_message = !empty($result['error']['message']) ? $result['error']['message'] : (is_string($result['error']) ? $result['error'] : 'Unknown error');
                $mess = '<span class="red-text">vnaicontent_openai: ' . $error_message . ' (api_key: ' . $api_key . ')</span>';
                $this->log_mess($mess, true, false, 0);
            } else {
                if (!empty($result['choices'][0]['message']['content'])) {
                    $data = $result['choices'][0]['message']['content'];
                }
            }
        }
        return $data;
    }

    public function vnaicontent_gemini($p, $api_key)
    {
        $data = '';
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $this->options['gemini_model'] . ':generateContent?key=' . trim($api_key);

        $request_body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array(
                            'text' => $p
                        )
                    )
                )
            ),
            'safetySettings' => array(
                array(
                    'category' => 'HARM_CATEGORY_HATE_SPEECH',
                    'threshold' => 'BLOCK_NONE'
                ),
                array(
                    'category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
                    'threshold' => 'BLOCK_NONE'
                ),
                array(
                    'category' => 'HARM_CATEGORY_DANGEROUS_CONTENT',
                    'threshold' => 'BLOCK_NONE'
                ),
                array(
                    'category' => 'HARM_CATEGORY_HARASSMENT',
                    'threshold' => 'BLOCK_NONE'
                )
            )
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_body));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
        ));
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        if (!empty($this->options['gemini_proxy'])) {
            $proxy = explode(':', $this->options['gemini_proxy']);

            if (!empty($proxy[0]) && !empty($proxy[1])) {
                curl_setopt($ch, CURLOPT_PROXY, $proxy[0]);
                curl_setopt($ch, CURLOPT_PROXYPORT, $proxy[1]);
            }

            if (!empty($proxy[2]) && !empty($proxy[3])) {
                curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy[2] . ':' . $proxy[3]);
            }
        }

        $response = curl_exec($ch);

        if ($response === false) {
            $mess = '<span class="red-text">vnaicontent_gemini: ' . curl_error($ch) . ' (api_key: ' . $api_key . ')</span>';
            $this->log_mess($mess, true, false, 0);
        } else {
            $result = json_decode($response, true);

            if (isset($result['error']['message'])) {
                $this->log_mess('vnaicontent_gemini: ' . $result['error']['message'] . ' (Code: ' . $result['error']['code'] . ') (api_key: ' . $api_key . ')', true, false, 0);
            }

            if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
                $data = $result['candidates'][0]['content']['parts'][0]['text'];
            }
        }

        curl_close($ch);

        return $data;
    }

    private function write_keyword_batches($rand_cate_id)
    {
        if (empty($this->unsuitable_keywords) && empty($this->failed_keywords) && empty($this->actived_keywords)) {
            return;
        }

        $keyword_txt              = VNAICONTENT_DATA . 'keyword_' . $rand_cate_id . '.txt';
        $keyword_active_txt       = VNAICONTENT_DATA . 'keyword_active_' . $rand_cate_id . '.txt';
        $keyword_miss_txt         = VNAICONTENT_DATA . 'keyword_miss_' . $rand_cate_id . '.txt';
        $keyword_not_suitable_txt = VNAICONTENT_DATA . 'keyword_not_suitable_' . $rand_cate_id . '.txt';

        $keywords_to_remove = [];

        if (!empty($this->actived_keywords)) {
            $this->append_keywords_to_file($keyword_active_txt, $this->actived_keywords);
            $keywords_to_remove = array_merge($keywords_to_remove, $this->actived_keywords);
        }

        if (!empty($this->failed_keywords)) {
            $this->append_keywords_to_file($keyword_miss_txt, $this->failed_keywords);
            $keywords_to_remove = array_merge($keywords_to_remove, $this->failed_keywords);
        }

        if (!empty($this->unsuitable_keywords)) {
            $this->append_keywords_to_file($keyword_not_suitable_txt, $this->unsuitable_keywords);
            $keywords_to_remove = array_merge($keywords_to_remove, $this->unsuitable_keywords);
        }

        if (!empty($keywords_to_remove)) {
            $keyword_content = file_get_contents($keyword_txt);
            $keyword_arr = explode("\n", $keyword_content);
            $keyword_arr = array_diff($keyword_arr, $keywords_to_remove);
            file_put_contents($keyword_txt, implode("\n", $keyword_arr));
        }
    }

    private function append_keywords_to_file($file_path, $keywords)
    {
        if (empty($keywords)) {
            return false;
        }

        $fp = fopen($file_path, 'a+');
        if (!$fp) {
            return false;
        }

        $bytes_written = 0;

        if (flock($fp, LOCK_EX)) {
            fseek($fp, -1, SEEK_END);
            $last_char = fgetc($fp);
            if ($last_char !== "\n" && $last_char !== false) {
                $bytes_written += fwrite($fp, "\n");
            }

            foreach ($keywords as $keyword) {
                $bytes_written += fwrite($fp, $keyword . "\n");
            }

            fflush($fp);
            flock($fp, LOCK_UN);
        }

        fclose($fp);

        return $bytes_written > 0;
    }

    private function write_txt($item, $item_txt, $item_arr, $end_txt)
    {
        $item_end_value = file_exists($end_txt) ? file_get_contents($end_txt) : '';
        $item_end_arr   = explode("\n", $item_end_value);

        array_push($item_end_arr, $item);
        $item_end_arr = array_values(array_unique(array_map('trim', $item_end_arr)));
        $item_arr = array_diff($item_arr, $item_end_arr);

        file_put_contents($item_txt, implode("\n", $item_arr));
        file_put_contents($end_txt, implode("\n", $item_end_arr));
    }

    private function handle_lock($keyword, $delete = false)
    {
        if (empty($keyword) || !is_string($keyword)) {
            return false;
        }

        $lock_timeout = 300;
        $lock_name = md5($keyword);
        $locked = get_option($lock_name);

        if ($delete) {
            if ($locked) {
                delete_option($lock_name);
            }
            return false;
        }

        if ($locked && ($this->get_current_time() - $locked) < $lock_timeout) {
            return true;
        }

        update_option($lock_name, $this->get_current_time());
        return false;
    }

    public function get_current_time()
    {
        $cached_time = get_option('vnaicontent_internet_time', false);
        $cache_set_time = get_option('vnaicontent_cache_set_time', false);
        if ($cached_time !== false && $cache_set_time !== false) {
            return $cached_time + (time() - $cache_set_time);
        }
        $response = wp_remote_get(
            'https://worldtimeapi.org/api/timezone/Asia/Ho_Chi_Minh',
            array('sslverify' => false)
        );
        if (is_wp_error($response)) {
            return time();
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($data['unixtime'])) {
            update_option('vnaicontent_internet_time', $data['unixtime'], 'no');
            update_option('vnaicontent_cache_set_time', time(), 'no');
            return $data['unixtime'];
        }
        return time();
    }

    public function log_mess($mess, $on_log = true, $update_mess = false, $sleep = 0)
    {
        if ($update_mess) {
            set_transient('vnaicontent_mess', $mess, 30 * MINUTE_IN_SECONDS);
            set_transient('vnaicontent_mess_time', $this->get_current_time(), 30 * MINUTE_IN_SECONDS);
            if ($sleep > 0) {
                sleep($sleep);
            }
        }

        if (isset($this->options['log']) && $on_log) {
            $log_file = VNAICONTENT_PATH . 'log.txt';
            if (!file_exists($log_file)) {
                touch($log_file);
                chmod($log_file, 0644);
            }
            file_put_contents($log_file, '[' . current_datetime()->format('d-m-Y H:i') . '] ' . wp_strip_all_tags($mess) . "\n", FILE_APPEND | LOCK_EX);
        }
    }
}
