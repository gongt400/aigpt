<?php
function vnaicontent_update_model()
{
    if (isset($_GET['cmd']) && $_GET['cmd'] === 'vnaicontent-update-model') {
        if (!current_user_can('manage_options')) {
            wp_die('Bạn không có quyền thực hiện hành động này.');
        }

        $url = 'https://vngpt.pro/model/';
        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            $message = 'Không thể kết nối đến server để cập nhật model.';
            $type = 'error';
        } else {
            $body = wp_remote_retrieve_body($response);
            update_option('vnaicontent_model', $body);
            $message = 'Cập nhật model thành công.';
            $type = 'success';
        }

        set_transient('vnaicontent_admin_notice', array('message' => $message, 'type' => $type), 30);
        wp_redirect(VNAICONTENT_ADMIN_PAGE);
        exit;
    }
}
add_action('admin_init', 'vnaicontent_update_model');

function vnaicontent_update_model_from_remote()
{
    $url = 'https://vngpt.pro/model/';
    $response = wp_remote_get($url);

    if (!is_wp_error($response)) {
        $body = wp_remote_retrieve_body($response);
        update_option('vnaicontent_model', $body);
        return true;
    }
    return false;
}

function vnaicontent_activation()
{
    vnaicontent_update_model_from_remote();
}
register_activation_hook(__FILE__, 'vnaicontent_activation');

function vnaicontent_upgrade($upgrader_object, $options)
{
    $current_plugin_path_name = plugin_basename(__FILE__);

    if ($options['action'] == 'update' && $options['type'] == 'plugin') {
        foreach ($options['plugins'] as $each_plugin) {
            if ($each_plugin == $current_plugin_path_name) {
                vnaicontent_update_model_from_remote();
            }
        }
    }
}
add_action('upgrader_process_complete', 'vnaicontent_upgrade', 10, 2);

function vnaicontent_install($upgrader_object, $options)
{
    if ($options['action'] == 'install' && $options['type'] == 'plugin') {
        $current_plugin_path_name = plugin_basename(__FILE__);
        $installed_plugin = $upgrader_object->plugin_info();
        if ($installed_plugin == $current_plugin_path_name) {
            vnaicontent_update_model_from_remote();
        }
    }
}
add_action('upgrader_process_complete', 'vnaicontent_install', 10, 2);

//update abacus model
add_action('admin_init', 'vnaicontent_handle_abacus');
function vnaicontent_handle_abacus()
{
    if (isset($_GET['cmd']) && $_GET['cmd'] === 'vnaicontent-update-abacus-model') {
        if (!current_user_can('manage_options')) {
            wp_die('Bạn không có quyền thực hiện hành động này.');
        }

        $options = vnaicontent_get_options();

        $projectId = $options['abacus_project_id'];
        $apiKey = $options['abacus_api'];

        $token = vnaicontent_get_abacus_token($projectId, $apiKey);
        $models = vnaicontent_get_abacus_models($projectId, $apiKey);

        if ($token !== false && $models !== false) {
            $options['abacus_token'] = $token;
            $options['abacus_models_json'] = $models;
            update_option('vnaicontent_option', $options);
            $message = 'Cập nhật dữ liệu abacus thành công.';
            $type = 'success';
        } else {
            $message = 'Cập nhật dữ liệu abacus thất bại.';
            $type = 'error';
        }

        set_transient('vnaicontent_admin_notice', array('message' => $message, 'type' => $type), 30);
        wp_redirect(VNAICONTENT_ADMIN_PAGE);
        exit;
    }
}

function vnaicontent_get_abacus_token($projectId, $apiKey)
{
    $url = "https://api.abacus.ai/api/v0/listDeploymentTokens?projectId=" . $projectId;
    $args = array(
        'headers' => array(
            'apiKey' => $apiKey,
        ),
        'timeout' => 60,
        'sslverify' => false,
    );

    $response = wp_remote_get($url, $args);

    if (!is_wp_error($response)) {
        $result = wp_remote_retrieve_body($response);
        $data = json_decode($result, true);
        return !empty($data['result'][0]['deploymentToken']) ? $data['result'][0]['deploymentToken'] : false;
    }
    return false;
}

function vnaicontent_get_abacus_models($projectId, $apiKey)
{
    $url = 'https://api.abacus.ai/api/v0/listDeployments';
    $args = array(
        'headers' => array(
            'apiKey' => $apiKey,
        ),
        'timeout' => 60,
        'sslverify' => false,
    );

    $url = add_query_arg('projectId', $projectId, $url);
    $response = wp_remote_get($url, $args);

    if (!is_wp_error($response)) {
        $result = wp_remote_retrieve_body($response);
        $data = json_decode($result, true);

        if (!empty($data['result'])) {
            $models = [];
            foreach ($data['result'] as $arr) {
                if (!empty($arr['deploymentId']) && !empty($arr['name']) && !empty($arr['modelId'])) {
                    $models[] = array(
                        'deploymentId' => $arr['deploymentId'],
                        'name' => $arr['name'],
                        //'modelId' => $arr['modelId']
                    );
                }
            }
            return !empty($models) ? json_encode($models) : false;
        }
    }
    return false;
}
