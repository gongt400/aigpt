<?php
add_filter('big_image_size_threshold', 'disable_scaled_images');
function disable_scaled_images($threshold)
{
    return 0;
}

function only_thumbnail_size($sizes)
{
    foreach ($sizes as $size => $details) {
        if ($size !== 'thumbnail') {
            unset($sizes[$size]);
        }
    }
    return $sizes;
}
add_filter('intermediate_image_sizes_advanced', 'only_thumbnail_size');

function remove_all_custom_image_sizes()
{
    global $_wp_additional_image_sizes;

    if (isset($_wp_additional_image_sizes) && count($_wp_additional_image_sizes)) {
        foreach ($_wp_additional_image_sizes as $size => $details) {
            if ($size !== 'thumbnail') {
                remove_image_size($size);
            }
        }
    }
}
add_action('init', 'remove_all_custom_image_sizes');

function remove_image_sizes_theme()
{
    foreach (get_intermediate_image_sizes() as $size) {
        if ($size !== 'thumbnail') {
            remove_image_size($size);
        }
    }
}
add_action('after_setup_theme', 'remove_image_sizes_theme', 11);
