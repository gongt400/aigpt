<?php

add_action('add_meta_boxes', 'vnaicontent_meta_boxes');

function vnaicontent_meta_boxes()
{
    add_meta_box(
        'vnaicontent_box_group_id',
        'VnAIContent',
        'vnaicontent_meta_boxes_callback',
        'post',
        'normal',
        'high',
        array('group' => 'vnaicontent_box_group')
    );
}

function vnaicontent_meta_boxes_callback($post)
{
    echo '<table class="form-table">';
    echo '<tbody>';
    echo '<tr>';
    echo '<th scope="row"><label for="vnaicontent_ai">AI</label></th>';
    echo '<td>';
    meta_box_ai($post);
    echo '</td>';
    echo '</tr>';

    echo '<tr>';
    echo '<th scope="row"><label for="vnaicontent_img_by">Tạo ảnh</label></th>';
    echo '<td>';
    meta_box_img_by($post);
    echo '</td>';
    echo '</tr>';

    echo '<tr>';
    echo '<th scope="row"><label for="vnaicontent_keyword">Từ khóa</label></th>';
    echo '<td>';
    meta_box_keyword($post);
    echo '</td>';
    echo '</tr>';

    echo '<tr>';
    echo '<th scope="row"><label for="vnaicontent_slug">Slug</label></th>';
    echo '<td>';
    meta_box_slug($post);
    echo '</td>';
    echo '</tr>';

    echo '<tr>';
    echo '<th scope="row"><label for="vnaicontent_title">Tiêu đề</label></th>';
    echo '<td>';
    meta_box_title($post);
    echo '</td>';
    echo '</tr>';

    echo '<tr>';
    echo '<th scope="row"><label for="vnaicontent_content">Nội dung</label></th>';
    echo '<td>';
    meta_box_content($post);
    echo '</td>';
    echo '</tr>';
    echo '</tbody>';
    echo '</table>';

    echo '<span id="ctrl-cmd" data-id="' . (isset($_GET["post"]) ? $_GET["post"] : '') . '">';
    global $pagenow;
    if ($pagenow === 'post.php') {
        echo '<button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_all" data-mess="tạo bài viết?">Tạo bài viết</button>
            <button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_title" data-mess="tạo tiêu đề?">Tạo tiêu đề</button>
            <button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_img" data-mess="tạo ảnh? (Chỉ tạo ảnh, nội dung không thay đổi!)">Tạo ảnh</button>
            <button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_content" data-mess="tạo nội dung?">Tạo nội dung</button>';
        echo '<button type="button" id="vnaicontent-save-draft" class="vnaicontent-btn button vnaicontent-save-post" data-cmd="save_draft" data-mess="lưu bản nháp?">Lưu nháp</button><button type="button" id="vnaicontent-save-publish" class="vnaicontent-btn button button-primary vnaicontent-save-post" data-cmd="save_publish" data-mess="xuất bản bài viết?">Xuất bản</button>';
    } else {
        echo '<button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_all" data-mess="tạo bài viết?">Tạo bài viết</button>';
    }
    echo '</span>';

    echo '<div id="vnaicontent-dialog" title="Thông báo!" style="display:none;"><p id="vnaicontent-dialog-content"></p></div>';

    if ($pagenow === 'post-new.php') {
        echo '<div id="select-cat-dialog" title="Chọn từ khóa theo danh mục" style="display:none;">';
        echo '<p id="select-cat-dialog-content">';
        $args_cates = array(
            'show_count' => 0,
            'hide_empty' => 0,
            'hierarchical' => 1,
            'show_option_none' => 'Chọn danh mục',
            'option_none_value' => '',
            'id' => 'ajax-cat-keywords',
        );
        wp_dropdown_categories($args_cates);
        echo '</p>';

        echo '<div id="ajax-list-keyword"></div>';
        echo '</div>';
    }
}

function meta_box_ai($post)
{
    $vnaicontent_option = get_option('vnaicontent_option');
    $type_ai = isset($vnaicontent_option['type_ai']) ? $vnaicontent_option['type_ai'] : 'gemini';
    echo '<select id="vnaicontent_ai" name="vnaicontent_ai">';
    echo '<option value="gemini"' . selected($type_ai, 'gemini', false) . '>Gemini</option>';
    echo '<option value="openai"' . selected($type_ai, 'openai', false) . '>OpenAI</option>';
    echo '<option value="claude"' . selected($type_ai, 'claude', false) . '>Claude</option>';
    echo '<option value="azure"' . selected($type_ai, 'azure', false) . '>Azure OpenAI</option>';
    echo '<option value="abacus"' . selected($type_ai, 'abacus', false) . '>Abacus</option>';
    echo '</select>';
}

function meta_box_img_by($post)
{
    $vnaicontent_option = get_option('vnaicontent_option');
    $img_by = isset($vnaicontent_option['img_by']) ? $vnaicontent_option['img_by'] : '';

    echo '<select id="vnaicontent_img_by" name="vnaicontent_img_by">';
    echo '<option value=""' . selected($img_by, '', false) . '>Tắt</option>';
    echo '<option value="openai"' . selected($img_by, 'openai', false) . '>Dall-E (OpenAI)</option>';
    echo '<option value="cloudflare"' . selected($img_by, 'cloudflare', false) . '>Cloudflare</option>';
    echo '<option value="huggingface"' . selected($img_by, 'huggingface', false) . '>Hugging Face</option>';
    echo '<option value="google"' . selected($img_by, 'google', false) . '>Google Search</option>';
    echo '</select>';
}

function meta_box_keyword($post)
{
    $keyword = get_post_meta($post->ID, 'keyword', true);
    echo '<input class="large-text" type="text" id="vnaicontent_keyword" name="vnaicontent_keyword" value="' . $keyword . '" />';
    global $pagenow;
    if ($pagenow === 'post-new.php') {
        echo '<button type="button" class="vnaicontent-btn button" id="select-cat">Chọn từ danh mục</button>';
    }
}

function meta_box_title($post)
{
    $title = !isset($_GET['post']) ? '' : get_the_title($post->ID);
    echo '<input class="large-text" type="text" id="vnaicontent_title" name="vnaicontent_title" value="' . $title . '" />';
    echo '<div id="list-title"></div>';
}

function meta_box_slug($post)
{
    $slug = get_post_field('post_name', $post->ID);
    echo '<input class="large-text" type="text" id="vnaicontent_slug" name="vnaicontent_slug" value="' . $slug . '" />';
}

function meta_box_content($post)
{
    $content = get_post_field('post_content', $post->ID);
    echo '<div id="vnaicontent_content">' . $content . '</div>';
}

function vnaicontent_meta_boxes_styles()
{
    echo '<style>
        .red-text {
            color: red
        }

        .green-text {
            color: #006400
        }

        .orange-text {
            color: #ff8c00
        }

        #vnaicontent_box_group_id {
            border: 2px solid #ff7f50
        }

        #vnaicontent_box_group_id .form-table th {
            width: 100px
        }

        #vnaicontent_box_group_id .button {
            margin-right: 5px
        }

        #vnaicontent_box_group_id .button:disabled {
            background: #ccc !important
        }

        #vnaicontent-save-draft {
            background: #ff8c00 !important;
            color: #fff !important;
            border-color: #ff8c00 !important
        }

        #vnaicontent_content {
            border: 1px solid #8c8f94;
            border-radius: 4px;
            padding: 10px;
            max-height: 600px;
            min-height: 50px;
            overflow-y: scroll;
            padding: 10px;
            resize: vertical
        }

        #vnaicontent_content h2,
        #vnaicontent_content h3,
        #vnaicontent_content h4 {
            margin: 15px 0 !important;
            padding: 0;
            font-weight: 500
        }

        #vnaicontent_content h2 {
            font-size: 26px
        }

        #vnaicontent_content h3 {
            font-size: 21px
        }

        #vnaicontent_content h4 {
            font-size: 16px
        }

        #vnaicontent_content ul {
            list-style: disc;
            margin-left: 2em
        }

        #vnaicontent_content p {
            margin-bottom: 1.5em
        }

        #vnaicontent_content table {
            border: 1px solid rgba(0, 0, 0, .1);
            border-collapse: separate;
            border-spacing: 0;
            border-width: 1px 0 0 1px;
            margin: 0 0 1.5em;
            width: 100%
        }

        #vnaicontent_content th,
        #vnaicontent_content td {
            padding: 8px;
            border: 1px solid rgba(0, 0, 0, .1);
            border-width: 0 1px 1px 0
        }

        #vnaicontent_content th {
            font-weight: 700
        }

        #vnaicontent_content blockquote {
            border-left: 3px solid #999;
            padding: 5px 10px;
            font-style: italic;
            margin: 0 0 1.5em
        }

        #vnaicontent_box_group_id .slug-focus {
            color: #2271b1 !important
        }

        .spinner {
            float: left !important
        }

        #list-title ul {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 0;
            border-radius: 4px;
            max-height: 200px;
            overflow-y: scroll;
            resize: vertical
        }

        #list-title li {
            line-height: 2em;
            cursor: pointer
        }

        #list-title li:hover,
        #list-title li.title-cur {
            background: #ccc
        }

        .ui-dialog-title {
            color: #ff8c00
        }

        .no-close .ui-dialog-titlebar-close {
            display: none
        }

        .ajax-cat{
            max-height: 250px;
            border: 1px solid #8c8f94;
            border-radius: 4px;
            padding: 10px;
            overflow-y: scroll;
            resize: vertical;
        }

        .ajax-cat ul{
            margin: 0;
        }

        .ajax-cat li {
            line-height: 2em;
            cursor: pointer
        }

        .ajax-cat li:hover,
        .ajax-cat li.keyword-cur {
            background: #ccc
        }

        #vnaicontent_content img{
            margin: 5px auto;
            display: block;
            max-width: 100%;
            height: auto;
        }

        img + em {
            text-align: center;
            display: block;
        }

        #vnaicontent_content::-webkit-scrollbar,
        .ajax-cat::-webkit-scrollbar,
        #list-title ul::-webkit-scrollbar {
            width: 8px
        }

        #vnaicontent_content::-webkit-scrollbar-track,
        .ajax-cat::-webkit-scrollbar-track,
        #list-title ul::-webkit-scrollbar-track {
            background-color: #f1f1f1
        }

        #vnaicontent_content::-webkit-scrollbar-thumb,
        .ajax-cat::-webkit-scrollbar-thumb,
        #list-title ul::-webkit-scrollbar-thumb {
            background-color: #999;
            border-radius: 4px
        }

        #vnaicontent_content::-webkit-scrollbar-thumb:hover,
        .ajax-cat::-webkit-scrollbar-thumb:hover,
        #list-title ul::-webkit-scrollbar-thumb:hover {
            background-color: #777
        }
    </style>';
}
add_action('admin_head', 'vnaicontent_meta_boxes_styles');
