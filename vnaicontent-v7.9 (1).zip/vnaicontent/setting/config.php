<?php
function vnaicontent_script($hook)
{
    if ($hook === 'post.php' || $hook === 'post-new.php' || (isset($_GET['page']) && $_GET['page'] == 'vnaicontent')) {
        if (isset($_GET['tab']) && $_GET['tab'] == 'audio') {
            wp_enqueue_media();
        }

        $css_ver = VNAICONTENT_VERSION . '.' . filemtime(VNAICONTENT_PATH . 'layout/vnaicontent.css');
        wp_enqueue_style('vnaicontent-css', VNAICONTENT_URL . 'layout/vnaicontent.css', array(), $css_ver);

        wp_enqueue_script('jquery-ui-dialog');
        wp_enqueue_style('wp-jquery-ui-dialog');

        $js_ver = VNAICONTENT_VERSION . '.' . filemtime(VNAICONTENT_PATH . 'layout/vnaicontent.js');
        wp_enqueue_script(
            'vnaicontent',
            VNAICONTENT_URL . 'layout/vnaicontent.js',
            array('jquery', 'jquery-ui-dialog'),
            $js_ver,
            true
        );

        wp_localize_script('vnaicontent', 'vnaicontent_obj', array(
            'ajaxurl'  => admin_url('admin-ajax.php'),
            'keywords' => VNAICONTENT_ADMIN_PAGE . '&tab=keywords',
            'config_nonce' => wp_create_nonce('vnaicontent_config_action'),
            'read_log_nonce' => wp_create_nonce('vnaicontent_read_log'),
            'filterkeyword_nonce' => wp_create_nonce('vnaicontent_filterkeyword_action'),
            'createprompt_nonce' => wp_create_nonce('vnaicontent_createprompt_action'),
            'createprompt_savecat_nonce' => wp_create_nonce('vnaicontent_createprompt_savecat_action'),
            'update_model_nonce' => wp_create_nonce('vnaicontent_update_model'),
            'update_abacus_model_nonce' => wp_create_nonce('vnaicontent_handle_abacus'),
            'clear_cache_nonce' => wp_create_nonce('vnaicontent_clear_cache'),
            'current_tab' => isset($_GET['tab']) ? $_GET['tab'] : '',
            'debug_enabled' => (defined('WP_DEBUG') && WP_DEBUG && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG)
        ));
    }
}
add_action('admin_enqueue_scripts', 'vnaicontent_script');

function vnaicontent_get_options()
{
    static $vnaicontent_options = null;
    if ($vnaicontent_options === null) {
        $vnaicontent_options = get_option('vnaicontent_option');
    }
    return $vnaicontent_options;
}

function vnaicontent_player()
{
    if (is_single()) {
        $options = vnaicontent_get_options();

        if ($options['audio_show'] != '') {
            $player = $options['audio_player'];
            $upload_dir = wp_upload_dir();
            $audio_file = $upload_dir['path'] . '/' . get_the_ID() . '.mp3';

            if (file_exists($audio_file)) {
                if ($player == 'plyr') {
                    wp_enqueue_script('plyr-js', VNAICONTENT_URL . 'lib/players/plyr.js', array(), null, false);
                    wp_enqueue_style('plyr-style', VNAICONTENT_URL . 'lib/players/plyr.css');
                    $player_css = "
                        .plyr__controls{border: 1px solid #00b3ff;margin: 15px 0;}
                    ";
                    wp_add_inline_style('plyr-style', $player_css);
                } elseif ($player == 'aplayer') {
                    wp_enqueue_script('aplayer-js', VNAICONTENT_URL . 'lib/players/APlayer.js', array(), null, false);
                    wp_enqueue_style('aplayer-style', VNAICONTENT_URL . 'lib/players/APlayer.css');
                    $player_css = "
                        .vnay-player{margin: 15px 0;}
                    ";
                    wp_add_inline_style('aplayer-style', $player_css);
                }
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'vnaicontent_player');

//admin bar
add_action('admin_bar_menu', 'vnaicontent_admin_bar', 999);
function vnaicontent_admin_bar($wp_admin_bar)
{
    $wp_admin_bar->add_menu(array(
        'id'    => 'vnaicontent',
        'title' => 'VnAIContent',
        'href'  => admin_url('options-general.php?page=vnaicontent')
    ));
}

add_filter('plugin_action_links_vnaicontent/vnaicontent.php', 'settings_vnaicontent');
function settings_vnaicontent($actions)
{
    $mylinks = array(
        '<a href="' . admin_url('options-general.php?page=vnaicontent') . '">Cài đặt</a>',
    );
    return array_merge($actions, $mylinks);
}
