<?php
define('VNAICONTENT_OBJECT_CACHE_TIME', 12 * HOUR_IN_SECONDS);
define('VNAICONTENT_TRANSIENT_CACHE_TIME', 7 * DAY_IN_SECONDS);
define('VNAICONTENT_TAXONOMY_CACHE_TIME', 24 * HOUR_IN_SECONDS);

add_filter('the_content', 'vnaicontent_update_content', 15);
function vnaicontent_update_content($content)
{
    try {
        if (!is_single()) {
            return $content;
        }

        $style = '<style>.vnaicontent-wrapper img{margin: 5px auto;max-width: 100%;display: block;}.vnaicontent-wrapper img + em, .vnaicontent-wrapper img + noscript + em{margin: 8px auto;display: block;text-align: center}';

        $options = vnaicontent_get_options();
        $post_id = get_the_ID();
        //get download link video yt
        if (isset($_GET['get_video']) && $_GET['get_video'] == '1') {
            $youtube_id = get_post_meta($post_id, 'youtube_id', true);

            if ($youtube_id && $youtube_id != 'no') {
                $download_url = vnaicontent_get_youtube_download_link($youtube_id);
                if (!headers_sent() && !empty($download_url)) {
                    wp_redirect($download_url);
                    exit;
                } else {
                    error_log('Headers sent or empty URL, cannot redirect.');
                }
            }
        }

        $modified_content = $content;

        //toc
        if (!empty($options['toc'])) {
            $cached_toc = get_cached_toc($modified_content, $options);

            if ($cached_toc) {
                foreach ($cached_toc['headings_map'] as $original => $new) {
                    $modified_content = str_replace($original, $new, $modified_content);
                }

                $toc = $cached_toc['toc'];
                $toc_position = $options['toc'];

                if ($toc_position == 1) {
                    $modified_content = $toc . $modified_content;
                } elseif ($toc_position == 2) {
                    $first_h2 = strpos($modified_content, '<h2');
                    if ($first_h2 !== false) {
                        $modified_content = substr_replace($modified_content, $toc, $first_h2, 0);
                    }
                } elseif ($toc_position == 3) {
                    $first_p = strpos($modified_content, '</p>');
                    if ($first_p !== false) {
                        $modified_content = substr_replace($modified_content, $toc, $first_p + 4, 0);
                    } else {
                        $modified_content = $toc . $modified_content;
                    }
                }
                $style .= '.vnaicontent-toc{background:#f9f9f9;border:1px solid #ccc;padding:12px 20px;
                margin-bottom:30px;}.vnaicontent-toc p{margin-top:0;margin-bottom:15px;
                font-size:140%}.vnaicontent-toc-list{list-style:none;padding-left:0;
                margin:0}.vnaicontent-toc-list li{margin-bottom:8px}.vnaicontent-toc-list li.lv2{
                font-size:110%}.vnaicontent-toc-list a{color:#333;text-decoration:none}';
            }
        }

        $wrappedContent = '<div id="vnaicontent-wrapper">' . $modified_content . '</div>';

        $dom = new DOMDocument();
        @$dom->loadHTML(
            mb_convert_encoding($wrappedContent, 'HTML-ENTITIES', 'UTF-8'),
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );
        $xpath = new DOMXPath($dom);
        $wrapper = $xpath->query('//div[@id="vnaicontent-wrapper"]')->item(0);
        $keyword = get_post_meta($post_id, 'keyword', true);

        $textNodeXPath = '//text()[not(ancestor::h2) and not(ancestor::h3) and not(ancestor::h4) and 
                not(ancestor::h5) and not(ancestor::h6) and not(ancestor::a) and not(ancestor::em) and 
                not(ancestor::figure) and not(parent::iframe/@title) and not(parent::img/@alt) and 
                not(parent::img/@title)]';

        if ($keyword != '') {
            if (isset($options['link_cur'])) {
                $textNodes = $xpath->query($textNodeXPath, $wrapper);

                foreach ($textNodes as $textNode) {
                    $text = $textNode->nodeValue;
                    $newText = preg_replace('/' . preg_quote($keyword, '/') . '/i', '<a href="' . get_permalink($post_id) . '">' . ucwords($keyword) . '</a>', $text, 1);
                    if ($text !== $newText) {
                        $fragment = $dom->createDocumentFragment();
                        @$fragment->appendXML($newText);
                        $textNode->parentNode->replaceChild($fragment, $textNode);
                        break;
                    }
                }
            }
        }

        if (isset($options['link_brand'])) {
            $brand = get_bloginfo('name');
            $textNodes = $xpath->query($textNodeXPath, $wrapper);

            $lastOccurrence = null;
            foreach ($textNodes as $textNode) {
                if (stripos($textNode->nodeValue, $brand) !== false) {
                    $lastOccurrence = $textNode;
                }
            }

            if ($lastOccurrence) {
                $text = $lastOccurrence->nodeValue;
                // Chỉ thay thế lần xuất hiện cuối cùng của brand name
                $pos = strripos($text, $brand);
                if ($pos !== false) {
                    $newText = substr($text, 0, $pos) .
                        '<a href="' . home_url() . '">' . $brand . '</a>' .
                        substr($text, $pos + strlen($brand));
                    $fragment = $dom->createDocumentFragment();
                    @$fragment->appendXML($newText);
                    $lastOccurrence->parentNode->replaceChild($fragment, $lastOccurrence);
                }
            }
        }

        //related post
        $num_relatedposts = isset($options['num_relatedposts']) ? $options['num_relatedposts'] : 0;
        if ($num_relatedposts > 0) {
            $optimal_links = $num_relatedposts;
            if ($num_relatedposts == 99) {
                $char_count = get_cached_char_count($post_id, $content);
                $optimal_links = get_optimal_links($char_count);

                if ($optimal_links > 0) {
                    $related_posts = get_cached_related_posts($post_id, $optimal_links, $options);

                    if (!empty($related_posts)) {
                        $links = array();
                        foreach ($related_posts as $post) {
                            $links[] = '<a ' . (isset($options['open_tab']) ? 'target="_blank"' : '') .
                                ' href="' . esc_url($post['permalink']) . '">' .
                                esc_html($post['title']) . '</a>';
                        }

                        $optimal_links = min($optimal_links, count($links));

                        $elements = $xpath->query('
                            //p[not(ancestor::blockquote) and not(ancestor::div[contains(@class, "related-link")]) and not(ancestor::div[contains(@class, "vnaicontent-toc")])] |
                            //ul[not(ancestor::blockquote) and not(ancestor::div[contains(@class, "related-link")]) and not(ancestor::div[contains(@class, "vnaicontent-toc")])] |
                            //ol[not(ancestor::blockquote) and not(ancestor::div[contains(@class, "related-link")]) and not(ancestor::div[contains(@class, "vnaicontent-toc")])] |
                            //table[not(ancestor::blockquote) and not(ancestor::div[contains(@class, "related-link")]) and not(ancestor::div[contains(@class, "vnaicontent-toc")])] |
                            //div[not(contains(@class, "related-link")) and not(contains(@class, "vnaicontent-toc")) and not(ancestor::blockquote)] |
                            //figure[not(ancestor::blockquote) and not(ancestor::div[contains(@class, "related-link")]) and not(ancestor::div[contains(@class, "vnaicontent-toc")])] |
                            //iframe[not(ancestor::blockquote) and not(ancestor::div[contains(@class, "related-link")]) and not(ancestor::div[contains(@class, "vnaicontent-toc")])]
                        ', $wrapper);

                        $validPositions = [];

                        foreach ($elements as $element) {
                            $isLastElement = true;
                            $nextNode = $element->nextSibling;
                            while ($nextNode) {
                                if ($nextNode->nodeType === XML_ELEMENT_NODE) {
                                    $isLastElement = false;
                                    break;
                                }
                                $nextNode = $nextNode->nextSibling;
                            }

                            if (!$isLastElement) {
                                $isValid = true;
                                $parent = $element->parentNode;

                                while ($parent && $parent !== $wrapper) {
                                    $parentClass = ($parent instanceof DOMElement) ? $parent->getAttribute('class') : '';
                                    if (
                                        $parent->nodeName === 'blockquote' ||
                                        $parent->nodeName === 'li' ||
                                        strpos($parentClass, 'related-link') !== false
                                    ) {
                                        $isValid = false;
                                        break;
                                    }
                                    $parent = $parent->parentNode;
                                }

                                if ($isValid) {
                                    $elementText = trim($element->textContent);
                                    if (!empty($elementText) && substr($elementText, -1) !== ':') {
                                        $validPositions[] = $element;
                                    }
                                }
                            }
                        }

                        $positionsCount = count($validPositions);
                        if ($positionsCount > 0) {
                            $minSpacing = max(3, floor($positionsCount / ($optimal_links + 1)));
                            $startPosition = min($minSpacing, floor($positionsCount * 0.2));
                            $currentPosition = $startPosition;
                            $positionsToInsert = [];

                            for ($i = 0; $i < $optimal_links && $currentPosition < $positionsCount - 1; $i++) {
                                if (isset($validPositions[$currentPosition])) {
                                    $positionsToInsert[] = $validPositions[$currentPosition];
                                    $currentPosition += $minSpacing;
                                }
                            }

                            foreach ($positionsToInsert as $index => $element) {
                                if (isset($links[$index])) {
                                    $fragment = $dom->createDocumentFragment();
                                    $relatedLinkHtml = '<div class="related-link">' .
                                        esc_html($options['text_more']) . ' ' .
                                        $links[$index] . '</div>';
                                    @$fragment->appendXML($relatedLinkHtml);
                                    $element->parentNode->insertBefore($fragment, $element->nextSibling);
                                }
                            }

                            $style .= '.related-link{
                                border-left: 4px solid #34495E; 
                                background-color: #eaeaea; 
                                padding: 15px 0 15px 15px; 
                                margin: 25px 0;
                            }';
                        }
                    }
                }
            }
        }

        if ($wrapper) {
            $modified_content = '';
            $children = $wrapper->childNodes;
            foreach ($children as $child) {
                $modified_content .= $dom->saveHTML($child);
            }
        }

        //audio
        $show_audio = $options['audio_show'];
        if ($show_audio != '') {
            $audio_content = get_cached_audio_content($post_id, $options);

            if (!empty($audio_content)) {
                if ($show_audio == 1) {
                    $modified_content = $audio_content . $modified_content;
                } elseif ($show_audio == 2) {
                    $position_audio = strpos($modified_content, '<h2');
                    if ($position_audio !== false) {
                        $modified_content = substr_replace($modified_content, $audio_content, $position_audio, 0);
                    }
                } elseif ($show_audio == 3) {
                    $modified_content = $modified_content . $audio_content;
                }
            }
        }

        //yt
        $show_yt = $options['yt_show'];
        if ($show_yt != '') {
            $youtube_id = get_post_meta($post_id, 'youtube_id', true);
            $youtube_content = get_cached_youtube_content($post_id, $youtube_id);

            if (!empty($youtube_content)) {
                $style .= '.responsive-video {position: relative;width: 100%;padding-bottom: 56.25%;height: 0;overflow: hidden; margin-bottom: 30px}.responsive-video iframe {position: absolute;top: 0;left: 0;width: 100%;height: 100%;}';

                if ($show_yt == 1) {
                    $modified_content = $youtube_content . $modified_content;
                } elseif ($show_yt == 2) {
                    $position = strpos($modified_content, '<h2');
                    if ($position !== false) {
                        $modified_content = substr_replace($modified_content, $youtube_content, $position, 0);
                    }
                } elseif ($show_yt == 3) {
                    $modified_content = $modified_content . $youtube_content;
                }
            }
        }

        $style .= '</style>';
        return $style . '<div class="vnaicontent-wrapper">' . $modified_content . '</div>';
    } catch (Exception $e) {
        error_log('error: ' . $e->getMessage());
        return $content;
    }
}

function vnaicontent_get_youtube_download_link($youtube_id)
{
    if (empty($youtube_id)) {
        error_log('Error: youtube_id is empty');
        return '';
    }

    $cache_key = 'yt_download_' . md5($youtube_id);

    $cached_url = get_transient($cache_key);
    if ($cached_url !== false) {
        if ($cached_url === '') {
            delete_transient($cache_key);
        } else {
            return $cached_url;
        }
    } else {
        error_log('No transient found for cache key: ' . $cache_key);
    }

    $ytdlp_path = VNAICONTENT_PATH . 'lib/yt-dlp_linux';

    if (!file_exists($ytdlp_path)) {
        error_log('yt-dlp file does not exist, attempting to download...');

        $yt_dlp_url = 'https://github.com/yt-dlp/yt-dlp/releases/download/2024.12.06/yt-dlp_linux';
        $download_result = file_put_contents($ytdlp_path, fopen($yt_dlp_url, 'r'));

        if ($download_result === false) {
            error_log('Error: Failed to download yt-dlp from ' . $yt_dlp_url);
            return '';
        }

        chmod($ytdlp_path, 0755);
        error_log('yt-dlp downloaded successfully and set executable permissions.');
    }

    if (!is_executable($ytdlp_path)) {
        error_log('Error: Cannot set executable permissions for ' . $ytdlp_path);
        return '';
    }

    $command = escapeshellcmd($ytdlp_path) . ' -g --format mp4 ' . escapeshellarg('https://www.youtube.com/watch?v=' . $youtube_id) . ' 2>&1';

    $download_url = shell_exec($command);
    $download_url = trim($download_url);

    if (empty($download_url)) {
        error_log('Error: yt-dlp command failed.');
        return '';
    }
    set_transient($cache_key, $download_url, 6 * HOUR_IN_SECONDS);

    return $download_url;
}

function get_optimal_links($char_count)
{
    if ($char_count < 2000) return 2;
    if ($char_count < 3000) return 3;
    if ($char_count < 4500) return 4;
    if ($char_count < 6000) return 5;
    if ($char_count < 7500) return 6;
    if ($char_count < 9000) return 7;
    if ($char_count < 12000) return 8;
    return 10;
}

function create_clean_anchor($string)
{
    $string = html_entity_decode($string, ENT_QUOTES, 'UTF-8');
    if (class_exists('Transliterator')) {
        try {
            $transliterator = Transliterator::create('Any-Latin; Latin-ASCII; [\u0100-\u7fff] remove');
            if ($transliterator !== null) {
                $string = $transliterator->transliterate($string);
            }
        } catch (Exception $e) {
            // Silent fail - fallback to sanitize_title
        }
    }

    return sanitize_title($string);
}

function get_cached_char_count($post_id, $content)
{
    $cache_key = 'post_char_count_' . $post_id;

    $char_count = wp_cache_get($cache_key);

    if (false === $char_count) {
        $char_count = get_transient($cache_key);

        if (false === $char_count) {
            $text_content = strip_tags($content);
            $text_content = html_entity_decode($text_content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $text_content = preg_replace('/\s+/', ' ', $text_content);
            $text_content = trim($text_content);
            $char_count = mb_strlen($text_content);

            set_transient($cache_key, $char_count, VNAICONTENT_TRANSIENT_CACHE_TIME);
            wp_cache_set($cache_key, $char_count, '', VNAICONTENT_OBJECT_CACHE_TIME);
        } else {
            wp_cache_set($cache_key, $char_count, '', VNAICONTENT_OBJECT_CACHE_TIME);
        }
    }

    return $char_count;
}

function get_cached_related_posts($post_id, $optimal_links, $options)
{
    try {
        $cache_key = 'related_posts_' . $post_id . '_' . $optimal_links;

        $cached_data = get_transient($cache_key);
        if (false !== $cached_data) {
            return $cached_data;
        }

        $cached_data = wp_cache_get($cache_key);
        if (false !== $cached_data) {
            return $cached_data;
        }

        // Cache category query
        $cat_key = 'post_categories_' . $post_id;
        $categories = wp_cache_get($cat_key);
        if (false === $categories) {
            $categories = get_the_category($post_id);
            wp_cache_set($cat_key, $categories, '', VNAICONTENT_TAXONOMY_CACHE_TIME);
        }

        // Cache tag query
        $tag_key = 'post_tags_' . $post_id;
        $post_tags = wp_cache_get($tag_key);
        if (false === $post_tags) {
            $post_tags = wp_get_post_tags($post_id);
            wp_cache_set($tag_key, $post_tags, '', VNAICONTENT_TAXONOMY_CACHE_TIME);
        }

        $args = array(
            'post__not_in' => array($post_id),
            'posts_per_page' => $optimal_links * 3,
            'orderby' => 'date',
            'order' => 'DESC',
            'post_status' => 'publish'
        );

        switch ($options['cat_tag']) {
            case 'cat':
                if (!empty($categories)) {
                    $args['category__in'] = array($categories[0]->term_id);
                }
                break;

            case 'tag':
                if (!empty($post_tags)) {
                    $tag_ids = array();
                    foreach ($post_tags as $tag) {
                        $tag_ids[] = $tag->term_id;
                    }
                    $args['tag__in'] = $tag_ids;
                }
                break;

            case 'all':
                if (!empty($post_tags)) {
                    $tag_ids = array();
                    foreach ($post_tags as $tag) {
                        $tag_ids[] = $tag->term_id;
                    }
                    $args['tag__in'] = $tag_ids;

                    $query_key = 'related_query_' . $post_id . '_tag';
                    $related_posts = wp_cache_get($query_key);

                    if (false === $related_posts) {
                        $related_posts = new WP_Query($args);
                        wp_cache_set($query_key, $related_posts, '', VNAICONTENT_TAXONOMY_CACHE_TIME);
                    }

                    if (!$related_posts->have_posts()) {
                        unset($args['tag__in']);
                        if (!empty($categories)) {
                            $args['category__in'] = array($categories[0]->term_id);
                        }
                    }
                } else {
                    if (!empty($categories)) {
                        $args['category__in'] = array($categories[0]->term_id);
                    }
                }
                break;
        }

        $related_posts = new WP_Query($args);

        // Nếu không đủ posts, query thêm từ toàn bộ
        if (!$related_posts->have_posts() || $related_posts->post_count < $optimal_links) {
            $args = array(
                'post__not_in' => array($post_id),
                'posts_per_page' => $optimal_links * 3,
                'orderby' => 'date',
                'order' => 'DESC',
                'post_status' => 'publish'
            );
            $related_posts = new WP_Query($args);
        }

        $result = array();
        if ($related_posts->have_posts()) {
            $all_posts = array();
            while ($related_posts->have_posts()) {
                $related_posts->the_post();
                $all_posts[] = array(
                    'title' => get_the_title(),
                    'permalink' => get_permalink(),
                );
            }
            wp_reset_postdata();

            shuffle($all_posts);
            $result = array_slice($all_posts, 0, $optimal_links);
        }

        // Cache kết quả
        set_transient($cache_key, $result, VNAICONTENT_TRANSIENT_CACHE_TIME);
        wp_cache_set($cache_key, $result, '', VNAICONTENT_OBJECT_CACHE_TIME);

        return $result;
    } catch (Exception $e) {
        error_log('Related posts cache error: ' . $e->getMessage());

        // Fallback về query không cache trong trường hợp lỗi
        $args = array(
            'post__not_in' => array($post_id),
            'posts_per_page' => $optimal_links,
            'orderby' => 'date',
            'order' => 'DESC',
            'post_status' => 'publish'
        );

        $related_posts = new WP_Query($args);
        $result = array();

        if ($related_posts->have_posts()) {
            while ($related_posts->have_posts()) {
                $related_posts->the_post();
                $result[] = array(
                    'title' => get_the_title(),
                    'permalink' => get_permalink(),
                );
            }
            wp_reset_postdata();
        }

        return $result;
    }
}

function get_cached_toc($content, $options)
{
    $post_id = get_the_ID();
    $cache_key = 'post_toc_' . $post_id;

    $cached_toc = wp_cache_get($cache_key);
    if (false !== $cached_toc) {
        return generate_toc_html($cached_toc, $options['toc_text']);
    }

    $cached_toc = get_transient($cache_key);
    if (false !== $cached_toc) {
        wp_cache_set($cache_key, $cached_toc, '', VNAICONTENT_OBJECT_CACHE_TIME);
        return generate_toc_html($cached_toc, $options['toc_text']);
    }

    // Nếu không có cache, tạo TOC mới
    preg_match_all('/<h[2-4].*?>(.*?)<\/h[2-4]>/i', $content, $matches);

    if (!empty($matches[0])) {
        $headings = array();
        $headings_map = array();
        $index = 0;

        foreach ($matches[0] as $heading) {
            preg_match('/<h([2-4])/i', $heading, $level);
            $level = $level[1];
            $title = strip_tags($matches[1][$index]);
            $anchor = create_clean_anchor($title);

            $headings[] = array(
                'level' => $level,
                'title' => $title,
                'anchor' => $anchor
            );

            $headings_map[$heading] = '<h' . $level . ' id="' . $anchor . '">' . $matches[1][$index] . '</h' . $level . '>';
            $index++;
        }

        $cache_data = array(
            'headings' => $headings,
            'headings_map' => $headings_map
        );

        set_transient($cache_key, $cache_data, VNAICONTENT_TRANSIENT_CACHE_TIME);
        wp_cache_set($cache_key, $cache_data, '', VNAICONTENT_OBJECT_CACHE_TIME);

        return generate_toc_html($cache_data, $options['toc_text']);
    }

    return null;
}

function generate_toc_html($cache_data, $toc_text = 'Nội dung bài viết')
{
    if (empty($cache_data['headings'])) {
        return null;
    }

    $toc = '<div class="vnaicontent-toc">';
    $toc .= '<p>' . esc_html($toc_text) . '</p>';
    $toc .= '<ul class="vnaicontent-toc-list">';

    foreach ($cache_data['headings'] as $heading) {
        $indent = ($heading['level'] - 2) * 25;
        $toc .= sprintf(
            '<li class="lv%d" style="margin-left: %dpx;"><a href="#%s">%s</a></li>',
            $heading['level'],
            $indent,
            $heading['anchor'],
            $heading['title']
        );
    }

    $toc .= '</ul></div>';

    return array(
        'toc' => $toc,
        'headings_map' => $cache_data['headings_map']
    );
}

function get_cached_audio_content($post_id, $options)
{
    $player = $options['audio_player'];
    $cache_key = 'post_audio_' . $post_id . '_' . $player; // Thêm player vào cache key

    $cached_content = wp_cache_get($cache_key);
    if (false !== $cached_content) {
        return $cached_content;
    }

    $cached_content = get_transient($cache_key);
    if (false !== $cached_content) {
        wp_cache_set($cache_key, $cached_content, '', VNAICONTENT_OBJECT_CACHE_TIME);
        return $cached_content;
    }

    // Nếu không có cache, tạo content mới
    $player_str = '';
    $upload_dir = wp_upload_dir();
    $audio_file = $upload_dir['path'] . '/' . $post_id . '.mp3';
    $audio_link = $upload_dir['url'] . '/' . $post_id . '.mp3';

    if (file_exists($audio_file)) {
        if ($player == 'plyr') {
            $player_str = '<audio id="vnay-player" controls><source src="' . $audio_link . '" type="audio/mp3" /></audio><script>const player = new Plyr("#vnay-player");</script>';
        } elseif ($player == 'aplayer') {
            $thumbnail_url = get_the_post_thumbnail_url($post_id);
            $player_str = '<div class="vnay-player"></div><script>const ap = new APlayer({container: document.querySelector(\'.vnay-player\'),volume: 1,theme: \'#c3c4c7\',loop: \'none\',audio: [{name: \'' . get_the_title() . '\',artist: \'' . get_bloginfo('name') . '\',url: \'' . $audio_link . '\',cover: \'' . $thumbnail_url . '\'}]});</script>';
        } else {
            $player_str = '<div style="margin-bottom:20px">' . do_shortcode('[audio mp3="' . $audio_link . '"]') . '</div>';
        }

        // Cache kết quả
        set_transient($cache_key, $player_str, VNAICONTENT_TRANSIENT_CACHE_TIME);
        wp_cache_set($cache_key, $player_str, '', VNAICONTENT_OBJECT_CACHE_TIME);
    }

    return $player_str;
}

function get_cached_youtube_content($post_id, $youtube_id)
{
    $cache_key = 'post_youtube_' . $post_id;

    $cached_content = wp_cache_get($cache_key);
    if (false !== $cached_content) {
        return $cached_content;
    }

    $cached_content = get_transient($cache_key);
    if (false !== $cached_content) {
        wp_cache_set($cache_key, $cached_content, '', VNAICONTENT_OBJECT_CACHE_TIME);
        return $cached_content;
    }

    if ($youtube_id !== false && $youtube_id != 'no' && $youtube_id != '') {
        $youtube = '<div class="responsive-video">' . wp_oembed_get('http://www.youtube.com/watch?v=' . $youtube_id) . '</div>';

        set_transient($cache_key, $youtube, VNAICONTENT_TRANSIENT_CACHE_TIME);
        wp_cache_set($cache_key, $youtube, '', VNAICONTENT_OBJECT_CACHE_TIME);

        return $youtube;
    }

    return '';
}

function clear_post_caches($post_id)
{
    // Clear related posts caches
    for ($i = 1; $i <= 10; $i++) {
        $cache_key = 'related_posts_' . $post_id . '_' . $i;
        wp_cache_delete($cache_key);
        delete_transient($cache_key);
    }

    // Clear TOC cache
    $toc_cache_key = 'post_toc_' . $post_id;
    wp_cache_delete($toc_cache_key);
    delete_transient($toc_cache_key);

    // Clear taxonomy caches
    wp_cache_delete('post_categories_' . $post_id);
    wp_cache_delete('post_tags_' . $post_id);
    wp_cache_delete('related_query_' . $post_id . '_tag');

    // Clear char count cache
    $char_count_key = 'post_char_count_' . $post_id;
    wp_cache_delete($char_count_key);
    delete_transient($char_count_key);

    // Clear audio cache
    $player_types = ['plyr', 'aplayer', 'default'];
    foreach ($player_types as $player) {
        $audio_cache_key = 'post_audio_' . $post_id . '_' . $player;
        wp_cache_delete($audio_cache_key);
        delete_transient($audio_cache_key);
    }

    // Clear YouTube cache
    $youtube_cache_key = 'post_youtube_' . $post_id;
    wp_cache_delete($youtube_cache_key);
    delete_transient($youtube_cache_key);
}

function clear_related_posts_caches($post_id)
{
    $categories = get_the_category($post_id);
    $related_ids = array();

    if (!empty($categories)) {
        $cat_posts = get_posts(array(
            'category__in' => array($categories[0]->term_id),
            'posts_per_page' => 100,
            'fields' => 'ids',
            'post__not_in' => array($post_id)
        ));
        $related_ids = array_merge($related_ids, $cat_posts);
    }

    $post_tags = wp_get_post_tags($post_id);
    if (!empty($post_tags)) {
        $tag_ids = wp_list_pluck($post_tags, 'term_id');
        $tag_posts = get_posts(array(
            'tag__in' => $tag_ids,
            'posts_per_page' => 100,
            'fields' => 'ids',
            'post__not_in' => array($post_id)
        ));
        $related_ids = array_merge($related_ids, $tag_posts);
    }

    $related_ids = array_unique($related_ids);

    foreach ($related_ids as $id) {
        clear_post_caches($id);
    }
}

add_action('save_post', function ($post_id) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
        return;
    }
    clear_post_caches($post_id);
    clear_related_posts_caches($post_id);
}, 10, 1);
