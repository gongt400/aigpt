<?php  
    function aicontent_column($columns) {
        $new_columns = array(
            'cb' => $columns['cb'],
            'title' => $columns['title'],
            'aiimage' => __('Image'),
            'aicontent' => __('AI Content'),
            'aiaudio' => __('Audio'),
            'yt' => __('Youtube'),
            'tag' => __('Tag'),
            'des' => __('Meta des')
        );
        unset($columns['cb']);
        unset($columns['title']);
        return $new_columns + $columns;
    }
    function aicontent_display_column($column_name, $post_id) {
        $type_ai = get_post_meta($post_id, 'type_ai', true);
        $img_by = get_post_meta($post_id, 'img_by', true);
        $audio = get_post_meta($post_id, 'audio', true);
        $yt = get_post_meta($post_id, 'youtube_id', true);
        $tag = get_post_meta($post_id, 'tag', true);
        $des = get_post_meta($post_id, 'des', true);

        if ($column_name == 'aicontent' && $type_ai != '') {
            echo $type_ai;
        }elseif ($column_name == 'aiimage') {
            if (has_post_thumbnail($post_id)) {
                $thumbnail = get_the_post_thumbnail($post_id, array(45, 45));
                echo '<a target="_blank" href="' . get_permalink($post_id) . '">' . $thumbnail . '</a>';
            }
            if ($img_by != '') {
                if ($img_by != 'error') {
                    echo '<p>' . $img_by . '</p>';
                }else{
                    echo '<span class="red-text">error</span>';
                }
            }
        }elseif ($column_name == 'aiaudio' && $audio != '') {
            $upload_dir = wp_upload_dir();
            $audio_link = $upload_dir['url'] . '/' . $post_id . '.mp3';
            echo '<a target="_blank" href="' . $audio_link . '">' . $audio . '</a>';
        }elseif ($column_name == 'yt' && $yt != '') {
            if ($yt != 'no') {
                echo '<a target="_blank" href="https://www.youtube.com/watch?v=' . $yt . '">' . $yt . '</a>';
            }else{
                echo 'Không có';
            }
        }elseif ($column_name == 'tag' && $tag != '') {
            if ($yt != 'no') {
                echo 'Đã tạo';
            }else{
                echo 'Không có';
            }
        }elseif ($column_name == 'des' && $des != '') {
            if ($des != 'no') {
                echo 'Đã tạo';
            }else{
                echo 'Không có';
            }
        }
    }
    add_filter('manage_post_posts_columns', 'aicontent_column');
    add_action('manage_post_posts_custom_column', 'aicontent_display_column', 10, 2);

    //========== filter post
    function aicontent_post_filter() {
        global $post_type;
        if ('post' == $post_type) {
            echo '<select name="vnaicontent_filter">';
                echo '<option value="">VnAIContent</option>';

                echo '<optgroup label="Lọc theo nội dung">';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'is_ai_content' ? 'selected' : '';
                    echo '<option value="is_ai_content" ' . $selected . '>Bài viết AI</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'gemini_content' ? 'selected' : '';
                    echo '<option value="gemini_content" ' . $selected . '>Bài viết Gemini</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'openai_content' ? 'selected' : '';
                    echo '<option value="openai_content" ' . $selected . '>Bài viết OpenAI</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'claude_content' ? 'selected' : '';
                    echo '<option value="claude_content" ' . $selected . '>Bài viết Claude</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'not_ai_content' ? 'selected' : '';
                    echo '<option value="not_ai_content" ' . $selected . '>Bài viết không tạo bởi AI</option>';

                echo '</optgroup>';

                echo '<optgroup label="Lọc theo hình ảnh">';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'is_ai_img' ? 'selected' : '';
                    echo '<option value="is_ai_img" ' . $selected . '>Có ảnh</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'cloudflare_img' ? 'selected' : '';
                    echo '<option value="cloudflare_img" ' . $selected . '>Ảnh Cloudflare</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'openai_img' ? 'selected' : '';
                    echo '<option value="openai_img" ' . $selected . '>Ảnh OpenAI</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'huggingface_img' ? 'selected' : '';
                    echo '<option value="huggingface_img" ' . $selected . '>Ảnh HuggingFace</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'google_img' ? 'selected' : '';
                    echo '<option value="google_img" ' . $selected . '>Ảnh Google Search</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'ai_img_error' ? 'selected' : '';
                    echo '<option value="ai_img_error" ' . $selected . '>Tạo ảnh thất bại</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'not_ai_img' ? 'selected' : '';
                    echo '<option value="not_ai_img" ' . $selected . '>Chưa tạo ảnh</option>';

                echo '</optgroup>';

                echo '<optgroup label="Lọc theo audio">';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'has_audio' ? 'selected' : '';
                    echo '<option value="has_audio" ' . $selected . '>Có audio</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'audio_viettel' ? 'selected' : '';
                    echo '<option value="audio_viettel" ' . $selected . '>Audio Viettel</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'audio_google' ? 'selected' : '';
                    echo '<option value="audio_google" ' . $selected . '>Audio Google</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'audio_openai' ? 'selected' : '';
                    echo '<option value="audio_openai" ' . $selected . '>Audio OpenAI</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'audio_azure_speech' ? 'selected' : '';
                    echo '<option value="audio_azure_speech" ' . $selected . '>Audio Azure Speech</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'audio_azure_openai' ? 'selected' : '';
                    echo '<option value="audio_azure_openai" ' . $selected . '>Audio Azure OpenAI</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'audio_error' ? 'selected' : '';
                    echo '<option value="audio_error" ' . $selected . '>Tạo audio thất bại</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'not_audio' ? 'selected' : '';
                    echo '<option value="not_audio" ' . $selected . '>Chưa tạo audio</option>';

                echo '</optgroup>';

                echo '<optgroup label="Lọc theo youtube">';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'has_yt' ? 'selected' : '';
                    echo '<option value="has_yt" ' . $selected . '>Có youtube</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'no_yt' ? 'selected' : '';
                    echo '<option value="no_yt" ' . $selected . '>Không có youtube</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'not_yt' ? 'selected' : '';
                    echo '<option value="not_yt" ' . $selected . '>Chưa lấy youtube</option>';

                echo '</optgroup>';

                echo '<optgroup label="Lọc theo tag">';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'has_tag' ? 'selected' : '';
                    echo '<option value="has_tag" ' . $selected . '>Có tag</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'no_tag' ? 'selected' : '';
                    echo '<option value="no_tag" ' . $selected . '>Không có tag</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'not_tag' ? 'selected' : '';
                    echo '<option value="not_tag" ' . $selected . '>Chưa tạo tag</option>';

                echo '</optgroup>';

                echo '<optgroup label="Lọc theo meta description">';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'has_des' ? 'selected' : '';
                    echo '<option value="has_des" ' . $selected . '>Có meta description</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'no_des' ? 'selected' : '';
                    echo '<option value="no_des" ' . $selected . '>Không có meta description</option>';

                    $selected = isset($_GET['vnaicontent_filter']) && $_GET['vnaicontent_filter'] == 'not_des' ? 'selected' : '';
                    echo '<option value="not_des" ' . $selected . '>Chưa tạo meta description</option>';

                echo '</optgroup>';

            echo '</select>';
        }
    }

    function aicontent_filter($query) {
        global $typenow;

        if ('post' == $typenow && isset($_GET['vnaicontent_filter'])) {
            $filter = $_GET['vnaicontent_filter'];

            $meta_query = $query->get('meta_query');
            if (!is_array($meta_query)) {
                $meta_query = array();
            }

            //des
            if ($filter == 'has_des') {
                $meta_query[] = array(
                    'key' => 'des',
                    'value' => 'ok'
                );
            }
            if ($filter == 'no_des') {
                $meta_query[] = array(
                    'key' => 'des',
                    'value' => 'no',
                );
            }
            if ($filter == 'not_des') {
                $meta_query[] = array(
                    'key' => 'des',
                    'compare' => 'NOT EXISTS',
                );
            }

            //tag
            if ($filter == 'has_tag') {
                $meta_query[] = array(
                    'key' => 'tag',
                    'value' => 'ok'
                );
            }
            if ($filter == 'no_tag') {
                $meta_query[] = array(
                    'key' => 'tag',
                    'value' => 'no',
                );
            }
            if ($filter == 'not_tag') {
                $meta_query[] = array(
                    'key' => 'tag',
                    'compare' => 'NOT EXISTS',
                );
            }

            //yt
            if ($filter == 'has_yt') {
                $meta_query[] = array(
                    'key' => 'youtube_id',
                    'value' => 'no',
                    'compare' => '!=',
                );
            }
            if ($filter == 'no_yt') {
                $meta_query[] = array(
                    'key' => 'youtube_id',
                    'value' => 'no',
                );
            }
            if ($filter == 'not_yt') {
                $meta_query[] = array(
                    'key' => 'youtube_id',
                    'compare' => 'NOT EXISTS',
                );
            }

            //audio
            if ($filter == 'has_audio') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'error',
                    'compare' => '!=',
                );
            }
            if ($filter == 'audio_viettel') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'viettel',
                );
            }
            if ($filter == 'audio_google') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'google',
                );
            }
            if ($filter == 'audio_openai') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'openai',
                );
            }
            if ($filter == 'audio_azure_speech') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'azure_speech',
                );
            }
            if ($filter == 'audio_azure_openai') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'azure_openai',
                );
            }
            if ($filter == 'audio_error') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'value' => 'error',
                );
            }
            if ($filter == 'not_audio') {
                $meta_query[] = array(
                    'key' => 'audio',
                    'compare' => 'NOT EXISTS',
                );
            }

            //content
            if ($filter == 'is_ai_content') {
                $meta_query[] = array(
                    'key' => 'type_ai',
                    'compare' => 'EXISTS',
                );
            }
            if ($filter == 'gemini_content') {
                $meta_query[] = array(
                    'key' => 'type_ai',
                    'value' => 'gemini',
                );
            }
            if ($filter == 'openai_content') {
                $meta_query[] = array(
                    'key' => 'type_ai',
                    'value' => 'openai',
                );
            }
            if ($filter == 'claude_content') {
                $meta_query[] = array(
                    'key' => 'type_ai',
                    'value' => 'claude',
                );
            }
            if ($filter == 'not_ai_content') {
                $meta_query[] = array(
                    'key' => 'type_ai',
                    'compare' => 'NOT EXISTS',
                );
            }

            //img
            if ($filter == 'is_ai_img') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'value' => 'error',
                    'compare' => '!=',
                );
            }
            if ($filter == 'cloudflare_img') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'value' => 'cloudflare',
                );
            }
            if ($filter == 'openai_img') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'value' => 'openai',
                );
            }
            if ($filter == 'huggingface_img') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'value' => 'huggingface',
                );
            }
            if ($filter == 'google_img') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'value' => 'google',
                );
            }
            if ($filter == 'ai_img_error') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'value' => 'error',
                );
            }
            if ($filter == 'not_ai_img') {
                $meta_query[] = array(
                    'key' => 'img_by',
                    'compare' => 'NOT EXISTS',
                );
            }

            $query->set('meta_query', $meta_query);
        }
    }

    add_action('restrict_manage_posts', 'aicontent_post_filter');
    add_action('pre_get_posts', 'aicontent_filter');

    //bulk_actions
    function vnaicontent_add_bulk_actions($actions) {
        $actions['vnaicontent_separator'] = '↓ VnAIContent';
        
        $actions['vnaicontent_remove_img'] = '&nbsp;&nbsp;&nbsp;&nbsp;' . __('Xóa trạng thái đã tạo ảnh', 'text-domain');
        $actions['vnaicontent_remove_audio'] = '&nbsp;&nbsp;&nbsp;&nbsp;' . __('Xóa trạng thái đã tạo audio', 'text-domain');
        $actions['vnaicontent_remove_yt'] = '&nbsp;&nbsp;&nbsp;&nbsp;' . __('Xóa trạng thái đã lấy youtube', 'text-domain');
        $actions['vnaicontent_remove_tag'] = '&nbsp;&nbsp;&nbsp;&nbsp;' . __('Xóa trạng thái đã tạo tag', 'text-domain');
        $actions['vnaicontent_remove_des'] = '&nbsp;&nbsp;&nbsp;&nbsp;' . __('Xóa trạng thái đã tạo meta description', 'text-domain');
        $actions['vnaicontent_remove_post_permanently'] = '&nbsp;&nbsp;&nbsp;&nbsp;' . __('Xóa vĩnh viễn bài viết và file đính kèm', 'text-domain');
        
        return $actions;
    }
    add_filter('bulk_actions-edit-post', 'vnaicontent_add_bulk_actions');

    function vnaicontent_add_bulk_action_disable_option() {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('select[name="action"] option[value="vnaicontent_separator"]').attr('disabled', 'disabled');
            });
        </script>
        <?php
    }
    add_action('admin_footer', 'vnaicontent_add_bulk_action_disable_option');

    function vnaicontent_add_custom_bulk_actions_css() {
        ?>
        <style type="text/css">
            select[name="action"] option[value="vnaicontent_separator"]{
                font-weight: bold;
                color: #000;
                background-color: #f1f1f1;
            }
        </style>
        <?php
    }
    add_action('admin_head', 'vnaicontent_add_custom_bulk_actions_css');

    function vnaicontent_add_bulk_action_confirmation() {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('#doaction').click(function(e) {
                    var selectedAction = $('select[name="action"]').val();

                    var checkedPosts = $('tbody th.check-column input[type="checkbox"]:checked').length;
                    
                    if (checkedPosts === 0) {
                        return;
                    }
                    
                    if (selectedAction === 'vnaicontent_remove_img') {
                        if (!confirm('<?php _e("Bạn có chắc chắn muốn xóa trạng thái đã tạo ảnh?", "text-domain"); ?>')) {
                            e.preventDefault();
                        }
                    }

                    if (selectedAction === 'vnaicontent_remove_audio') {
                        if (!confirm('<?php _e("Bạn có chắc chắn muốn xóa trạng thái đã tạo audio? Hành động này sẽ xóa audio của bài viết (nếu có) và không thể hoàn tác", "text-domain"); ?>')) {
                            e.preventDefault();
                        }
                    }

                    if (selectedAction === 'vnaicontent_remove_yt') {
                        if (!confirm('<?php _e("Bạn có chắc chắn muốn xóa trạng thái đã lấy youtube?", "text-domain"); ?>')) {
                            e.preventDefault();
                        }
                    }

                    if (selectedAction === 'vnaicontent_remove_tag') {
                        if (!confirm('<?php _e("Bạn có chắc chắn muốn xóa trạng thái đã tạo tag? Hành động này sẽ xóa toàn bộ tags của bài viết và không thể hoàn tác!", "text-domain"); ?>')) {
                            e.preventDefault();
                        }
                    }

                    if (selectedAction === 'vnaicontent_remove_des') {
                        if (!confirm('<?php _e("Bạn có chắc chắn muốn xóa trạng thái đã tạo meta description? Hành động này sẽ xóa excerpt của bài viết và không thể hoàn tác!", "text-domain"); ?>')) {
                            e.preventDefault();
                        }
                    }
                    
                    if (selectedAction === 'vnaicontent_remove_post_permanently') {
                        if (!confirm('<?php _e("Bạn có chắc chắn muốn xóa vĩnh viễn bài viết và file đính kèm? Hành động này không thể hoàn tác!", "text-domain"); ?>')) {
                            e.preventDefault();
                        }
                    }
                });
            });
        </script>
        <?php
    }
    add_action('admin_footer', 'vnaicontent_add_bulk_action_confirmation');

    function vnaicontent_handle_remove_img_action($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'vnaicontent_remove_img') {
            return $redirect_to;
        }
        foreach ($post_ids as $post_id) {
            delete_post_meta($post_id, 'img_by');
        }
        $redirect_to = add_query_arg('img_removed', count($post_ids), $redirect_to);
        return $redirect_to;
    }
    add_filter('handle_bulk_actions-edit-post', 'vnaicontent_handle_remove_img_action', 10, 3);

    function vnaicontent_handle_remove_audio_action($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'vnaicontent_remove_audio') {
            return $redirect_to;
        }

        $upload_dir = wp_upload_dir();
        foreach ($post_ids as $post_id) {
            delete_post_meta($post_id, 'audio');
            delete_post_meta($post_id, 'rank_math_schema_PodcastEpisode');
            $audio_file = $upload_dir['path'] . '/' . $post_id . '.mp3';
            if (file_exists($audio_file)) {
                unlink($audio_file);
            }

            $audio_url = $upload_dir['url'] . '/' . $post_id . '.mp3';
            $attachment_id = attachment_url_to_postid($audio_url);
            if ($attachment_id) {
                wp_delete_attachment($attachment_id, true);
            }
        }
        $redirect_to = add_query_arg('audio_removed', count($post_ids), $redirect_to);
        return $redirect_to;
    }
    add_filter('handle_bulk_actions-edit-post', 'vnaicontent_handle_remove_audio_action', 10, 3);

    function vnaicontent_handle_remove_yt_action($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'vnaicontent_remove_yt') {
            return $redirect_to;
        }
        foreach ($post_ids as $post_id) {
            delete_post_meta($post_id, 'youtube_id');
        }
        $redirect_to = add_query_arg('yt_removed', count($post_ids), $redirect_to);
        return $redirect_to;
    }
    add_filter('handle_bulk_actions-edit-post', 'vnaicontent_handle_remove_yt_action', 10, 3);

    function vnaicontent_handle_remove_tag_action($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'vnaicontent_remove_tag') {
            return $redirect_to;
        }
        foreach ($post_ids as $post_id) {
            wp_set_post_terms($post_id, array(), 'post_tag');
            delete_post_meta($post_id, 'tag');
        }
        $redirect_to = add_query_arg('tag_removed', count($post_ids), $redirect_to);
        return $redirect_to;
    }
    add_filter('handle_bulk_actions-edit-post', 'vnaicontent_handle_remove_tag_action', 10, 3);

    function vnaicontent_handle_remove_des_action($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'vnaicontent_remove_des') {
            return $redirect_to;
        }
        foreach ($post_ids as $post_id) {
            wp_update_post(array('ID' => $post_id, 'post_excerpt' => ''));
            delete_post_meta($post_id, 'des');
        }
        $redirect_to = add_query_arg('des_removed', count($post_ids), $redirect_to);
        return $redirect_to;
    }
    add_filter('handle_bulk_actions-edit-post', 'vnaicontent_handle_remove_des_action', 10, 3);

    function vnaicontent_handle_remove_post_permanently_action($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'vnaicontent_remove_post_permanently') {
            return $redirect_to;
        }

        foreach ($post_ids as $post_id) {
            $attachments = get_attached_media('', $post_id);
            foreach ($attachments as $attachment) {
                wp_delete_attachment($attachment->ID, true);
            }

            $keyword_post_removed = get_post_meta($post_id, 'keyword', true);
            $cats = get_the_category($post_id);
            if (!empty($keyword_post_removed) && !empty($cats)) {
                $keyword_post_removed_txt = VNAICONTENT_DATA . 'keyword_post_removed_' . $cats[0]->term_id . '.txt';

                if (!file_exists($keyword_post_removed_txt)) {
                    $handle = fopen($keyword_post_removed_txt, "w");
                    fclose($handle);
                }

                $keyword_post_removed_value = file_get_contents($keyword_post_removed_txt);
                $keyword_post_removed_arr = !empty($keyword_post_removed_value) ? explode("\n", $keyword_post_removed_value) : array();
                
                array_push($keyword_post_removed_arr, $keyword_post_removed);

                $keyword_active_txt = VNAICONTENT_DATA . 'keyword_active_' . $cats[0]->term_id . '.txt';

                if (file_exists($keyword_active_txt)) {
                    $keyword_active_value = file_get_contents($keyword_active_txt);
                    $keyword_active_arr = !empty($keyword_active_value) ? explode("\n", $keyword_active_value) : array();

                    if (($key = array_search($keyword_post_removed, $keyword_active_arr)) !== false) {
                        unset($keyword_active_arr[$key]);
                    }

                    file_put_contents($keyword_active_txt, implode("\n", $keyword_active_arr));
                }

                file_put_contents($keyword_post_removed_txt, implode("\n", $keyword_post_removed_arr));
            }

            wp_delete_post($post_id, true);
        }

        $redirect_to = add_query_arg('posts_deleted', count($post_ids), $redirect_to);
        return $redirect_to;
    }
    add_filter('handle_bulk_actions-edit-post', 'vnaicontent_handle_remove_post_permanently_action', 10, 3);

?>