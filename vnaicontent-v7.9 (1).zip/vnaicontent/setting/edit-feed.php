<?php
add_filter('pre_get_posts', 'vnaicontent_category_feed_filter');
function vnaicontent_category_feed_filter($query)
{
    if (!$query->is_feed()) {
        return $query;
    }

    $meta_query = array();
    //upload yt to fb by make
    if (isset($_GET['yt']) && $_GET['yt'] == '1') {
        $meta_query = array(
            'relation' => 'AND',
            array(
                'key' => 'youtube_id',
                'value' => '',
                'compare' => '!='
            ),
            array(
                'key' => 'youtube_id',
                'value' => 'no',
                'compare' => '!='
            )
        );
    }

    if (isset($_GET['ids'])) {
        $category_ids = array_map('intval', explode(',', $_GET['ids']));
        $category_ids = array_filter($category_ids);

        if (!empty($category_ids)) {
            $query->set('tax_query', [
                [
                    'taxonomy' => 'category',
                    'field'    => 'term_id',
                    'terms'    => $category_ids,
                ]
            ]);
        }
    }

    if (!empty($meta_query)) {
        $query->set('meta_query', $meta_query);
    }

    return $query;
}

add_action('template_redirect', 'vnaicontent_fix_podcast_feed');
function vnaicontent_fix_podcast_feed()
{
    if (!is_feed()) {
        return;
    }

    ob_start(function ($output) {
        $options = vnaicontent_get_options();
        $pattern = '/<item>(.*?)<\/item>/s';
        $output = preg_replace_callback($pattern, function ($matches) use ($options) {
            $item_content = $matches[1];

            if (preg_match('/<guid.*?>(.*?)<\/guid>/', $item_content, $guid_matches)) {
                $post_id = url_to_postid($guid_matches[1]);

                if ($post_id) {
                    $permalink = get_permalink($post_id);
                    $link_str = 'Chi tiết: ';
                    $site_lang = get_locale();
                    if ($site_lang != 'vi') {
                        $link_str = 'Detail: ';
                    }
                    $link_str = "\n======\n" . $link_str . $permalink;
                    $keyword = get_post_meta($post_id, 'keyword', true);
                    $keyword_str = '';
                    $description_content = '';
                    $lenght_content = 255;
                    $hashtags = '';
                    $first_str = '';

                    if (isset($_GET['title']) && $_GET['title'] == 1) {
                        $keyword_str = (!empty($keyword) ? ucwords($keyword) : get_the_title($post_id)) . "\n\n";
                    }

                    if (isset($_GET['content'])) {
                        $lenght_content = $_GET['content'];
                    }

                    $content = get_the_content(null, false, $post_id);
                    if (isset($_GET['markdown']) && $_GET['markdown'] == 1) {
                        $content = vnaicontent_html2m($content);
                    } else {
                        $content = wp_strip_all_tags($content);
                        $content = strip_shortcodes($content);
                    }

                    $description_content = substr($content, 0, $lenght_content) . ($lenght_content > 0 ? '...' : '');

                    if (preg_match_all('/<category><!\[CDATA\[(.*?)\]\]><\/category>/', $item_content, $category_matches)) {
                        $tags = array_slice($category_matches[1], 0, 6);
                        $hashtags = "\n\n" . implode(' ', array_map(function ($tag) {
                            return vnaicontent_tag_to_hastag($tag);
                        }, $tags));
                    }

                    if (isset($_GET['link']) && $_GET['link'] == 0) {
                        $link_str = '';
                    }

                    if (strpos($_SERVER['REQUEST_URI'], '/podcast') !== false) {
                        $first_str = 'id' . $post_id . ' - ';
                    }

                    $description = $first_str . $keyword_str . $description_content . $hashtags . $link_str;

                    if (isset($_GET['thumb']) && $_GET['thumb'] == 1) {
                        $thumbnail_url = get_the_post_thumbnail_url($post_id, 'full');
                        if (!empty($thumbnail_url)) {
                            $item_content = str_replace(
                                '</guid>',
                                '</guid>' . "\n\t\t" . '<media:thumbnail url="' . esc_url($thumbnail_url) . '" />',
                                $item_content
                            );
                        }
                    }

                    if (!preg_match('/<description>/', $item_content)) {
                        $item_content .= "\n\t\t<description><![CDATA[" . $description . "]]></description>\n\t";
                    } else {
                        $item_content = preg_replace(
                            '/<description>.*?<\/description>/s',
                            "\n\t\t<description><![CDATA[" . $description . "]]></description>\n\t",
                            $item_content
                        );
                    }
                }
            }

            return "<item>\n\t\t" . trim($item_content) . "\n</item>\n";
        }, $output);

        return $output;
    });
}

function vnaicontent_tag_to_hastag($tag)
{
    if (class_exists('Transliterator')) {
        $transliterator = Transliterator::create('Any-Latin; Latin-ASCII; [\u0100-\u7fff] remove');
        $tag = $transliterator->transliterate($tag);
    }
    $slug = sanitize_title($tag);
    $hastag = ucwords(str_replace('-', ' ', $slug));
    return '#' . str_replace(' ', '', $hastag);
}

function vnaicontent_html2m($html)
{
    try {
        $html = preg_replace('/<img\b[^>]*>/i', '', $html);

        $autoloadPath = VNAICONTENT_PATH . 'lib/html-to-markdown/autoload.php';
        if (!file_exists($autoloadPath)) {
            return '';
        }
        require_once $autoloadPath;

        $config = array(
            'header_style' => 'atx',
            'strip_tags' => true,
            'strip_placeholder_links' => true,
            'hard_break' => true,
            'use_autolinks' => false,
            'preserve_line_breaks' => true,
            'preserve_spaces' => true,
        );

        $converter = new \League\HTMLToMarkdown\HtmlConverter($config);
        $converter->getEnvironment()->addConverter(new \League\HTMLToMarkdown\Converter\TableConverter());
        $content_m = $converter->convert($html);

        $content_m = preg_replace('/(?<!^)(\s*#{1,6}\s.*)/', "\n\$1", trim($content_m));
        return $content_m;
    } catch (\Exception $e) {
        return '';
    }
}

function vnaicontent_podcast_rewrite_rule()
{
    add_rewrite_rule( // slug/feed/podcast/
        '^([^/]+)/feed/podcast/?$',
        'index.php?category_name=$matches[1]&feed=podcast',
        'top'
    );

    add_rewrite_rule( // slug/feed/podcast.xml
        '^([^/]+)/feed/podcast\.xml/?$',
        'index.php?category_name=$matches[1]&feed=podcast',
        'top'
    );
}
add_action('init', 'vnaicontent_podcast_rewrite_rule');

add_filter('rank_math/podcast_args', function ($args = []) {
    if (get_query_var('category_name')) {
        $category = get_category_by_slug(get_query_var('category_name'));
        if ($category) {
            $args['cat'] = $category->term_id;
        }
    }

    $options = vnaicontent_get_options();
    if (!empty($options['feed_podcast_order'])) {
        $args['orderby'] = 'ID';
        $args['order'] = 'ASC';
    }
    if (!isset($options['feed_podcast_offset']) && $options['feed_podcast_offset'] > 0) {
        $args['offset'] = $options['feed_podcast_offset'];
    }

    return $args;
});
