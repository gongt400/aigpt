<div class="vnaicontent-tab-vertical" style="<?php if (!isset($_GET['tab']) || (isset($_GET['tab']) & $_GET['tab'] != 'tools')) {
                                                    echo 'display: none;';
                                                } ?>">
    <div class="tab-links">
        <button type="button" data-tab="related-posts" class="button-first">Tạo Related Posts</button>
        <button type="button" data-tab="tag">Tạo Tag</button>
        <button type="button" data-tab="meta-des">Tạo Meta Description</button>
        <button type="button" data-tab="toc">Tạo Table Of Content</button>
        <button type="button" data-tab="filter-keyword">Lọc Keywords</button>
        <button type="button" data-tab="clear-cache">Xóa cache</button>
    </div>

    <div class="tab-content tab-content-first" id="related-posts">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="text_more">Text more</label></th>
                    <td>
                        <?php $text_more = isset($this->options['text_more']) ? $this->options['text_more'] : ''; ?>
                        <input name="vnaicontent_option[text_more]" id="text_more" class="regular-text" placeholder="Xem thêm:" value="<?php echo $text_more; ?>" type="text">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="num_relatedposts">Số lượng Related posts</label></th>
                    <td>
                        <?php
                        $num_relatedposts = isset($this->options['num_relatedposts']) ? $this->options['num_relatedposts'] : 0;
                        ?>
                        <select name="vnaicontent_option[num_relatedposts]" id="num_relatedposts">
                            <option value="0" <?php echo selected($num_relatedposts, '0', false) ?>>Không chèn</option>
                            <option value="99" <?php echo selected($num_relatedposts, '99', false) ?>>Tự động tối ưu</option>
                            <option value="1" <?php echo selected($num_relatedposts, '1', false) ?>>1</option>
                            <option value="2" <?php echo selected($num_relatedposts, '2', false) ?>>2</option>
                            <option value="3" <?php echo selected($num_relatedposts, '3', false) ?>>3</option>
                            <option value="4" <?php echo selected($num_relatedposts, '4', false) ?>>4</option>
                            <option value="5" <?php echo selected($num_relatedposts, '5', false) ?>>5</option>
                            <option value="6" <?php echo selected($num_relatedposts, '6', false) ?>>6</option>
                            <option value="7" <?php echo selected($num_relatedposts, '7', false) ?>>7</option>
                            <option value="8" <?php echo selected($num_relatedposts, '8', false) ?>>8</option>
                            <option value="9" <?php echo selected($num_relatedposts, '9', false) ?>>9</option>
                            <option value="10" <?php echo selected($num_relatedposts, '10', false) ?>>10</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cat_tag">Related posts</label>
                    </th>
                    <td>
                        <?php $cat_tag = isset($this->options['cat_tag']) ? $this->options['cat_tag'] : 'all'; ?>
                        <select name="vnaicontent_option[cat_tag]" id="cat_tag">
                            <option value="all" <?php echo selected($cat_tag, 'all', false) ?>>Cùng danh mục hoặc tag (ưu tiên tag)</option>
                            <option value="cat" <?php echo selected($cat_tag, 'cat', false) ?>>Cùng danh mục</option>
                            <option value="tag" <?php echo selected($cat_tag, 'tag', false) ?>>Cùng tag</option>
                        </select>
                        <p style="margin-top: 15px;">
                            <input name="vnaicontent_option[open_tab]" id="open_tab" type="checkbox" value="1" <?php checked(isset($this->options['open_tab']) ? 1 : '', 1); ?>>
                            <label for="open_tab">Mở link trong tab mới</label>
                        </p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="tag">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="tag_action_time">Tự động tạo</label>
                    </th>
                    <td>
                        Sau mỗi
                        <input name="vnaicontent_option[tag_action_time]" id="tag_action_time" class="small-text" value="<?php echo isset($this->options['tag_action_time']) ? esc_attr($this->options['tag_action_time']) : '0'; ?>" type="number" min="0"> phút. <code>(Set = 0 sẽ dừng tự động tạo tag)</code>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="tag_action_time">Số lượng</label>
                    </th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[num_tag]" id="num_tag">
                            <?php
                            $num_tag = isset($this->options['num_tag']) ? $this->options['num_tag'] : 99;
                            ?>
                            <option value="99" <?php selected($num_tag, '99'); ?>>AI tự đề xuất</option>
                            <option value="3" <?php selected($num_tag, '3'); ?>>3 tag</option>
                            <option value="4" <?php selected($num_tag, '4'); ?>>4 tag</option>
                            <option value="5" <?php selected($num_tag, '5'); ?>>5 tag</option>
                            <option value="6" <?php selected($num_tag, '6'); ?>>6 tag</option>
                            <option value="7" <?php selected($num_tag, '7'); ?>>7 tag</option>
                            <option value="8" <?php selected($num_tag, '8'); ?>>8 tag</option>
                            <option value="9" <?php selected($num_tag, '9'); ?>>9 tag</option>
                            <option value="10" <?php selected($num_tag, '10'); ?>>10 tag</option>
                            <option value="15" <?php selected($num_tag, '15'); ?>>15 tag</option>
                            <option value="20" <?php selected($num_tag, '20'); ?>>20 tag</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_voice_viettel">Loại trừ các tag</label>
                    </th>
                    <td>
                        <?php $exclude_tag = isset($this->options['exclude_tag']) ? esc_attr($this->options['exclude_tag']) : ''; ?>
                        <textarea name="vnaicontent_option[exclude_tag]" id="exclude_tag" class="large-text" rows="4"><?php echo $exclude_tag; ?></textarea>
                        <p>- Các tag cần loại trừ phân tách nhau bởi dấu <code>,</code></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="meta-des">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="des_action_time">Tự động tạo</label>
                    </th>
                    <td>
                        Sau mỗi
                        <input name="vnaicontent_option[des_action_time]" id="des_action_time" class="small-text" value="<?php echo isset($this->options['des_action_time']) ? esc_attr($this->options['des_action_time']) : '0'; ?>" type="number" min="0"> phút. <code>(Set = 0 sẽ dừng tự động tạo meta description)</code>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="toc">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="toc">Vị trí</label>
                    </th>
                    <td>
                        <?php
                        $toc = isset($this->options['toc']) ? $this->options['toc'] : 0;
                        ?>
                        <select name="vnaicontent_option[toc]" id="toc">
                            <option value="" <?php echo selected($toc, '', false) ?>>Không chèn TOC</option>
                            <option value="1" <?php echo selected($toc, '1', false) ?>>Đầu bài viết</option>
                            <option value="2" <?php echo selected($toc, '2', false) ?>>Trước thẻ H2 đầu tiên</option>
                            <option value="3" <?php echo selected($toc, '3', false) ?>>Sau đoạn văn đầu tiên</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="toc_text">Text</label></th>
                    <td>
                        <?php $toc_text = isset($this->options['toc_text']) ? $this->options['toc_text'] : 'Nội dung bài viết'; ?>
                        <input name="vnaicontent_option[toc_text]" id="toc_text" class="regular-text" placeholder="Nội dung bài viết" value="<?php echo $toc_text; ?>" type="text">
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="filter-keyword">
        <div class="poststuff">
            <div class="postbox">
                <div class="filterkeyword-list">
                    <label for="lang">Ngôn ngữ của keyword</label><br>
                    <select name="lang" id="lang">
                        <?php
                        $lang_arr = ['Anh', 'Việt', 'Ả Rập', 'Bengali', 'Bulgaria', 'Trung', 'Croatia', 'Séc', 'Đan Mạch', 'Hà Lan', 'Estonia', 'Phần Lan', 'Pháp', 'Đức', 'Hy Lạp', 'Do Thái', 'Hindi', 'Hungary', 'Indonesia', 'Ý', 'Nhật', 'Hàn', 'Latvia', 'Lithuania', 'Na Uy', 'Ba Lan', 'Bồ Đào Nha', 'Romania', 'Nga', 'Serbia', 'Slovak', 'Slovenia', 'Tây Ban Nha', 'Swahili', 'Thuỵ Điển', 'Thái', 'Thổ Nhĩ Kỳ', 'Ukraina'];
                        foreach ($lang_arr as $lang_name) {
                            echo '<option value="' . $lang_name . '">' . $lang_name . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="filterkeyword-list">
                    <label for="ai">AI</label><br>
                    <select name="ai" id="ai">
                        <option value="gemini">Gemini</option>
                        <option value="openai">OpenAI</option>
                        <option value="claude">Claude</option>
                        <option value="abacus">Abacus</option>
                    </select>
                </div>
                <div class="filterkeyword-list">
                    <label for="model">Model</label><br>
                    <select name="model" id="model">
                        <?php
                        $model_json = get_option('vnaicontent_model');
                        $models = json_decode($model_json, true);

                        $gemini_model_arr = !empty($models['ai']['gemini_model']) ? $models['ai']['gemini_model'] : ['gemini-1.5-pro-latest' => 'gemini-1.5-pro-latest (8k)'];
                        $openai_model_arr = !empty($models['ai']['openai_model']) ? $models['ai']['openai_model'] : ['chatgpt-4o-latest' => 'chatgpt-4o-latest (16k)'];
                        $claude_model_arr = !empty($models['ai']['claude_model']) ? $models['ai']['claude_model'] : ['claude-3-5-sonnet-20240620' => 'claude-3-5-sonnet-20240620 (4k)'];

                        $options = get_option('vnaicontent_option');
                        $abacus_model_arr = !empty($options['abacus_models_json']) ? json_decode($options['abacus_models_json'], true) : [];

                        //gemini
                        foreach ($gemini_model_arr as $value => $text) {
                            echo '<option class="model-gemini" value="' . $value . '">' . $text . '</option>';
                        }
                        //openai
                        foreach ($openai_model_arr as $value => $text) {
                            echo '<option class="model-openai" value="' . $value . '">' . $text . '</option>';
                        }
                        //claude
                        foreach ($claude_model_arr as $value => $text) {
                            echo '<option class="model-claude" value="' . $value . '">' . $text . '</option>';
                        }
                        //abacus
                        if (!empty($abacus_model_arr)) {
                            foreach ($abacus_model_arr as $model) {
                                echo '<option class="model-abacus" value="' . $model['deploymentId'] . '">' . $model['name'] . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="filterkeyword-list" style="display: block;">
                    <label for="keyword-txt">Upload File txt keyword (Mỗi keyword trên 1 dòng)</label><br>
                    <input type="file" name="keyword_txt" id="keyword-txt" accept=".txt">
                </div>

                <div class="filterkeyword-list" style="display: block;">
                    <label for="topic">Lọc lấy những keyword về</label><br>
                    <input type="text" name="topic" class="regular-text" id="topic" placeholder="công thức, cách làm món ăn">
                </div>

                <div style="margin-bottom: 15px;">
                    <button type="button" class="button filter-keyword-btn">Lọc keyword</button>
                </div>
            </div>

            <div class="postbox" id="filterkeyword-res" style="padding: 0; border: none;"></div>
        </div>
    </div>

    <div class="tab-content" id="clear-cache">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                    </th>
                    <td>
                        <button type="button" id="clear_cache" class="button button-secondary">
                            Xóa Cache
                        </button>
                        <span id="clear_cache_status" style="margin-left: 10px;"></span>
                        <p style="margin-top: 15px">- Các dữ liệu bài viết được cache tự động để tối ưu bao gồm: Related Posts, Table Of Content, Youtube, Audio.</p>
                        <p style="margin-top: 15px">- Khi thực hiện hành động cập nhật 1 bài viết thì toàn bộ cache của bài viết đó sẽ bị xóa</p>
                        <p style="margin-top: 15px">- Click button này sẽ xóa cache của tất cả các bài viết và thực hiện lưu cache lại từ đầu</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>