<div class="vnaicontent-tab-vertical" style="<?php if (!isset($_GET['tab']) || (isset($_GET['tab']) & $_GET['tab'] != 'images')) {
                                                    echo 'display: none;';
                                                } ?>">
    <?php
    $model_json = get_option('vnaicontent_model');
    $models = json_decode($model_json, true);
    ?>
    <div class="tab-links">
        <button type="button" data-tab="images-config" class="button-first">Cấu hình chung</button>
        <button type="button" data-tab="images-huggingface">HuggingFace</button>
        <button type="button" data-tab="images-openai">Dall-E</button>
        <button type="button" data-tab="images-cloudflare">Cloudflare</button>
        <button type="button" data-tab="images-google-search">Google Search</button>
    </div>

    <div class="tab-content tab-content-first" id="images-config">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="img_by">Ảnh tạo bởi</label></th>
                    <td>
                        <p style="margin-bottom: 8px;">
                            <select form="vnaicontent-form" name="vnaicontent_option[img_by]" id="img_by">
                                <?php
                                $img_by = isset($this->options['img_by']) ? $this->options['img_by'] : '';
                                ?>
                                <option value="" <?php selected($img_by, ''); ?>>Không tạo ảnh</option>
                                <option value="openai" <?php selected($img_by, 'openai'); ?>>Dall-E (OpenAI)</option>
                                <option value="cloudflare" <?php selected($img_by, 'cloudflare'); ?>>Cloudflare</option>
                                <option value="huggingface" <?php selected($img_by, 'huggingface'); ?>>HuggingFace</option>
                                <option value="google" <?php selected($img_by, 'google'); ?>>Google Search</option>
                            </select>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="num_img">Số lượng</label></th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[num_img]" id="num_img">
                            <?php
                            $num_img = isset($this->options['num_img']) ? $this->options['num_img'] : '';
                            ?>
                            <option value="99" <?php selected($num_img, '99'); ?>>AI tự đề xuất</option>
                            <option value="1" <?php selected($num_img, '1'); ?>>1 ảnh</option>
                            <option value="2" <?php selected($num_img, '2'); ?>>2 ảnh</option>
                            <option value="3" <?php selected($num_img, '3'); ?>>3 ảnh</option>
                            <option value="4" <?php selected($num_img, '4'); ?>>4 ảnh</option>
                            <option value="1-2" <?php selected($num_img, '1-2'); ?>>1-2 ảnh</option>
                            <option value="1-3" <?php selected($num_img, '1-3'); ?>>1-3 ảnh</option>
                            <option value="1-4" <?php selected($num_img, '1-4'); ?>>1-4 ảnh</option>
                            <option value="2-3" <?php selected($num_img, '2-3'); ?>>2-3 ảnh</option>
                            <option value="2-4" <?php selected($num_img, '2-4'); ?>>2-4 ảnh</option>
                            <option value="3-4" <?php selected($num_img, '3-4'); ?>>3-4 ảnh</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="format_img">Định dạng ảnh</label></th>
                    <td>
                        <?php
                        $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[format_img]" id="format_img">
                            <?php
                            $format_img = isset($this->options['format_img']) ? $this->options['format_img'] : 'jpg';
                            ?>
                            <option value="jpg" <?php selected($format_img, 'jpg'); ?>>jpg</option>
                            <option value="png" <?php selected($format_img, 'png'); ?>>png</option>
                            <option value="webp" <?php selected($format_img, 'webp'); ?>>webp</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="resize_img">Resize</label></th>
                    <td>
                        <?php
                        $resize_img = isset($this->options['resize_img']) ? $this->options['resize_img'] : 0;
                        ?>
                        <input name="vnaicontent_option[resize_img]" id="resize_img" class="small-text" value="<?php echo $resize_img; ?>" type="number" min="0">
                        <code>(Set = 0 sẽ không resize)</code>
                        <p>Thay đổi kích thước ảnh theo chiều ngang nhưng vẫn giữ nguyên tỉ lệ</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="img_action_time">Tự động tạo ảnh</label></th>
                    <td>
                        <?php
                        $img_action_time = isset($this->options['img_action_time']) ? $this->options['img_action_time'] : 0;
                        ?>
                        Tự động tạo ảnh sau mỗi
                        <input name="vnaicontent_option[img_action_time]" id="img_action_time" class="small-text" value="<?php echo $img_action_time; ?>" type="number" min="0"> phút<code>(Set = 0 sẽ dừng)</code> cho các bài viết có trạng thái
                        <select name="vnaicontent_option[status_post_img]">
                            <?php
                            $status_post_img = isset($this->options['status_post_img']) ? $this->options['status_post_img'] : 'jpg';
                            ?>
                            <option value="">Tất cả</option>
                            <option value="publish" <?php selected($status_post_img, 'publish'); ?>>Đã xuất bản</option>
                            <option value="draft" <?php selected($status_post_img, 'draft'); ?>>Bản nháp</option>
                        </select>
                        <hr>
                        <p style="margin: 15px 0;">
                            <input name="vnaicontent_option[only_img_ai]" id="only_img_ai" type="checkbox" value="1" <?php checked(isset($this->options['only_img_ai']) ? 1 : '', 1); ?>>
                            <label for="only_img_ai">Chỉ tạo ảnh cho các bài viết được tạo ra bởi AI</label>
                        </p>
                        <hr>
                        <div>
                            <strong><code>Không tạo ảnh</code></strong> cho các bài viết thuộc các danh mục sau:
                            <?php
                            $cats = get_categories(array(
                                'hide_empty' => false,
                                'orderby'    => 'name',
                                'order'      => 'ASC'
                            ));

                            if (!empty($cats)) {
                                $exclude_cat_img_arr = isset($this->options['exclude_cat_img']) ? explode(',', $this->options['exclude_cat_img']) : array();
                                echo '<ul class="category-list">';
                                foreach ($cats as $exclude_cat_img) {
                                    $post_count = get_term($exclude_cat_img->cat_ID, 'category')->count;
                                    echo '<li><label for="exclude_cat_img-' . $exclude_cat_img->cat_ID . '"><input type="checkbox" name="vnaicontent_option[exclude_cat_img][]" value="' . $exclude_cat_img->cat_ID . '" id="exclude_cat_img-' . $exclude_cat_img->cat_ID . '" ' . (in_array($exclude_cat_img->cat_ID, $exclude_cat_img_arr) ? 'checked' : '') . '>' . $exclude_cat_img->name . ' (' . $post_count . ')</label></li>';
                                }
                                echo '</ul>';
                            }
                            ?>
                        </div>

                        <hr>

                        <p>- Để tránh xung đột với tự tạo bài viết <code>khi bật tạo ảnh tự động thì tính năng tạo bài tự động sẽ bị tắt</code></p>
                        <p>- Chỉ những bài viết <code>không có trạng thái đã tạo ảnh AI</code> mới được đưa vào danh sách để chạy tự động. Nếu muốn tạo lại ảnh tự động hàng loạt cho những bài đã tạo ảnh AI bạn hãy vào <a target="_blank" href="<?php echo admin_url('edit.php'); ?>">danh sách bài viết</a> và chọn hàng loạt bài (<a target="_blank" href="https://www.youtube.com/watch?v=8OWh8KmuQSc">xem video</a>) để <code>xóa trạng thái đã tạo ảnh AI.</code></p>
                        <p>- Bài viết sẽ bị xóa bỏ mọi tệp đính kèm trước khi thực hiện tạo ảnh. Vì vậy hãy cân nhắc khi sử dụng tính năng này cho các bài viết được tạo thủ công (viết tay, không phải tạo bởi AI)</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="images-huggingface">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="huggingface_model_img">Model</label></th>
                    <td>
                        <?php
                        $huggingface_model_img = isset($this->options['huggingface_model_img']) ? $this->options['huggingface_model_img'] : 'stabilityai/stable-diffusion-xl-base-1.0';
                        $huggingface_model_img_arr = !empty($models['img']['huggingface_model_img']) ? $models['img']['huggingface_model_img'] : ['stabilityai/stable-diffusion-xl-base-1.0' => 'stable-diffusion-xl-base-1.0 (1024x1024)'];
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[huggingface_model_img]" id="huggingface_model_img">
                            <?php
                            foreach ($huggingface_model_img_arr as $value => $text) {
                                echo '<option value="' . $value . '" ' . selected($huggingface_model_img, $value, false) . '>' . $text . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="huggingface_token">HuggingFace Token</label></th>
                    <td>
                        <?php $huggingface_token = isset($this->options['huggingface_token']) ? esc_attr($this->options['huggingface_token']) : ''; ?>
                        <textarea name="vnaicontent_option[huggingface_token]" id="huggingface_token" class="large-text" rows="5"><?php echo $huggingface_token; ?></textarea>
                        <?php if ($huggingface_token == ''): ?>
                            <p class="red-text">Chưa có HuggingFace Token!</p>
                        <?php endif ?>
                        <p>- Nếu sử dụng nhiều <a target="_blank" href="https://huggingface.co/settings/tokens">HuggingFace Token</a> thì các Token sẽ được sử dụng xoay vòng. Các Token phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>token1|token2|token3</strong></code></p>
                        <p>- Xem video hướng dẫn lấy <a target="_blank" href="https://www.youtube.com/watch?v=QOk_x4oSVJQ">HuggingFace Token</a></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="images-openai">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="openai_model_img">Model</label></th>
                    <td>
                        <?php
                        $openai_model_img = isset($this->options['openai_model_img']) ? $this->options['openai_model_img'] : 'dall-e-3';
                        $openai_model_img_arr = !empty($models['img']['openai_model_img']) ? $models['img']['openai_model_img'] : ['dall-e-3' => 'Dall-E 3'];
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[openai_model_img]" id="openai_model_img">
                            <?php
                            foreach ($openai_model_img_arr as $value => $text) {
                                echo '<option value="' . $value . '" ' . selected($openai_model_img, $value, false) . '>' . $text . '</option>';
                            }
                            ?>
                        </select>
                        <p>- Nếu sử dụng API của các bên trung gian thì cần xem API đó có thể dùng được những model nào để lựa chọn cho phù hợp</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="openai_api_key_img">OpenAI API</label></th>
                    <td>
                        <?php $openai_api_key_img = isset($this->options['openai_api_key_img']) ? esc_attr($this->options['openai_api_key_img']) : ''; ?>
                        <textarea name="vnaicontent_option[openai_api_key_img]" id="openai_api_key_img" class="large-text" rows="5"><?php echo $openai_api_key_img; ?></textarea>
                        <?php if ($openai_api_key_img == ''): ?>
                            <p class="red-text">Chưa có OpenAI API!</p>
                        <?php endif ?>
                        <p>- Nếu sử dụng nhiều api thì các api sẽ được sử dụng xoay vòng. Các api key phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>key1|key2|key3</strong></code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="openai_img_endpoint">Endpoint</label></th>
                    <td>
                        <?php $openai_img_endpoint = isset($this->options['openai_img_endpoint']) ? esc_attr($this->options['openai_img_endpoint']) : 'https://api.openai.com/v1/images/generations'; ?>
                        <input name="vnaicontent_option[openai_img_endpoint]" id="openai_img_endpoint" class="large-text" value="<?php echo $openai_img_endpoint; ?>" type="text" placeholder="https://api.openai.com/v1/images/generations">
                        <p>- Mặc định của OpenAI là <code>https://api.openai.com/v1/images/generations</code>. Nếu sử dụng API của các bên trung gian thì cần thay thế <code>Endpoint</code> do bên trung gian cung cấp. Lưu ý: Chỉ sử dụng api từ bên trung gian tuân thủ chính xác dữ liệu returns của OpenAI để tránh lỗi hoặc khi gặp lỗi mà không có thông báo rõ ràng, dẫn đến không biết được nguyên nhân gây lỗi</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="images-cloudflare">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="cf_model_img">Model</label></th>
                    <td>
                        <?php
                        $cloudflare_model_img = isset($this->options['cloudflare_model_img']) ? $this->options['cloudflare_model_img'] : '@cf/stabilityai/stable-diffusion-xl-base-1.0';
                        $cloudflare_model_img_arr = !empty($models['img']['cloudflare_model_img']) ? $models['img']['cloudflare_model_img'] : ['@cf/stabilityai/stable-diffusion-xl-base-1.0' => 'stable-diffusion-xl-base-1.0 (1024x1024)'];
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[cloudflare_model_img]" id="cloudflare_model_img">
                            <?php
                            foreach ($cloudflare_model_img_arr as $value => $text) {
                                echo '<option value="' . $value . '" ' . selected($cloudflare_model_img, $value, false) . '>' . $text . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cf_acc_token">Account ID và API Token</label></th>
                    <td>
                        <?php $cf_acc_token = isset($this->options['cf_acc_token']) ? esc_attr($this->options['cf_acc_token']) : ''; ?>
                        <textarea name="vnaicontent_option[cf_acc_token]" id="cf_acc_token" class="large-text" rows="5"><?php echo $cf_acc_token; ?></textarea>
                        <?php if ($cf_acc_token == ''): ?>
                            <p class="red-text">Chưa có Cloudflare Account ID và API Token!</p>
                        <?php endif ?>
                        <p>- Nhập Account ID và API Token nối nhau bởi <code>@</code>. Ví dụ <code><strong>acount_id@api_token</strong></code></p>
                        <p>- Nếu sử dụng nhiều cặp acount_id@api_token thì chúng sẽ được xoay vòng. Các cặp acount_id@api_token phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>acount_id1@api_token1|acount_id2@api_token2</strong></code></p>
                        <p>- Xem video hướng dẫn lấy <a target="_blank" href="https://www.youtube.com/watch?v=wPdPXTLrYWk">Account ID và API Token</a></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="images-google-search">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="gg_search_api_img">Custom Search API</label></th>
                    <td>
                        <?php $gg_search_api_img = isset($this->options['gg_search_api_img']) ? esc_attr($this->options['gg_search_api_img']) : ''; ?>
                        <textarea name="vnaicontent_option[gg_search_api_img]" id="gg_search_api_img" class="large-text" rows="5"><?php echo $gg_search_api_img; ?></textarea>
                        <?php if ($gg_search_api_img == ''): ?>
                            <p class="red-text">Chưa có Custom Search API key!</p>
                        <?php endif ?>
                        <p>- Để sử dụng tính năng này cần <a target="_blank" href="https://console.cloud.google.com/?hl=vi">bật Google Custom Search API và tạo api</a>. Với mỗi tài khoản Google có thể tạo 12 dự án, mỗi dự án chỉ tạo 1 api. Mỗi api được search miễn phí 100 lần/ngày. <a target="_blank" href="https://www.youtube.com/watch?v=moxTam1iJsw">Xem video hướng dẫn</a></p>
                        <p>- Nếu sử dụng nhiều api key thì các api sẽ được sử dụng xoay vòng. Các api key phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>key1|key2|key3</strong></code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gg_search_img_country">Local search</label></th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[gg_search_img_country]" id="gg_search_img_country">
                            <?php
                            $country = array('' => 'Chọn quốc gia search', 'af' => 'Afghanistan', 'al' => 'Albania', 'dz' => 'Algeria', 'as' => 'Samoa', 'ar' => 'Argentina', 'am' => 'Armenia', 'au' => 'Úc', 'at' => 'Áo', 'az' => 'Azerbaijan', 'bd' => 'Bangladesh', 'by' => 'Belarus', 'be' => 'Bỉ', 'bo' => 'Bolivia', 'br' => 'Brazil', 'bn' => 'Brunei', 'bg' => 'Bulgari', 'kh' => 'Campuchia', 'ca' => 'Canada', 'cl' => 'Chile', 'cn' => 'Trung Quốc', 'co' => 'Colombia', 'cr' => 'Costa Rica', 'hr' => 'Croatia', 'cu' => 'Cuba', 'cy' => 'Síp', 'cz' => 'Séc', 'dk' => 'Đan Mạch', 'ec' => 'Ecuador', 'eg' => 'Ai Cập', 'sv' => 'El Salvador', 'ee' => 'Estonia', 'fi' => 'Phần Lan', 'fr' => 'Pháp', 'ge' => 'Georgia', 'de' => 'Đức', 'gr' => 'Hy Lạp', 'gt' => 'Guatemala', 'hn' => 'Honduras', 'hk' => 'Hong Kong', 'hu' => 'Hungary', 'is' => 'Iceland', 'in' => 'Ấn Độ', 'id' => 'Indonesia', 'ir' => 'Iran', 'iq' => 'Iraq', 'ie' => 'Ireland', 'il' => 'Israel', 'it' => 'Ý', 'jm' => 'Jamaica', 'jp' => 'Nhật Bản', 'jo' => 'Jordan', 'kz' => 'Kazakhstan', 'ke' => 'Kenya', 'kp' => 'Triều Tiên', 'kr' => 'Hàn Quốc', 'kw' => 'Kuwait', 'kg' => 'Kyrgyzstan', 'la' => 'Lào', 'lv' => 'Latvia', 'lb' => 'Liban', 'lt' => 'Lithuania', 'lu' => 'Luxembourg', 'mo' => 'Macao', 'my' => 'Malaysia', 'mv' => 'Maldives', 'mt' => 'Malta', 'mx' => 'Mexico', 'mc' => 'Monaco', 'mn' => 'Mông Cổ', 'ma' => 'Morocco', 'mz' => 'Mozambique', 'mm' => 'Myanmar', 'np' => 'Nepal', 'nl' => 'Hà Lan', 'nz' => 'New Zealand', 'ni' => 'Nicaragua', 'ng' => 'Nigeria', 'no' => 'Na Uy', 'om' => 'Oman', 'pk' => 'Pakistan', 'pa' => 'Panama', 'pg' => 'Papua New Guinea', 'py' => 'Paraguay', 'pe' => 'Peru', 'ph' => 'Philippines', 'pl' => 'Ba Lan', 'pt' => 'Bồ Đào Nha', 'pr' => 'Puerto Rico', 'qa' => 'Qatar', 'ro' => 'Rumani', 'ru' => 'Nga', 'sa' => 'Ả Rập Xê Út', 'sg' => 'Singapore', 'sk' => 'Slovakia', 'si' => 'Slovenia', 'za' => 'Nam Phi', 'es' => 'Tây Ban Nha', 'lk' => 'Sri Lanka', 'sd' => 'Sudan', 'se' => 'Thụy Điển', 'ch' => 'Thuỵ Sĩ', 'sy' => 'Syria', 'tw' => 'Đài Loan', 'tj' => 'Tajikistan', 'tz' => 'Tanzania', 'th' => 'Thái Lan', 'tr' => 'Thổ Nhĩ Kỳ', 'tm' => 'Turkmenistan', 'ua' => 'Ukraina', 'ae' => 'Ả Rập Thống nhất', 'uk' => 'Vương Quốc Anh', 'us' => 'Mỹ', 'uy' => 'Uruguay', 'uz' => 'Uzbekistan', 've' => 'Venezuela', 'vn' => 'Việt Nam', 'ye' => 'Yemen', 'zm' => 'Zambia', 'zw' => 'Zimbabwe');

                            $country_cur = isset($this->options['gg_search_img_country']) ? esc_attr($this->options['gg_search_img_country']) : '';

                            foreach ($country as $code => $name) {
                                echo '<option value="' . $code . '" ' . selected($country_cur, $code, false) . '>' . $name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gg_search_img_lang">Language search</label></th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[gg_search_img_lang]" id="gg_search_img_lang">
                            <?php
                            $lang = array('' => 'Chọn ngôn ngữ search', 'af' => 'Afrikaans', 'sq' => 'Albania', 'sm' => 'Amhara', 'ar' => 'Ả Rập', 'az' => 'Azerbaijan', 'eu' => 'Basque', 'be' => 'Belarus', 'bn' => 'Bengal', 'bh' => 'Bihar', 'bs' => 'Bosnia', 'bg' => 'Bungary', 'ca' => 'Catalan', 'zh-CN' => 'Trung (Giản thể)', 'zh-TW' => 'Trung (Phồn thể)', 'hr' => 'Croatia', 'cs' => 'Séc', 'da' => 'Đan Mạch', 'nl' => 'Hà Lan', 'en' => 'Anh', 'eo' => 'Esperanto', 'et' => 'Estonia', 'fo' => 'Faroese', 'fi' => 'Phần Lan', 'fr' => 'Pháp', 'fy' => 'Frisia', 'gl' => 'Galic', 'ka' => 'Gruzia', 'de' => 'Đức', 'el' => 'Hy Lạp', 'gu' => 'Gujarat', 'iw' => 'Do Thái', 'hi' => 'Hindi', 'hu' => 'Hungary', 'is' => 'Iceland', 'id' => 'Indonesia', 'ia' => 'Interlingua', 'ga' => 'Ireland', 'it' => 'Ý', 'ja' => 'Nhật', 'jw' => 'Java', 'kn' => 'Kannada', 'ko' => 'Hàn', 'la' => 'Latinh', 'lv' => 'Latvia', 'lt' => 'Lithuania', 'mk' => 'Macedonia', 'ms' => 'Malay', 'ml' => 'Malayam', 'mt' => 'Malta', 'mr' => 'Maratha', 'ne' => 'Nepal', 'no' => 'Na Uy', 'oc' => 'Occitan', 'fa' => 'Ba Tư', 'pl' => 'Ba Lan', 'pt-PT' => 'Bồ Đào Nha', 'pa' => 'Punjab', 'ro' => 'Romania', 'ru' => 'Nga', 'gd' => 'Gael Scotland', 'sr' => 'Serbia', 'si' => 'Sinhala', 'sk' => 'Slovak', 'sl' => 'Slovenia', 'es' => 'Tây Ban Nha', 'su' => 'Sudan', 'sw' => 'Swahili', 'sv' => 'Thuỵ Điển', 'tl' => 'Tagalog', 'ta' => 'Tamil', 'te' => 'Telugu', 'th' => 'Thái', 'ti' => 'Tigrinya', 'tr' => 'Thổ Nhĩ Kỳ', 'uk' => 'Ukraina', 'ur' => 'Urdu', 'uz' => 'Uzbek', 'vi' => 'Việt', 'cy' => 'Wales', 'xh' => 'Xhosa', 'zu' => 'Zulu');

                            $lang_cur = isset($this->options['gg_search_img_lang']) ? $this->options['gg_search_img_lang'] : '';

                            foreach ($lang as $code => $name) {
                                echo '<option value="' . $code . '" ' . selected($lang_cur, $code, false) . '>' . $name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gg_search_img_country_publish">Quốc gia xuất bản</label></th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[gg_search_img_country_publish]" id="gg_search_img_country_publish">
                            <?php
                            $country = array('' => 'Chọn quốc gia ảnh xuất bản', 'countryAF' => 'Afghanistan', 'countryAL' => 'Albania', 'countryDZ' => 'Algeria', 'countryAS' => 'Samoa thuộc Hoa Kỳ', 'countryAD' => 'Andorra', 'countryAO' => 'Angola', 'countryAI' => 'Anguilla', 'countryAQ' => 'Antarctica', 'countryAG' => 'Antigua & Barbuda', 'countryAR' => 'Argentina', 'countryAM' => 'Armenia', 'countryAW' => 'Aruba', 'countryAU' => 'Úc', 'countryAT' => 'Áo', 'countryAZ' => 'Azerbaijan', 'countryBS' => 'Bahamas', 'countryBH' => 'Bahrain', 'countryBD' => 'Bangladesh', 'countryBB' => 'Barbados', 'countryBY' => 'Belarus', 'countryBE' => 'Bỉ', 'countryBZ' => 'Belize', 'countryBJ' => 'Benin', 'countryBT' => 'Bhutan', 'countryBO' => 'Bolivia', 'countryBA' => 'Bosnia & Herzegovina', 'countryBW' => 'Botswana', 'countryBR' => 'Brazil', 'countryCF' => 'Cộng hoà Trung Phi', 'countryTD' => 'Chad', 'countryCL' => 'Chile', 'countryCN' => 'Trung Quốc', 'countryCO' => 'Colombia', 'countryKM' => 'Comoros', 'countryCG' => 'Congo', 'countryCD' => 'Congo (Dân chủ)', 'countryCR' => 'Costa Rica', 'countryCI' => 'Bờ biển Ngà', 'countryHR' => 'Croatia', 'countryCU' => 'Cuba', 'countryCY' => 'Síp', 'countryCZ' => 'Czechia', 'countryDK' => 'Đan Mạch', 'countryDJ' => 'Djibouti', 'countryDM' => 'Dominica', 'countryDO' => 'Dominica (Cộng hoà)', 'countryEC' => 'Ecuador', 'countryEG' => 'Ai Cập', 'countrySV' => 'El Salvador', 'countryGQ' => 'Guinea Xích đạo', 'countryER' => 'Eritrea', 'countryEE' => 'Estonia', 'countryET' => 'Ethiopia', 'countryFK' => 'Falkland', 'countryFO' => 'Faroe', 'countryFJ' => 'Fiji', 'countryFI' => 'Phần Lan', 'countryFR' => 'Pháp', 'countryGA' => 'Gabon', 'countryGM' => 'Gambia', 'countryGE' => 'Georgia', 'countryDE' => 'Đức', 'countryGH' => 'Ghana', 'countryGI' => 'Gibraltar', 'countryGR' => 'Hy Lạp', 'countryGL' => 'Greenland', 'countryGD' => 'Grenada', 'countryGT' => 'Guatemala', 'countryGN' => 'Guinea', 'countryGW' => 'Guinea-Bissau', 'countryGY' => 'Guyana', 'countryHT' => 'Haiti', 'countryHN' => 'Honduras', 'countryHK' => 'Hong Kong', 'countryHU' => 'Hungary', 'countryIS' => 'Iceland', 'countryIN' => 'Ấn Độ', 'countryID' => 'Indonesia', 'countryIR' => 'Iran', 'countryIQ' => 'Iraq', 'countryIE' => 'Ireland', 'countryIL' => 'Israel', 'countryIT' => 'Ý', 'countryJM' => 'Jamaica', 'countryJP' => 'Nhật Bản', 'countryJO' => 'Jordan', 'countryKZ' => 'Kazakhstan', 'countryKE' => 'Kenya', 'countryKI' => 'Kiribati', 'countryKP' => 'Triều Tiên', 'countryKR' => 'Hàn Quốc', 'countryKW' => 'Kuwait', 'countryKG' => 'Kyrgyzstan', 'countryLA' => 'Lào', 'countryLV' => 'Latvia', 'countryLB' => 'Liban', 'countryLS' => 'Lesotho', 'countryLR' => 'Liberia', 'countryLY' => 'Libya', 'countryLI' => 'Liechtenstein', 'countryLT' => 'Lithuania', 'countryLU' => 'Luxembourg', 'countryMK' => 'Macedonia', 'countryMG' => 'Madagascar', 'countryMW' => 'Malawi', 'countryMY' => 'Malaysia', 'countryMV' => 'Maldives', 'countryML' => 'Mali', 'countryMT' => 'Malta', 'countryMR' => 'Mauritania', 'countryMU' => 'Mauritius', 'countryMX' => 'Mexico', 'countryFM' => 'Micronesia', 'countryMD' => 'Moldova', 'countryMC' => 'Monaco', 'countryMN' => 'Mông Cổ', 'countryMS' => 'Montserrat', 'countryMA' => 'Morocco', 'countryMZ' => 'Mozambique', 'countryMM' => 'Myanmar', 'countryNA' => 'Namibia', 'countryNR' => 'Nauru', 'countryNP' => 'Nepal', 'countryNL' => 'Hà Lan', 'countryNC' => 'New Caledonia', 'countryNZ' => 'New Zealand', 'countryNI' => 'Nicaragua', 'countryNE' => 'Niger', 'countryNG' => 'Nigeria', 'countryNU' => 'Niue', 'countryNF' => 'Norfolk', 'countryMP' => 'Mariana', 'countryNO' => 'Na Uy', 'countryOM' => 'Oman', 'countryPK' => 'Pakistan', 'countryPW' => 'Palau', 'countryPS' => 'Palestine', 'countryPA' => 'Panama', 'countryPG' => 'Papua New Guinea', 'countryPY' => 'Paraguay', 'countryPE' => 'Peru', 'countryPH' => 'Philippines', 'countryPL' => 'Ba Lan', 'countryPT' => 'Bồ Đào Nha', 'countryPR' => 'Puerto Rico', 'countryQA' => 'Qatar', 'countryRE' => 'Reunion', 'countryRO' => 'Rumani', 'countryRU' => 'Nga', 'countryRW' => 'Rwanda', 'countryWS' => 'Samoa', 'countrySM' => 'San Marino', 'countrySA' => 'Ả Rập Xê Út', 'countrySN' => 'Senegal', 'countrySC' => 'Seychelles', 'countrySL' => 'Sierra Leone', 'countrySG' => 'Singapore', 'countrySK' => 'Slovakia', 'countrySI' => 'Slovenia', 'countrySB' => 'Solomon', 'countrySO' => 'Somalia', 'countryZA' => 'Nam Phi', 'countryES' => 'Tây Ban Nha', 'countryLK' => 'Sri Lanka', 'countrySD' => 'Sudan', 'countrySR' => 'Suriname', 'countrySZ' => 'Eswatini', 'countrySE' => 'Thụy Điển', 'countryCH' => 'Thụy Sĩ', 'countrySY' => 'Syria', 'countryTW' => 'Đài Loan', 'countryTJ' => 'Tajikistan', 'countryTZ' => 'Tanzania', 'countryTH' => 'Thái Lan', 'countryTG' => 'Togo', 'countryTK' => 'Tokelau', 'countryTO' => 'Tonga', 'countryTT' => 'Trinidad & Tobago', 'countryTN' => 'Tunisia', 'countryTR' => 'Thổ Nhĩ Kỳ', 'countryTM' => 'Turkmenistan', 'countryTC' => 'Turks & Caicos', 'countryTV' => 'Tuvalu', 'countryUG' => 'Uganda', 'countryUA' => 'Ukraina', 'countryAE' => 'UAE', 'countryUK' => 'Anh', 'countryUS' => 'Mỹ', 'countryUY' => 'Uruguay', 'countryUZ' => 'Uzbekistan', 'countryVU' => 'Vanuatu', 'countryVE' => 'Venezuela', 'countryVN' => 'Việt Nam', 'countryYE' => 'Yemen', 'countryZM' => 'Zambia', 'countryZW' => 'Zimbabwe');

                            $country_cur = isset($this->options['gg_search_img_country_publish']) ? $this->options['gg_search_img_country_publish'] : '';

                            foreach ($country as $code => $name) {
                                echo '<option value="' . $code . '" ' . selected($country_cur, $code, false) . '>' . $name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="domain_img">Nguồn ảnh</label></th>
                    <td>
                        <?php $domain_img = isset($this->options['domain_img']) ? esc_attr($this->options['domain_img']) : ''; ?>
                        <input name="vnaicontent_option[domain_img]" id="domain_img" class="regular-text" value="<?php echo $domain_img; ?>" type="text">
                        <p>- Nếu để trống sẽ thực hiện google search và lấy ảnh</p>
                        <p>- Nếu nhập 1 domain thì sẽ chỉ search ảnh từ domain đó. Lưu ý chỉ nhập duy nhất 1 domain, không thể nhập nhiều domain cùng lúc. Ví dụ, nếu muốn lấy ảnh từ pixabay thì nhập vào domain <code><strong>pixabay.com</strong></code></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>