<div style="display: none;" class="notice settings-error is-dismissible"><p><strong></strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"></span></button></div>

<div style="<?php if(!isset($_GET['tab']) || (isset($_GET['tab']) & $_GET['tab'] != 'prompts')){echo 'display: none;';} ?>">
    <div class="prompt-bound">
        <div class="create-prompt" style="border: 1px solid #c5c7c9; padding: 15px; margin-top:15px">
            <div class="create-prompt-item">
                <label for="ai">AI</label><br>
                <select name="ai" id="ai">
                    <option value="gemini">Gemini</option>
                    <option value="openai">OpenAI</option>
                    <option value="claude">Claude</option>
                    <option value="abacus">Abacus</option>
                </select>
            </div>
            <div class="create-prompt-item">
                <label for="model">Model</label><br>
                <select name="model" id="model">
                    <?php
                        $model_json = get_option('vnaicontent_model');
                        $models = json_decode($model_json, true);

                        $gemini_model_arr = !empty($models['ai']['gemini_model'])?$models['ai']['gemini_model']:['gemini-1.5-pro-latest' => 'gemini-1.5-pro-latest (8k)'];
                        $openai_model_arr = !empty($models['ai']['openai_model'])?$models['ai']['openai_model']:['chatgpt-4o-latest' => 'chatgpt-4o-latest (16k)'];
                        $claude_model_arr = !empty($models['ai']['claude_model'])?$models['ai']['claude_model']:['claude-3-5-sonnet-20240620' => 'claude-3-5-sonnet-20240620 (4k)'];

                        $abacus_model_arr = !empty($this->options['abacus_models_json'])?json_decode($this->options['abacus_models_json'], true):[];

                        //gemini
                        foreach ($gemini_model_arr as $value => $text) {
                            echo '<option class="model-gemini" value="' . $value . '">' . $text . '</option>';
                        }
                        //openai
                        foreach ($openai_model_arr as $value => $text) {
                            echo '<option class="model-openai" value="' . $value . '">' . $text . '</option>';
                        }
                        //claude
                        foreach ($claude_model_arr as $value => $text) {
                            echo '<option class="model-claude" value="' . $value . '">' . $text . '</option>';
                        }
                        //abacus
                        if (!empty($abacus_model_arr)) {
                            foreach ($abacus_model_arr as $model) {
                                echo '<option class="model-abacus" value="' . $model['deploymentId'] . '">' . $model['name'] . '</option>';
                            }
                        }
                    ?>
                </select>
            </div>
            <div class="create-prompt-item">
                <label for="prompt-topic">Chủ đề</label>
                <input id="prompt-topic" class="regular-text" value="" type="text" placeholder="ẩm thực">
            </div>
            <div class="create-prompt-item">
                <input id="prompt-is-detail" type="checkbox">
                <label for="prompt-is-detail">Tạo quy trình viết bài chi tiết</label>
            </div>
            <div class="create-prompt-item">
                <button type="button" class="button btn-create" id="btn-create-ai-as">Tạo vai trò AI</button>
                <button type="button" class="button btn-create" id="btn-create-prompt">Tạo prompt</button>
            </div>
        </div>
        <div id="res-prompt" class="create-prompt">
            - Tính năng này sử dụng AI để tạo ra các <strong>Vai trò AI</strong> và <strong>Prompt</strong> mẫu theo chủ đề bạn nhập. Nên sử dụng <strong>Claude</strong> sẽ cho kết quả tốt hơn các AI khác
            <br><br>
            - Lưu ý đây chỉ là prompt mẫu, bạn nên edit lại cho phù hợp với mục đích, nhu cầu sử dụng của mình để có được prompt tối ưu
        </div>
    </div>
    
    <div class="poststuff">
        <div class="postbox">
            <div class="postbox-header">
                <h2>Vai trò AI</h2>
            </div>
            <div class="inside">
                <table class="form-table">
                    <tbody>
                        <tr>
                            <td>
                            <?php
                                $categories = get_categories(array(
                                    'hide_empty' => false,
                                    'hierarchical' => true
                                ));

                                $str_cate = '<p><label for="ai_as"><strong>All (Chung cho tất cả danh mục)</strong></label><textarea name="vnaicontent_option[ai_as]" id="ai_as" class="large-text" rows="4">' . (isset($this->options['ai_as'])?esc_attr($this->options['ai_as']):'') . '</textarea></p>';
                                foreach ($categories as $category) {
                                    $ai_as_cate = get_term_meta($category->term_id, 'ai_as', true);
                                    $str_cate .= '<p>';
                                        $str_cate .= '<label for="ai_as_cate' . $category->term_id . '"><strong>' . esc_html($category->name) . '</strong></label>';
                                        $str_cate .= '<textarea name="vnaicontent_option[ai_as_cate][' . $category->term_id . ']" id="ai_as_cate' . $category->term_id . '" class="large-text" rows="4">' . $ai_as_cate . '</textarea>';
                                    $str_cate .= '</p>';
                                }
                                echo $str_cate;
                            ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Set vai trò AI cho từng danh mục thì khi tạo bài viết vai trò AI sẽ lấy tương ứng theo danh mục đó. Nếu để trống sẽ lấy vai trò AI chung<code><strong>All</code></strong>. Prompt này chỉ sử dụng <code><strong>tiếng Việt</strong></code></p>
                                <p>Ví dụ: <code>Với tư cách là nhà sáng tạo nội dung tại website "<strong><?php echo get_bloginfo('name'); ?></strong>", bạn là chuyên gia giải mã giấc mơ am hiểu sâu sắc văn hóa và tâm linh người Việt, đặc biệt là mối liên hệ giữa giấc mơ và các con số may mắn (lô đề, xổ số).</code></p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="postbox">
            <div class="postbox-header">
                <h2>Prompt</h2>
            </div>
            <div class="inside">
                <table class="form-table">
                    <tbody>
                        <tr>
                            <td>
                                <?php
                                    $categories = get_categories(array(
                                        'hide_empty' => false,
                                        'hierarchical' => true
                                    ));

                                    $str_cate = '<p><label for="prompt"><strong>All (Chung cho tất cả danh mục)</strong></label><textarea name="vnaicontent_option[prompt]" id="prompt" class="large-text" rows="4">' . (isset($this->options['prompt'])?esc_attr($this->options['prompt']):'') . '</textarea></p>';
                                    foreach ($categories as $category) {
                                        $prompt_cate = get_term_meta($category->term_id, 'prompt', true);
                                        $str_cate .= '<p>';
                                            $str_cate .= '<label for="prompt_cate' . $category->term_id . '"><strong>' . esc_html($category->name) . '</strong></label>';
                                            $str_cate .= '<textarea name="vnaicontent_option[prompt_cate][' . $category->term_id . ']" id="prompt_cate' . $category->term_id . '" class="large-text" rows="4">' . $prompt_cate . '</textarea>';
                                        $str_cate .= '</p>';
                                    }
                                    echo $str_cate;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p><strong><code>Vui lòng đọc kỹ phần dưới đây để giảm tình trạng không tạo được bài viết:</code></strong></p>
                                <p>- Ở trên là các prompt tương ứng với từng danh mục, nó là yêu cầu về nội dung bài viết. Nếu không nhập prompt cho các danh mục thì sẽ sử dụng prompt chung <code><strong>All</strong></code> cho tất cả các danh mục.</p> 
                                <p>- Prompt chỉ sử dụng <code><strong>tiếng Việt</strong></code>. Ví dụ:</p>
                                <pre style="background: #e5ddc4; padding: 5px; margin-top:5px; white-space: pre-wrap;">
## Nghiên cứu từ khóa:
- Phân tích sâu từ khóa chính "[keyword]":
  + Xác định ý định tìm kiếm (informational, navigational, transactional)
  + Đánh giá khối lượng tìm kiếm và độ khó cạnh tranh
- Xây dựng danh sách từ khóa mở rộng:
  + Từ khóa đuôi dài (long-tail keywords)
  + Từ khóa và cụm từ liên quan đến chủ đề
  + Biến thể và đồng nghĩa của từ khóa chính
  + Thuật ngữ chuyên ngành liên quan
- Xác định các chủ đề và khía cạnh phụ của vấn đề chính
- Tìm kiếm các câu hỏi thường gặp liên quan đến chủ đề
- Nghiên cứu xu hướng tìm kiếm và tính thời vụ (nếu có)
- Phân tích ngôn ngữ và cách diễn đạt của đối tượng mục tiêu
- Xem xét các yếu tố văn hóa ảnh hưởng đến cách sử dụng từ khóa

## Tối ưu SEO:
- Tối thiểu 1000 từ (có thể điều chỉnh để phù hợp)
- Mật độ từ khóa chính 1-2%
- Sử dụng từ khóa phụ, ngữ nghĩa và LSI (Latent Semantic Indexing - Lập chỉ mục ngữ nghĩa tiềm ẩn, là các từ khóa liên quan về mặt ngữ nghĩa)
- Đảm bảo đáp ứng tiêu chí E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness - Kinh nghiệm, Chuyên môn, Uy tín, Đáng tin cậy)
- Tối ưu cho Helpful Content Update (Cập nhật Nội dung Hữu ích của Google, tập trung vào việc tạo ra nội dung chất lượng cao, hữu ích cho người dùng)
- Tối ưu cho tìm kiếm bằng giọng nói: 
  + Sử dụng câu hỏi tự nhiên làm tiêu đề phụ
  + Cung cấp câu trả lời ngắn gọn (30-40 từ)
  + Tập trung vào từ khóa long-tail và conversational
  + Tối ưu cho câu hỏi 5W1H liên quan đến "[keyword]"
- <strong class="red-text">[internal_links]</strong>

## Cấu trúc:
1. <strong class="red-text">Tiêu đề bài viết (H1 #)</strong>: Hấp dẫn, 50-60 ký tự, bao gồm từ khóa chính "[keyword]"
2. Đoạn mở đầu: Giới thiệu tổng quan, bao gồm từ khóa chính "[keyword]" trong 50 từ đầu tiên, không sử dụng tiêu đề phụ
3. Nội dung chính:
   - <strong class="red-text">Sử dụng H2 (##) và H3 (###) cho các tiêu đề phụ</strong>
   - Tích hợp từ khóa chính vào ít nhất một tiêu đề phụ
   - Phân bố từ khóa chính và phụ đều trong nội dung
   - Sử dụng dấu đầu dòng cho các điểm chính
   - Sử dụng danh sách đánh số cho hướng dẫn từng bước
   - Áp dụng in đậm và in nghiêng để nhấn mạnh
   - Sử dụng blockquote cho thông tin nổi bật
   - Thêm bảng để trình bày thông tin hoặc so sánh (nếu phù hợp)
   - Bổ sung trích dẫn từ chuyên gia giả định:
     + Tạo nhân vật chuyên gia bao gồm tên đầy đủ phù hợp với ngôn ngữ chủ đề và văn hóa
     + Viết 2-3 trích dẫn ngắn gọn, thực tế, và có giá trị để minh họa điểm chính hoặc cung cấp góc nhìn thực tế
     + Phân bố trích dẫn đều trong bài viết để tăng tính đáng tin cậy
4. Kết luận: Tóm tắt điểm chính, khuyến khích hành động, bao gồm từ khóa chính "[keyword]"
5. FAQ (5-7 câu hỏi) (nếu phù hợp với chủ đề và độ dài bài viết)

## Phong cách:
- Sử dụng tiếng Anh tự nhiên, gần gũi, như đang trò chuyện trực tiếp với người đọc
- Áp dụng ngôn ngữ hàng ngày, thành ngữ và cách nói thông dụng trong tiếng Anh
- Sử dụng ví dụ đời thường và so sánh dễ hiểu để minh họa các điểm phức tạp
- Kết hợp câu hỏi tu từ và lời mời gọi tương tác để tạo cảm giác đối thoại
- Duy trì cân bằng giữa tính chuyên môn và sự dễ hiểu
- Sử dụng cấu trúc câu đa dạng và luồng ngôn ngữ tự nhiên
- Áp dụng kỹ thuật viết giống người bản ngữ, sử dụng giai thoại cá nhân và từ vựng đa dạng

## Chất lượng nội dung:
- Đảm bảo độ chính xác và giá trị thông tin
- Đảm bảo ngữ pháp, chính tả, tính mạch lạc và logic
- Đảm bảo tính độc đáo và tránh đạo văn
- Cung cấp thông tin độc đáo và hữu ích
- Đáp ứng nhu cầu và giải quyết vấn đề của người đọc
- Cung cấp thông tin cập nhật và liên quan đến xu hướng hiện tại (nếu có)
- Đảm bảo tính nhất quán trong giọng điệu và phong cách viết xuyên suốt bài viết

## Lưu ý Quan trọng:
- Đảm bảo tính nhất quán giữa các phần của bài viết, đặc biệt là giữa tiêu đề, đoạn mở đầu, nội dung chính và kết luận
                                </pre>
                                <p>- Prompt nên sử dụng định dạng markdown và đánh số thứ tự như mẫu trên, đặc biệt cần mô tả rõ ràng tiêu đề bài viết là h1 (#), các tiêu đề phụ h2 (##), h3 (###) ... Việc này giúp AI hiểu rõ cấu trúc bài viết tránh dẫn đến tạo bài viết có cấu trúc không hợp lệ (tiêu đề không phải thẻ h1 ...)</p>
                                <p>- Để AI tự thêm các liên kết nội bộ đến các bài viết khác bạn có thể thêm mã <code>[internal_links]</code> vào prompt ở vị trí thích hợp. Ngoài ra cũng có thể sử dụng mã <code>[keyword]</code> trong prompt:</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>