<h1 class="wp-heading-inline">VnAIContent</h1>
<p class="subsubsub" style="float: none; font-size: 15px;">
    <a href="<?php echo VNAICONTENT_ADMIN_PAGE; ?>" class="<?php if (!isset($_GET['tab'])) {
                                                                echo 'current';
                                                            } ?>">Cài đặt</a> |
    <a class="<?php if (isset($_GET['tab']) && $_GET['tab'] == 'prompts') {
                    echo 'current';
                } ?>" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=prompts'; ?>">Prompts</a> |
    <a class="<?php if (isset($_GET['tab']) && $_GET['tab'] == 'images') {
                    echo 'current';
                } ?>" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=images'; ?>">Hình ảnh</a> |
    <a class="<?php if (isset($_GET['tab']) && $_GET['tab'] == 'audio') {
                    echo 'current';
                } ?>" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=audio'; ?>">Audio</a> |
    <a class="<?php if (isset($_GET['tab']) && $_GET['tab'] == 'keywords') {
                    echo 'current';
                } ?>" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=keywords'; ?>">Keywords</a> |
    <a class="<?php if (isset($_GET['tab']) && $_GET['tab'] == 'tools') {
                    echo 'current';
                } ?>" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=tools'; ?>">Công cụ</a> |
    <a class="<?php if (isset($_GET['tab']) && $_GET['tab'] == 'notes') {
                    echo 'current';
                } ?>" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=notes'; ?>">Lưu ý</a>
</p>

<div class="vnaicontent">
    <div class="column-left">
        <?php
        $cmd = isset($_GET['cmd']) ? $_GET['cmd'] : '';
        if (!isset($_GET['tab']) || $_GET['tab'] == 'prompts' || $_GET['tab'] == 'images' || $_GET['tab'] == 'audio' || $_GET['tab'] == 'tools' || $_GET['tab'] == 'socials') {
            echo '<form method="post" action="options.php" id="vnaicontent-form">';
            require_once VNAICONTENT_PATH . 'layout/settings.php';
            require_once VNAICONTENT_PATH . 'layout/prompts.php';
            require_once VNAICONTENT_PATH . 'layout/images.php';
            require_once VNAICONTENT_PATH . 'layout/audio.php';
            require_once VNAICONTENT_PATH . 'layout/tools.php';

            submit_button();
            settings_fields('vnaicontent_option_group');
            do_settings_sections('vnaicontent');
            echo '</form>';
        } else {
            if ($_GET['tab'] == 'keywords') {
                require_once VNAICONTENT_PATH . 'layout/keywords.php';
            } elseif ($_GET['tab'] == 'notes') {
                require_once VNAICONTENT_PATH . 'layout/notes.php';
            }
        }
        ?>
    </div>
    <div class="column-right">
        <?php
        if (get_option('vnaicontent_warning') != '') {
            echo '<div class="vnaicontent-warning">' . get_option('vnaicontent_warning') . '</div>';
        }
        ?>
        <div id="mess-bound" class="text-center" style="margin: 30px 0 20px 0;">
            <?php
            $mess = get_transient('vnaicontent_mess');
            $mess_time  = get_transient('vnaicontent_mess_time');
            if ($mess && $mess_time > 0 && $mess_time <= time()) {
                echo '<span class="blinker" id="mess-time" data-mess-time="' . $mess_time . '"></span> s trước - <span id="mess">' . $mess . '</span>';
            }
            ?>
        </div>
    </div>
</div>