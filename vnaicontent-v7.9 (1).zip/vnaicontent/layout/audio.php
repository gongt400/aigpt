<div class="vnaicontent-tab-vertical audio" style="<?php if (!isset($_GET['tab']) || (isset($_GET['tab']) & $_GET['tab'] != 'audio')) {
                                                        echo 'display: none;';
                                                    } ?>">
    <div class="tab-links">
        <button type="button" data-tab="audio-config" class="button-first">Cấu hình chung</button>
        <button type="button" data-tab="audio-ai">AI</button>
        <button type="button" data-tab="audio-prompt">Prompt</button>
        <button type="button" data-tab="audio-podcast">Podcast</button>
    </div>

    <div class="tab-content tab-content-first" id="audio-config">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="audio_type">Audio tạo bởi</label></th>
                    <td>
                        <?php $audio_type = isset($this->options['audio_type']) ? $this->options['audio_type'] : ''; ?>
                        <select name="vnaicontent_option[audio_type]" id="audio_type">
                            <option value="" <?php selected($audio_type, ''); ?>>Không tạo audio</option>
                            <option value="viettel" <?php echo selected($audio_type, 'viettel', false) ?>>Viettel</option>
                            <option value="fpt" <?php echo selected($audio_type, 'fpt', false) ?>>FPT</option>
                            <option value="zalo" <?php echo selected($audio_type, 'zalo', false) ?>>Zalo</option>
                            <option value="google" <?php echo selected($audio_type, 'google', false) ?>>Google</option>
                            <option value="openai" <?php echo selected($audio_type, 'openai', false) ?>>OpenAI</option>
                            <option value="azure_speech" <?php echo selected($audio_type, 'azure_speech', false) ?>>Azure Speech</option>
                            <option value="azure_openai" <?php echo selected($audio_type, 'azure_openai', false) ?>>Azure OpenAI</option>
                            <option value="vbee" <?php echo selected($audio_type, 'vbee', false) ?>>Vbee</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="audio_action_time">Tự động tạo audio</label></th>
                    <td>
                        <?php
                        $audio_action_time = isset($this->options['audio_action_time']) ? $this->options['audio_action_time'] : 0;
                        $audio_status_post = isset($this->options['audio_status_post']) ? $this->options['audio_status_post'] : 'publish';
                        ?>
                        Tự động tạo audio sau mỗi
                        <input name="vnaicontent_option[audio_action_time]" id="audio_action_time" class="small-text" value="<?php echo $audio_action_time; ?>" type="number" min="0"> phút<code>(Set = 0 sẽ dừng)</code> cho các bài viết có trạng thái
                        <select name="vnaicontent_option[audio_status_post]">
                            <option value="">Tất cả</option>
                            <option value="publish" <?php selected($audio_status_post, 'publish'); ?>>Đã xuất bản</option>
                            <option value="draft" <?php selected($audio_status_post, 'draft'); ?>>Bản nháp</option>
                        </select>
                        <hr>
                        <input name="vnaicontent_option[audio_check_thumb]" id="audio_check_thumb" type="checkbox" value="1" <?php checked(isset($this->options['audio_check_thumb']) ? 1 : '', 1); ?>>
                        <label for="audio_check_thumb">Chỉ tạo audio cho bài viết có thumb</label>
                        <hr>
                        <div>
                            <strong><code>Không tạo audio</code></strong> cho các bài viết thuộc các danh mục sau:
                            <?php
                            $cats = get_categories(array(
                                'hide_empty' => false,
                                'orderby'    => 'name',
                                'order'      => 'ASC'
                            ));

                            if (!empty($cats)) {
                                $audio_exclude_cat_arr = isset($this->options['audio_exclude_cat']) ? explode(',', $this->options['audio_exclude_cat']) : array();
                                echo '<ul class="category-list">';
                                foreach ($cats as $audio_exclude_cat) {
                                    $post_count = get_term($audio_exclude_cat->cat_ID, 'category')->count;
                                    echo '<li><label for="audio_exclude_cat-' . $audio_exclude_cat->cat_ID . '"><input type="checkbox" name="vnaicontent_option[audio_exclude_cat][]" value="' . $audio_exclude_cat->cat_ID . '" id="audio_exclude_cat-' . $audio_exclude_cat->cat_ID . '" ' . (in_array($audio_exclude_cat->cat_ID, $audio_exclude_cat_arr) ? 'checked' : '') . '>' . $audio_exclude_cat->name . ' (' . $post_count . ')</label></li>';
                                }
                                echo '</ul>';
                            }
                            ?>
                        </div>
                        <hr>
                        <p>- Để tạo lại audio hàng loạt cho những bài viết đã tạo audio thì cần vào <a href="<?php echo admin_url('edit.php'); ?>">quản trị danh sách bài viết</a> và thực hiện xóa trạng thái đã tạo audio</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_player">Audio Player</label>
                    </th>
                    <td>
                        <?php $audio_player = isset($this->options['audio_player']) ? $this->options['audio_player'] : 'default'; ?>
                        <select name="vnaicontent_option[audio_player]" id="audio_player">
                            <option value="default" <?php echo selected($audio_player, 'default', false) ?>>Mặc định của wordpress</option>
                            <option value="plyr" <?php echo selected($audio_player, 'plyr', false) ?>>Plyr</option>
                            <option value="aplayer" <?php echo selected($audio_player, 'aplayer', false) ?>>APlayer</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_show">Chèn Audio vào bài viết</label>
                    </th>
                    <td>
                        <?php $audio_show = isset($this->options['audio_show']) ? $this->options['audio_show'] : ''; ?>
                        <select name="vnaicontent_option[audio_show]" id="audio_show">
                            <option value="" <?php echo selected($audio_show, '', false) ?>>Chọn vị trí</option>
                            <option value="1" <?php echo selected($audio_show, '1', false) ?>>Đầu bài viết</option>
                            <option value="2" <?php echo selected($audio_show, '2', false) ?>>Trước h2 đầu tiên</option>
                            <option value="3" <?php echo selected($audio_show, '3', false) ?>>Cuối bài viết</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="yt_show">Youtube Podcast</label>
                    </th>
                    <td>
                        <?php
                        $yt_action_time = isset($this->options['yt_action_time']) ? $this->options['yt_action_time'] : 0;
                        $yt_show = isset($this->options['yt_show']) ? $this->options['yt_show'] : '';
                        ?>
                        Tự động lấy video Youtube web sau mỗi
                        <input name="vnaicontent_option[yt_action_time]" id="yt_action_time" class="small-text" value="<?php echo $yt_action_time; ?>" type="number" min="0"> phút<code>(Set = 0 sẽ dừng)</code>
                        và chèn vào
                        <select name="vnaicontent_option[yt_show]" id="yt_show">
                            <option value="" <?php echo selected($yt_show, '', false) ?>>Không chèn Youtube</option>
                            <option value="1" <?php echo selected($yt_show, '1', false) ?>>Đầu bài viết</option>
                            <option value="2" <?php echo selected($yt_show, '2', false) ?>>Trước h2 đầu tiên</option>
                            <option value="3" <?php echo selected($yt_show, '3', false) ?>>Cuối bài viết</option>
                        </select>
                        <hr>
                        <label for="yt_url">Url kênh Youtube (<code>https://www.youtube.com/@khamphalichsu68</code>)</label>
                        <?php $yt_url = isset($this->options['yt_url']) ? esc_attr($this->options['yt_url']) : ''; ?>
                        <input name="vnaicontent_option[yt_url]" id="yt_url" class="large-text" value="<?php echo $yt_url; ?>" type="text">
                        <p>- Tính năng này sẽ lấy các video từ kênh Youtube tạo bởi rss podcast của web sau đó chèn vào bài viết tương ứng</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="podcast_thumb">Thumbnail Podcast</label>
                    </th>
                    <td>
                        <?php $podcast_thumb = isset($this->options['podcast_thumb']) ? $this->options['podcast_thumb'] : ''; ?>
                        <input id="podcast_thumb" type="text" name="vnaicontent_option[podcast_thumb]" value="<?php echo $podcast_thumb; ?>" class="large-text">
                        <p>
                            <button id="podcast_thumb_select" type="button" class="button button-primary">Chọn</button>
                            <button id="podcast_thumb_reset" type="button" class="button">Đặt lại</button>
                        </p>
                        <p>- Trong trường hợp bài viết không có thumbnail dẫn dến podcast cũng không có thumbnail thì hình ảnh này sẽ được dùng làm thumbnail của podcast. Nên chọn hình ảnh có tỉ lệ <strong>16:9</strong> để podcast hiển thị trên youtube sẽ có thumbnail đẹp</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="audio-ai">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="audio_voice_viettel">Viettel</label>
                    </th>
                    <td>
                        <?php
                        require_once VNAICONTENT_PATH . 'layout/tts.php';
                        usort($voice_viettel_arr, function ($a, $b) {
                            $order = ['Bắc' => 1, 'Trung' => 2, 'Nam' => 3];
                            $local_cmp = $order[$a['local']] <=> $order[$b['local']];
                            if ($local_cmp === 0) {
                                $gender_cmp = (strpos($a['name'], '(Nữ)') !== false) ? -1 : 1;
                                $gender_cmp -= (strpos($b['name'], '(Nữ)') !== false) ? -1 : 1;
                                return $gender_cmp;
                            }
                            return $local_cmp;
                        });

                        $audio_voice_viettel = isset($this->options['audio_voice_viettel']) ? $this->options['audio_voice_viettel'] : 'hn-quynhanh';
                        $audio_voice_viettel2 = isset($this->options['audio_voice_viettel2']) ? $this->options['audio_voice_viettel2'] : 'hcm-minhquan';
                        ?>
                        <label for="audio_voice_viettel">Voice 1</label>
                        <select name="vnaicontent_option[audio_voice_viettel]" id="audio_voice_viettel" class="form-control">
                            <?php
                            $current_local = '';
                            foreach ($voice_viettel_arr as $value) {
                                if ($current_local !== $value['local']) {
                                    if ($current_local !== '') {
                                        echo '</optgroup>';
                                    }
                                    $current_local = $value['local'];
                                    echo '<optgroup label="Miền ' . $current_local . '">';
                                }
                                echo '<option value="' . $value['code'] . '" ' . selected($audio_voice_viettel, $value['code'], false) . '>' . $value['name'] . '</option>';
                            }
                            if ($current_local !== '') {
                                echo '</optgroup>';
                            }
                            ?>
                        </select>
                        <label for="audio_voice_viettel2">Voice 2</label>
                        <select name="vnaicontent_option[audio_voice_viettel2]" id="audio_voice_viettel2" class="form-control">
                            <?php
                            $current_local = '';
                            foreach ($voice_viettel_arr as $value) {
                                if ($current_local !== $value['local']) {
                                    if ($current_local !== '') {
                                        echo '</optgroup>';
                                    }
                                    $current_local = $value['local'];
                                    echo '<optgroup label="Miền ' . $current_local . '">';
                                }
                                echo '<option value="' . $value['code'] . '" ' . selected($audio_voice_viettel2, $value['code'], false) . '>' . $value['name'] . '</option>';
                            }
                            if ($current_local !== '') {
                                echo '</optgroup>';
                            }
                            ?>
                        </select>
                        <hr>
                        <label for="viettel_proxy">Proxy</label>
                        <?php $viettel_proxy = isset($this->options['viettel_proxy']) ? esc_attr($this->options['viettel_proxy']) : ''; ?>
                        <input name="vnaicontent_option[viettel_proxy]" class="large-text" value="<?php echo $viettel_proxy; ?>" type="text">
                        <p>- Audio Viettel sử dụng cookie để dùng free nên chạy được một lúc ip của website bạn sẽ bị đưa vào danh sách và bị chặn. Vì vậy để cần dùng proxy (nên dùng proxy xoay) để khắc phục. Định dạng proxy: <code>ip:port:user:pass</code></p>
                        <hr>
                        <label for="viettel_token">Token</label>
                        <?php $viettel_token = isset($this->options['viettel_token']) ? esc_attr($this->options['viettel_token']) : ''; ?>
                        <input name="vnaicontent_option[viettel_token]" class="large-text" value="<?php echo $viettel_token; ?>" type="text">
                        <p>- Nếu không nhập <a target="_blank" href="https://viettelai.vn/dashboard/token">token</a> thì sẽ sử dụng cookie để tạo audio free</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_fpt_api">FPT</label>
                    </th>
                    <td>
                        <label for="audio_fpt_api">API</label>
                        <?php $audio_fpt_api = isset($this->options['audio_fpt_api']) ? $this->options['audio_fpt_api'] : ''; ?>
                        <textarea name="vnaicontent_option[audio_fpt_api]" id="audio_fpt_api" class="large-text" rows="5"><?php echo $audio_fpt_api; ?></textarea>
                        <p>- Mỗi tài khoản FPT được miễn phí 100k ký tự/tháng. Bạn có thể tạo nhiều tk để lấy nhiều api xoay vòng.</p>
                        <p>- Nếu sử dụng nhiều <a target="_blank" href="https://console.fpt.ai">API key</a> thì các api sẽ được sử dụng xoay vòng. Các api phân tách nhau bởi <code>|</code> Ví dụ: <code>key1|key2|key3</code>.</p>
                        <hr>
                        <?php
                        $audio_voice_fpt = isset($this->options['audio_voice_fpt']) ? $this->options['audio_voice_fpt'] : 'banmai';
                        $audio_voice_fpt2 = isset($this->options['audio_voice_fpt2']) ? $this->options['audio_voice_fpt2'] : 'linhsan';
                        ?>
                        <label for="audio_voice_fpt">Voice 1</label>
                        <select name="vnaicontent_option[audio_voice_fpt]" id="audio_voice_fpt" class="form-control">
                            <optgroup label="Miền Bắc">
                                <option value="banmai" <?php echo selected($audio_voice_fpt, 'banmai', false) ?>>Ban Mai (nữ)</option>
                                <option value="thuminh" <?php echo selected($audio_voice_fpt, 'thuminh', false) ?>>Thu Minh (nữ)</option>
                                <option value="leminh" <?php echo selected($audio_voice_fpt, 'leminh', false) ?>>Lê Minh (nam)</option>
                            </optgroup>
                            <optgroup label="Miền Trung">
                                <option value="myan" <?php echo selected($audio_voice_fpt, 'myan', false) ?>>Mỹ An (nữ)</option>
                                <option value="giahuy" <?php echo selected($audio_voice_fpt, 'giahuy', false) ?>>Gia Huy (nam)</option>
                            </optgroup>
                            <optgroup label="Miền Nam">
                                <option value="lannhi" <?php echo selected($audio_voice_fpt, 'lannhi', false) ?>>Lan Nhi (nữ)</option>
                                <option value="linhsan" <?php echo selected($audio_voice_fpt, 'linhsan', false) ?>>Linh San (nữ)</option>
                            </optgroup>
                        </select>
                        <label for="audio_voice_fpt2">Voice 2</label>
                        <select name="vnaicontent_option[audio_voice_fpt2]" id="audio_voice_fpt2" class="form-control">
                            <optgroup label="Miền Bắc">
                                <option value="banmai" <?php echo selected($audio_voice_fpt2, 'banmai', false) ?>>Ban Mai (nữ)</option>
                                <option value="thuminh" <?php echo selected($audio_voice_fpt2, 'thuminh', false) ?>>Thu Minh (nữ)</option>
                                <option value="leminh" <?php echo selected($audio_voice_fpt2, 'leminh', false) ?>>Lê Minh (nam)</option>
                            </optgroup>
                            <optgroup label="Miền Trung">
                                <option value="myan" <?php echo selected($audio_voice_fpt2, 'myan', false) ?>>Mỹ An (nữ)</option>
                                <option value="giahuy" <?php echo selected($audio_voice_fpt2, 'giahuy', false) ?>>Gia Huy (nam)</option>
                            </optgroup>
                            <optgroup label="Miền Nam">
                                <option value="lannhi" <?php echo selected($audio_voice_fpt2, 'lannhi', false) ?>>Lan Nhi (nữ)</option>
                                <option value="linhsan" <?php echo selected($audio_voice_fpt2, 'linhsan', false) ?>>Linh San (nữ)</option>
                            </optgroup>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_zalo_api">Zalo</label>
                    </th>
                    <td>
                        <label for="audio_zalo_api">API</label>
                        <?php $audio_zalo_api = isset($this->options['audio_zalo_api']) ? esc_attr($this->options['audio_zalo_api']) : ''; ?>
                        <input name="vnaicontent_option[audio_zalo_api]" id="audio_zalo_api" class="large-text" value="<?php echo $audio_zalo_api; ?>" type="text">
                        <p>- Tạo Audio Zalo cần <a target="_blank" href="https://ai.zalo.cloud/account/manage-keys">API key</a></p>
                        <hr>
                        <?php
                        $audio_voice_zalo = isset($this->options['audio_voice_zalo']) ? $this->options['audio_voice_zalo'] : 1;
                        $audio_voice_zalo2 = isset($this->options['audio_voice_zalo2']) ? $this->options['audio_voice_zalo2'] : 3;
                        ?>
                        <label for="audio_voice_zalo">Voice 1</label>
                        <select name="vnaicontent_option[audio_voice_zalo]" id="audio_voice_zalo" class="form-control">
                            <option value="1" <?php echo selected($audio_voice_zalo, '1', false) ?>>Nữ miền Nam</option>
                            <option value="2" <?php echo selected($audio_voice_zalo, '2', false) ?>>Nữ miền Bắc</option>
                            <option value="3" <?php echo selected($audio_voice_zalo, '3', false) ?>>Nam miền Nam</option>
                            <option value="4" <?php echo selected($audio_voice_zalo, '4', false) ?>>Nam miền Bắc</option>
                        </select>
                        <label for="audio_voice_zalo2">Voice 2</label>
                        <select name="vnaicontent_option[audio_voice_zalo2]" id="audio_voice_zalo2" class="form-control">
                            <option value="1" <?php echo selected($audio_voice_zalo2, '1', false) ?>>Nữ miền Nam</option>
                            <option value="2" <?php echo selected($audio_voice_zalo2, '2', false) ?>>Nữ miền Bắc</option>
                            <option value="3" <?php echo selected($audio_voice_zalo2, '3', false) ?>>Nam miền Nam</option>
                            <option value="4" <?php echo selected($audio_voice_zalo2, '4', false) ?>>Nam miền Bắc</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_gg_api">Google</label>
                    </th>
                    <td>
                        <label for="audio_gg_api">API</label>
                        <?php $audio_gg_api = isset($this->options['audio_gg_api']) ? esc_attr($this->options['audio_gg_api']) : ''; ?>
                        <input name="vnaicontent_option[audio_gg_api]" id="audio_gg_api" class="large-text" value="<?php echo $audio_gg_api; ?>" type="text">
                        <p>Tạo audio google cần <a target="_blank" href="https://cloud.google.com/text-to-speech/docs/quickstart">API key</a> và bật Cloud Text-to-Speech API. <a target="_blank" href="https://www.youtube.com/watch?v=Z503w-TbnJM">Video hướng dẫn</a></p>
                        <hr>
                        <label for="audio_lang_gg">Ngôn ngữ</label>
                        <select name="vnaicontent_option[audio_lang_gg]" id="audio_lang_gg" class="form-select">
                            <?php
                            $cur_audio_lang_gg = isset($this->options['audio_lang_gg']) ? esc_attr($this->options['audio_lang_gg']) : '';
                            foreach ($tts_gg as $code => $value) {
                                echo '<option value="' . $code . '" ' . selected($cur_audio_lang_gg, $code, false) . '>' . $value['name'] . '</option>';
                            }
                            ?>
                        </select>
                        <hr>
                        <?php
                        if (empty($cur_audio_lang_gg)) {
                            $cur_audio_lang_gg = 'vi-VN';
                        }
                        $cur_audio_voice_gg = isset($this->options['audio_voice_gg']) ? esc_attr($this->options['audio_voice_gg']) : 'vi-VN-Standard-A';
                        $cur_audio_voice_gg2 = isset($this->options['audio_voice_gg2']) ? esc_attr($this->options['audio_voice_gg2']) : 'vi-VN-Standard-B';
                        echo '<label for="audio_voice_gg">Voice 1</label>';
                        echo '<select name="vnaicontent_option[audio_voice_gg]" id="audio_voice_gg" class="form-select">';
                        foreach ($tts_gg as $code => $voices) {
                            foreach ($voices as $type => $value) {
                                if ($type != 'name' && $value != '') {
                                    $voices_arr = explode(',', $value);
                                    foreach ($voices_arr as $voice) {
                                        $class = 'hide';
                                        if ($cur_audio_lang_gg == $code) {
                                            $class = 'show';
                                        }
                                        $voice_value = $code . '-' . $type . '-' . $voice;
                                        echo '<option class="' . $class . ' ' . $code . '" value="' . $voice_value . '" ' . selected($cur_audio_voice_gg, $voice_value, false) . '>' . $voice_value . '</option>';
                                    }
                                }
                            }
                        }
                        echo '</select>';
                        echo '<label for="audio_voice_gg2">Voice 2</label>';
                        echo '<select name="vnaicontent_option[audio_voice_gg2]" id="audio_voice_gg2" class="form-select">';
                        foreach ($tts_gg as $code => $voices) {
                            foreach ($voices as $type => $value) {
                                if ($type != 'name' && $value != '') {
                                    $voices_arr = explode(',', $value);
                                    foreach ($voices_arr as $voice) {
                                        $class = 'hide';
                                        if ($cur_audio_lang_gg == $code) {
                                            $class = 'show';
                                        }
                                        $voice_value = $code . '-' . $type . '-' . $voice;
                                        echo '<option class="' . $class . ' ' . $code . '" value="' . $voice_value . '" ' . selected($cur_audio_voice_gg2, $voice_value, false) . '>' . $voice_value . '</option>';
                                    }
                                }
                            }
                        }
                        echo '</select>';
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_openai_api">OpenAI</label>
                    </th>
                    <td>
                        <label for="audio_openai_api">API</label>
                        <?php $audio_openai_api = isset($this->options['audio_openai_api']) ? esc_attr($this->options['audio_openai_api']) : ''; ?>
                        <input name="vnaicontent_option[audio_openai_api]" id="audio_openai_api" class="large-text" value="<?php echo $audio_openai_api; ?>" type="text">
                        <hr>
                        <label for="audio_openai_model">Model</label>
                        <?php $audio_openai_model = isset($this->options['audio_openai_model']) ? $this->options['audio_openai_model'] : 'tts-1'; ?>
                        <select name="vnaicontent_option[audio_openai_model]" id="audio_openai_model" class="form-control">
                            <option value="tts-1" <?php echo selected($audio_openai_model, 'tts-1', false) ?>>tts-1</option>
                            <option value="tts-1-hd" <?php echo selected($audio_openai_model, 'tts-1-hd', false) ?>>tts-1-hd</option>
                        </select>
                        <hr>
                        <?php
                        $audio_openai_voice = isset($this->options['audio_openai_voice']) ? $this->options['audio_openai_voice'] : 'echo';
                        $audio_openai_voice2 = isset($this->options['audio_openai_voice2']) ? $this->options['audio_openai_voice2'] : 'nova';
                        ?>
                        <label for="audio_openai_voice">Voice 1</label>
                        <select name="vnaicontent_option[audio_openai_voice]" id="audio_openai_voice" class="form-control">
                            <option value="alloy" <?php echo selected($audio_openai_voice, 'alloy', false) ?>>alloy (nam)</option>
                            <option value="echo" <?php echo selected($audio_openai_voice, 'echo', false) ?>>echo (nam)</option>
                            <option value="fable" <?php echo selected($audio_openai_voice, 'fable', false) ?>>fable (nam)</option>
                            <option value="onyx" <?php echo selected($audio_openai_voice, 'onyx', false) ?>>onyx (nam)</option>
                            <option value="nova" <?php echo selected($audio_openai_voice, 'nova', false) ?>>nova (nữ)</option>
                            <option value="shimmer" <?php echo selected($audio_openai_voice, 'shimmer', false) ?>>shimmer (nữ)</option>
                        </select>
                        <label for="audio_openai_voice2">Voice 2</label>
                        <select name="vnaicontent_option[audio_openai_voice2]" id="audio_openai_voice2" class="form-control">
                            <option value="alloy" <?php echo selected($audio_openai_voice2, 'alloy', false) ?>>alloy (nam)</option>
                            <option value="echo" <?php echo selected($audio_openai_voice2, 'echo', false) ?>>echo (nam)</option>
                            <option value="fable" <?php echo selected($audio_openai_voice2, 'fable', false) ?>>fable (nam)</option>
                            <option value="onyx" <?php echo selected($audio_openai_voice2, 'onyx', false) ?>>onyx (nam)</option>
                            <option value="nova" <?php echo selected($audio_openai_voice2, 'nova', false) ?>>nova (nữ)</option>
                            <option value="shimmer" <?php echo selected($audio_openai_voice2, 'shimmer', false) ?>>shimmer (nữ)</option>
                        </select>
                        <hr>
                        <label for="audio_openai_endpoint">Endpoint</label>
                        <?php $audio_openai_endpoint = isset($this->options['audio_openai_endpoint']) ? esc_attr($this->options['audio_openai_endpoint']) : 'https://api.openai.com/v1/audio/speech'; ?>
                        <input name="vnaicontent_option[audio_openai_endpoint]" id="audio_openai_endpoint" class="large-text" value="<?php echo $audio_openai_endpoint; ?>" type="text" placeholder="https://api.openai.com/v1/audio/speech">
                        <p>- Nếu sử dụng API của các bên trung gian thì cần nhập <code>url endpoint</code> do bên trung gian cung cấp. Lưu ý: Chỉ sử dụng api từ bên trung gian tuân thủ chính xác dữ liệu returns của OpenAI để tránh lỗi hoặc khi gặp lỗi mà không có thông báo rõ ràng, dẫn đến không biết được nguyên nhân gây lỗi</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_azure_speech_region">Azure Speech</label>
                    </th>
                    <td>
                        <label for="audio_azure_speech_region">Region</label>
                        <?php $audio_azure_speech_region = isset($this->options['audio_azure_speech_region']) ? esc_attr($this->options['audio_azure_speech_region']) : ''; ?>
                        <input name="vnaicontent_option[audio_azure_speech_region]" id="audio_azure_speech_region" class="large-text" value="<?php echo $audio_azure_speech_region; ?>" type="text">
                        <hr>

                        <label for="audio_azure_speech_api">API</label>
                        <?php $audio_azure_speech_api = isset($this->options['audio_azure_speech_api']) ? esc_attr($this->options['audio_azure_speech_api']) : ''; ?>
                        <input name="vnaicontent_option[audio_azure_speech_api]" id="audio_azure_speech_api" class="large-text" value="<?php echo $audio_azure_speech_api; ?>" type="text">
                        <hr>

                        <label for="audio_lang_azure_speech">Ngôn ngữ </label>
                        <select name="vnaicontent_option[audio_lang_azure_speech]" id="audio_lang_azure_speech" class="form-select">
                            <?php
                            $cur_audio_lang_azure_speech = isset($this->options['audio_lang_azure_speech']) ? esc_attr($this->options['audio_lang_azure_speech']) : '';
                            foreach ($lang_azure as $code => $name) {
                                echo '<option value="' . $code . '" ' . selected($cur_audio_lang_azure_speech, $code, false) . '>' . $name . '</option>';
                            }
                            ?>
                        </select>
                        <hr>
                        <?php
                        if (empty($cur_audio_lang_azure_speech)) {
                            $cur_audio_lang_azure_speech = 'vi-VN';
                        }
                        $cur_audio_voice_azure_speech = isset($this->options['audio_voice_azure_speech']) ? esc_attr($this->options['audio_voice_azure_speech']) : 'vi-VN-HoaiMyNeural';
                        $cur_audio_voice_azure_speech2 = isset($this->options['audio_voice_azure_speech2']) ? esc_attr($this->options['audio_voice_azure_speech2']) : 'vi-VN-NamMinhNeural';
                        $gender = '';
                        foreach ($tts_azure[$cur_audio_lang_azure_speech] as $item) {
                            if ($item['ShortName'] === $cur_audio_voice_azure_speech) {
                                $gender = $item['Gender'];
                                break;
                            }
                        }
                        $gender2 = '';
                        foreach ($tts_azure[$cur_audio_lang_azure_speech] as $item) {
                            if ($item['ShortName'] === $cur_audio_voice_azure_speech2) {
                                $gender2 = $item['Gender'];
                                break;
                            }
                        }

                        echo '<input type="hidden" name="vnaicontent_option[azure_speech_gender]" value="' . $gender . '">';
                        echo '<label for="audio_voice_azure_speech">Voice 1</label>';
                        echo '<select name="vnaicontent_option[audio_voice_azure_speech]" id="audio_voice_azure_speech" class="form-select">';
                        foreach ($tts_azure as $code => $voices) {
                            foreach ($voices as $voice) {
                                $class = 'hide';
                                if ($cur_audio_lang_azure_speech == $code) {
                                    $class = 'show';
                                }
                                echo '<option class="' . $class . ' ' . $code . '" value="' . $voice['ShortName'] . '" ' . selected($cur_audio_voice_azure_speech, $voice['ShortName'], false) . '>' . $voice['LocalName'] . ' (' . $voice['Gender'] . ')</option>';
                            }
                        }
                        echo '</select>';

                        echo '<input type="hidden" name="vnaicontent_option[azure_speech_gender2]" value="' . $gender2 . '">';
                        echo '<label for="audio_voice_azure_speech2">Voice 2</label>';
                        echo '<select name="vnaicontent_option[audio_voice_azure_speech2]" id="audio_voice_azure_speech2" class="form-select">';
                        foreach ($tts_azure as $code => $voices) {
                            foreach ($voices as $voice) {
                                $class = 'hide';
                                if ($cur_audio_lang_azure_speech == $code) {
                                    $class = 'show';
                                }
                                echo '<option class="' . $class . ' ' . $code . '" value="' . $voice['ShortName'] . '" ' . selected($cur_audio_voice_azure_speech2, $voice['ShortName'], false) . '>' . $voice['LocalName'] . ' (' . $voice['Gender'] . ')</option>';
                            }
                        }
                        echo '</select>';
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_azure_openai_key">Azure OpenAI</label>
                    </th>
                    <td>
                        <label for="audio_azure_openai_key">Key</label>
                        <?php $audio_azure_openai_key = isset($this->options['audio_azure_openai_key']) ? esc_attr($this->options['audio_azure_openai_key']) : ''; ?>
                        <input name="vnaicontent_option[audio_azure_openai_key]" id="audio_azure_openai_key" class="large-text" value="<?php echo $audio_azure_openai_key; ?>" type="text">
                        <hr>
                        <label for="audio_azure_openai_endpoint">Endpoint</label>
                        <?php $audio_azure_openai_endpoint = isset($this->options['audio_azure_openai_endpoint']) ? esc_attr($this->options['audio_azure_openai_endpoint']) : ''; ?>
                        <input name="vnaicontent_option[audio_azure_openai_endpoint]" id="audio_azure_openai_endpoint" class="large-text" value="<?php echo $audio_azure_openai_endpoint; ?>" type="text">
                        <p>- Tùy vào loại tài khoản Azure đang sử dụng khi tạo Resources cần chọn <a target="_blank" href="https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/models?tabs=python-secure#model-summary-table-and-region-availability">region cho phép dùng tss OpenAI</a>.</p>
                        <hr>
                        <?php
                        $audio_voice_azure_openai = isset($this->options['audio_voice_azure_openai']) ? $this->options['audio_voice_azure_openai'] : 'echo';
                        $audio_voice_azure_openai2 = isset($this->options['audio_voice_azure_openai2']) ? $this->options['audio_voice_azure_openai2'] : 'nova';
                        ?>
                        <label for="audio_voice_azure_openai">Voice 1</label>
                        <select name="vnaicontent_option[audio_voice_azure_openai]" id="audio_voice_azure_openai" class="form-control">
                            <option value="alloy" <?php echo selected($audio_voice_azure_openai, 'alloy', false) ?>>alloy (nam)</option>
                            <option value="echo" <?php echo selected($audio_voice_azure_openai, 'echo', false) ?>>echo (nam)</option>
                            <option value="fable" <?php echo selected($audio_voice_azure_openai, 'fable', false) ?>>fable (nam)</option>
                            <option value="onyx" <?php echo selected($audio_voice_azure_openai, 'onyx', false) ?>>onyx (nam)</option>
                            <option value="nova" <?php echo selected($audio_voice_azure_openai, 'nova', false) ?>>nova (nữ)</option>
                            <option value="shimmer" <?php echo selected($audio_voice_azure_openai, 'shimmer', false) ?>>shimmer (nữ)</option>
                        </select>
                        <label for="audio_voice_azure_openai2">Voice 2</label>
                        <select name="vnaicontent_option[audio_voice_azure_openai2]" id="audio_voice_azure_openai2" class="form-control">
                            <option value="alloy" <?php echo selected($audio_voice_azure_openai2, 'alloy', false) ?>>alloy (nam)</option>
                            <option value="echo" <?php echo selected($audio_voice_azure_openai2, 'echo', false) ?>>echo (nam)</option>
                            <option value="fable" <?php echo selected($audio_voice_azure_openai2, 'fable', false) ?>>fable (nam)</option>
                            <option value="onyx" <?php echo selected($audio_voice_azure_openai2, 'onyx', false) ?>>onyx (nam)</option>
                            <option value="nova" <?php echo selected($audio_voice_azure_openai2, 'nova', false) ?>>nova (nữ)</option>
                            <option value="shimmer" <?php echo selected($audio_voice_azure_openai2, 'shimmer', false) ?>>shimmer (nữ)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="audio_vbee_token">Vbee</label>
                    </th>
                    <td>
                        <label for="audio_vbee_token">Token</label>
                        <?php $audio_vbee_token = isset($this->options['audio_vbee_token']) ? esc_attr($this->options['audio_vbee_token']) : ''; ?>
                        <textarea name="vnaicontent_option[audio_vbee_token]" id="audio_vbee_token" class="large-text" rows="5"><?php echo $audio_vbee_token; ?></textarea>
                        <p>- Nếu sử dụng nhiều <a target="_blank" href="https://api.vbee.vn/apps/create">Token</a> thì các token sẽ được sử dụng xoay vòng. Các token phân tách nhau bởi <code>|</code> Ví dụ: <code>token1|token2|token3</code>.</p>
                        <hr>
                        <?php
                        $audio_voice_vbee = isset($this->options['audio_voice_vbee']) ? $this->options['audio_voice_vbee'] : 'hn_female_ngochuyen_full_48k-fhg';
                        $audio_voice_vbee2 = isset($this->options['audio_voice_vbee2']) ? $this->options['audio_voice_vbee2'] : 'hn_male_phuthang_stor80dt_48k-fhg';
                        ?>
                        <label for="audio_voice_vbee">Voice 1</label>
                        <select name="vnaicontent_option[audio_voice_vbee]" id="audio_voice_vbee" class="form-control">
                            <optgroup label="Hà Nội">
                                <option value="hn_female_ngochuyen_full_48k-fhg" <?php echo selected($audio_voice_vbee, 'hn_female_ngochuyen_full_48k-fhg', false) ?>>Ngọc Huyền</option>
                                <option value="hn_female_hachi_book_22k-vc" <?php echo selected($audio_voice_vbee, 'hn_female_hachi_book_22k-vc', false) ?>>Hà Chi (thuyết Minh)</option>
                                <option value="hn_female_hermer_stor_48k-fhg" <?php echo selected($audio_voice_vbee, 'hn_female_hermer_stor_48k-fhg', false) ?>>Ngọc Lan (đọc truyện)</option>
                                <option value="hn_female_lenka_stor_48k-phg" <?php echo selected($audio_voice_vbee, 'hn_female_lenka_stor_48k-phg', false) ?>>Nguyệt Dương (đọc truyện)</option>
                                <option value="hn_female_maiphuong_vdts_48k-fhg" <?php echo selected($audio_voice_vbee, 'hn_female_maiphuong_vdts_48k-fhg', false) ?>>Mai Phương</option>
                                <option value="hn_male_vietbach_child_22k-vc" <?php echo selected($audio_voice_vbee, 'hn_male_vietbach_child_22k-vc', false) ?>>Việt Bách (trẻ em)</option>
                                <option value="hn_male_phuthang_stor80dt_48k-fhg" <?php echo selected($audio_voice_vbee, 'hn_male_phuthang_stor80dt_48k-fhg', false) ?>>Anh Khôi (đọc truyện)</option>
                                <option value="hn_male_manhdung_news_48k-fhg" <?php echo selected($audio_voice_vbee, 'hn_male_manhdung_news_48k-fhg', false) ?>>Mạnh Dũng</option>
                                <option value="hn_male_thanhlong_talk_48k-fhg" <?php echo selected($audio_voice_vbee, 'hn_male_thanhlong_talk_48k-fhg', false) ?>>Thanh Long</option>
                                <option value="hn_male_phuthang_news65dt_44k-fhg" <?php echo selected($audio_voice_vbee, 'hn_male_phuthang_news65dt_44k-fhg', false) ?>>Anh Khôi (tin tức)</option>
                                <option value="hn_male_manhdung_news_48k-phg" <?php echo selected($audio_voice_vbee, 'hn_male_manhdung_news_48k-phg', false) ?>>Mạnh Dũng (nhấn nhá)</option>
                            </optgroup>

                            <optgroup label="Huế">
                                <option value="hue_female_huonggiang_full_48k-fhg" <?php echo selected($audio_voice_vbee, 'hue_female_huonggiang_full_48k-fhg', false) ?>>Hương Giang</option>
                                <option value="hue_male_duyphuong_full_48k-fhg" <?php echo selected($audio_voice_vbee, 'hue_male_duyphuong_full_48k-fhg', false) ?>>Duy Phương</option>
                            </optgroup>

                            <optgroup label="Sài Gòn">
                                <option value="sg_female_tuongvy_call_44k-fhg" <?php echo selected($audio_voice_vbee, 'sg_female_tuongvy_call_44k-fhg', false) ?>>Tường Vi (tổng đài)</option>
                                <option value="sg_female_thaotrinh_full_44k-phg" <?php echo selected($audio_voice_vbee, 'sg_female_thaotrinh_full_44k-phg', false) ?>>Thảo Trinh (nhấn nhá)</option>
                                <option value="sg_female_thaotrinh_full_48k-fhg" <?php echo selected($audio_voice_vbee, 'sg_female_thaotrinh_full_48k-fhg', false) ?>>Thảo Trinh</option>
                                <option value="sg_female_lantrinh_vdts_48k-fhg" <?php echo selected($audio_voice_vbee, 'sg_female_lantrinh_vdts_48k-fhg', false) ?>>Lan Trinh</option>
                                <option value="sg_male_chidat_ebook_48k-phg" <?php echo selected($audio_voice_vbee, 'sg_male_chidat_ebook_48k-phg', false) ?>>Chí Đạt (đọc truyện)</option>
                                <option value="sg_male_trungkien_vdts_48k-fhg" <?php echo selected($audio_voice_vbee, 'sg_male_trungkien_vdts_48k-fhg', false) ?>>Trung Kiên</option>
                                <option value="sg_male_minhhoang_full_48k-fhg" <?php echo selected($audio_voice_vbee, 'sg_male_minhhoang_full_48k-fhg', false) ?>>Minh Hoàng</option>
                            </optgroup>
                        </select>

                        <label for="audio_voice_vbee2">Voice 2</label>
                        <select name="vnaicontent_option[audio_voice_vbee2]" id="audio_voice_vbee2" class="form-control">
                            <optgroup label="Hà Nội">
                                <option value="hn_female_ngochuyen_full_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_female_ngochuyen_full_48k-fhg', false) ?>>Ngọc Huyền</option>
                                <option value="hn_female_hachi_book_22k-vc" <?php echo selected($audio_voice_vbee2, 'hn_female_hachi_book_22k-vc', false) ?>>Hà Chi (thuyết Minh)</option>
                                <option value="hn_female_hermer_stor_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_female_hermer_stor_48k-fhg', false) ?>>Ngọc Lan (đọc truyện)</option>
                                <option value="hn_female_lenka_stor_48k-phg" <?php echo selected($audio_voice_vbee2, 'hn_female_lenka_stor_48k-phg', false) ?>>Nguyệt Dương (đọc truyện)</option>
                                <option value="hn_female_maiphuong_vdts_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_female_maiphuong_vdts_48k-fhg', false) ?>>Mai Phương</option>
                                <option value="hn_male_vietbach_child_22k-vc" <?php echo selected($audio_voice_vbee2, 'hn_male_vietbach_child_22k-vc', false) ?>>Việt Bách (trẻ em)</option>
                                <option value="hn_male_phuthang_stor80dt_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_male_phuthang_stor80dt_48k-fhg', false) ?>>Anh Khôi (đọc truyện)</option>
                                <option value="hn_male_manhdung_news_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_male_manhdung_news_48k-fhg', false) ?>>Mạnh Dũng</option>
                                <option value="hn_male_thanhlong_talk_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_male_thanhlong_talk_48k-fhg', false) ?>>Thanh Long</option>
                                <option value="hn_male_phuthang_news65dt_44k-fhg" <?php echo selected($audio_voice_vbee2, 'hn_male_phuthang_news65dt_44k-fhg', false) ?>>Anh Khôi (tin tức)</option>
                                <option value="hn_male_manhdung_news_48k-phg" <?php echo selected($audio_voice_vbee2, 'hn_male_manhdung_news_48k-phg', false) ?>>Mạnh Dũng (nhấn nhá)</option>
                            </optgroup>

                            <optgroup label="Huế">
                                <option value="hue_female_huonggiang_full_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hue_female_huonggiang_full_48k-fhg', false) ?>>Hương Giang</option>
                                <option value="hue_male_duyphuong_full_48k-fhg" <?php echo selected($audio_voice_vbee2, 'hue_male_duyphuong_full_48k-fhg', false) ?>>Duy Phương</option>
                            </optgroup>

                            <optgroup label="Sài Gòn">
                                <option value="sg_female_tuongvy_call_44k-fhg" <?php echo selected($audio_voice_vbee2, 'sg_female_tuongvy_call_44k-fhg', false) ?>>Tường Vi (tổng đài)</option>
                                <option value="sg_female_thaotrinh_full_44k-phg" <?php echo selected($audio_voice_vbee2, 'sg_female_thaotrinh_full_44k-phg', false) ?>>Thảo Trinh (nhấn nhá)</option>
                                <option value="sg_female_thaotrinh_full_48k-fhg" <?php echo selected($audio_voice_vbee2, 'sg_female_thaotrinh_full_48k-fhg', false) ?>>Thảo Trinh</option>
                                <option value="sg_female_lantrinh_vdts_48k-fhg" <?php echo selected($audio_voice_vbee2, 'sg_female_lantrinh_vdts_48k-fhg', false) ?>>Lan Trinh</option>
                                <option value="sg_male_chidat_ebook_48k-phg" <?php echo selected($audio_voice_vbee2, 'sg_male_chidat_ebook_48k-phg', false) ?>>Chí Đạt (đọc truyện)</option>
                                <option value="sg_male_trungkien_vdts_48k-fhg" <?php echo selected($audio_voice_vbee2, 'sg_male_trungkien_vdts_48k-fhg', false) ?>>Trung Kiên</option>
                                <option value="sg_male_minhhoang_full_48k-fhg" <?php echo selected($audio_voice_vbee2, 'sg_male_minhhoang_full_48k-fhg', false) ?>>Minh Hoàng</option>
                            </optgroup>
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="audio-prompt" style="padding: 30px;">
        <p style="margin: 0 0 15px 0;">
            <input name="vnaicontent_option[audio_use_prompt]" id="audio_use_prompt" type="checkbox" value="1" <?php checked(isset($this->options['audio_use_prompt']) ? 1 : '', 1); ?>>
            <label for="audio_use_prompt">Sử dụng prompt</label>
        </p>
        <?php $audio_prompt = isset($this->options['audio_prompt']) ? esc_attr($this->options['audio_prompt']) : ''; ?>
        <textarea style="width: 100%;" name="vnaicontent_option[audio_prompt]" id="audio_prompt" class="large-text" rows="15"><?php echo $audio_prompt; ?></textarea>
        <p>- Mặc định nguyên văn 100% nội dung bài viết sẽ được chuyển thành audio với <code>voice 1</code>. Nếu bạn nhập prompt này thì AI sẽ viết lại kịch bản tạo audio từ nội dung bài viết dựa trên yêu cầu từ prompt.</p>
        <p>- Tùy vào prompt sẽ có thể tạo audio với 1 giọng đọc hoặc 2 giọng đọc tương tác đối thoại với nhau</p>
        <p>- Prompt mẫu <code>chỉ có 1 người (sử dụng voice 1)</code></p>
        <pre style="background: #e5ddc4; padding: 5px; margin:0; white-space: pre-wrap;">
Chuyển đổi bài viết dưới đây thành định dạng podcast cho kênh "Khám phá lịch sử", phù hợp để chuyển thành giọng nói bằng công cụ text-to-speech, theo các yêu cầu sau:

1. Quy tắc chuyển đổi
- Chỉ giữ lại nội dung thuần túy sẽ được đọc
- Không thêm bất kỳ chú thích về âm thanh, nhạc hay hiệu ứng
- Không sử dụng các ký hiệu đặc biệt và định dạng văn bản
- Viết tất cả số liệu bằng chữ để dễ đọc (ví dụ: "hai mươi lăm phần trăm" thay vì "25%")
- Chuyển bullet points thành câu văn hoàn chỉnh
- Chuyển đổi dữ liệu và bảng biểu thành câu chuyện tự nhiên
- Loại bỏ hoàn toàn trích dẫn, nguồn tham khảo, link và chú thích
- Với thuật ngữ chuyên ngành: Giải thích qua ví dụ đời thường trước khi đưa ra định nghĩa

2. Cấu trúc và nhịp điệu
- Mở đầu với lời chào thương hiệu và giới thiệu chủ đề tập podcast
- Chia nội dung thành các đoạn ngắn (2-3 câu) để dễ theo dõi
- Sử dụng dấu câu để tạo nhịp điệu tự nhiên:
  + Dấu phẩy cho các điểm dừng ngắn
  + Dấu chấm cho các điểm dừng dài hơn
  + Dấu chấm lửng để tạo sự tò mò
- Kết thúc với tổng kết và lời chào tạm biệt mang tính thương hiệu

3. Tương tác và gắn kết
- Thêm câu hỏi gợi mở cho cộng đồng người nghe
- Sử dụng "quý vị", "các bạn", "chúng ta" để tạo kết nối với đông đảo thính giả
- Thêm các cụm từ nhấn mạnh cho những thông tin quan trọng
- Kể chuyện minh họa ngắn gọn để tăng tính hấp dẫn

4. Xử lý nội dung chuyên môn
- Giải thích thuật ngữ chuyên ngành bằng ngôn ngữ đại chúng
- Sử dụng ví dụ thực tế để minh họa khái niệm phức tạp
- Chia nhỏ thông tin phức tạp thành các phần dễ hiểu
- Nhấn mạnh các điểm chính bằng cách lặp lại một cách tự nhiên
- Với số liệu phức tạp:
  + Làm tròn số để dễ đọc và nhớ
  + Đặt trong ngữ cảnh so sánh thực tế
  + Tập trung vào ý nghĩa hơn con số chính xác

5. Chuyển tiếp và kết nối
- Sử dụng các cụm từ chuyển tiếp tự nhiên (ví dụ: "tiếp theo", "bên cạnh đó", "điều này dẫn đến")
- Tạo cầu nối mượt mà giữa các ý tưởng
- Nhắc lại ý chính trước khi chuyển sang chủ đề mới
- Tránh chuyển đề tài đột ngột

6. Phong cách
- Giọng điệu chuyên nghiệp, thân thiện, phù hợp với thương hiệu "Khám phá lịch sử"
- Câu văn đơn giản, rõ ràng, tránh các cấu trúc phức tạp
- Sử dụng từ ngữ phổ thông, dễ hiểu với đại chúng
- Tránh các từ ngữ dễ gây nhầm lẫn khi đọc bằng TTS
- Không sử dụng các từ viết tắt, cần viết đầy đủ
- Duy trì tính nhất quán trong cách xưng hô với người nghe

7. Yêu cầu đầu ra
- Chỉ trả về văn bản hoàn chỉnh để đọc podcast
- Không bao gồm bất kỳ chú thích, giải thích hay hướng dẫn nào
- Không có đánh dấu phần, định dạng văn bản hay ký tự đặc biệt
- Trả về duy nhất nội dung podcast ở định dạng văn bản thuần túy
        </pre>
        <p>- Prompt mẫu <code>có 2 người (sử dụng voice 1 và voice 2)</code></p>
        <pre style="background: #e5ddc4; padding: 5px; margin:0; white-space: pre-wrap;">
Chuyển đổi bài viết dưới đây thành kịch bản podcast đối thoại phù hợp để chuyển thành giọng nói bằng công cụ text-to-speech, với 2 giọng đọc:

VOICE 1 - Ngọc Mai:
- Giới tính: NỮ
- Vai trò: MC dẫn chuyện, đại diện kênh "Khám phá lịch sử"
- Tính cách: Nhiệt tình, tò mò, hay đặt câu hỏi sâu. Thường chia sẻ những suy nghĩ và cảm xúc của mình về chủ đề.
- Phong cách nói: Thân thiện, gần gũi, đôi khi hóm hỉnh
- Nhiệm vụ: 
  + Dẫn dắt câu chuyện một cách tự nhiên
  + Đặt những câu hỏi thú vị, gợi mở
  + Chia sẻ góc nhìn cá nhân và kinh nghiệm liên quan
  + Thể hiện sự ngạc nhiên, thích thú khi học được điều mới
  + Đưa ra các ví dụ thực tế để minh họa
  + Thường có những giả định ban đầu để Voice 2 thách thức
  + Tỏ ra ngạc nhiên với "Thật sao?", "Điều này thú vị quá!" 
  + Đặt câu hỏi đào sâu dựa trên câu chuyện của Voice 2
- Cách xưng hô:
  + Xưng "tôi" với khách mời và khán giả
  + Gọi khách mời là "anh/chị/ông/bà + tên", theo chức danh hoặc bao gồm cả chức danh và tên của khách mời
  + Gọi khán giả là "các bạn/quý vị"

VOICE 2 - Chuyên gia (tạo tên và chức danh phù hợp với chủ đề bài viết):
- Giới tính: NAM 
- Vai trò: Khách mời, chuyên gia trong lĩnh vực
- Tính cách: 
  + Uyên bác nhưng dí dỏm, thích kể chuyện
  + Thường chia sẻ câu chuyện cá nhân và trải nghiệm thực tế
  + Thích đưa ra góc nhìn bất ngờ, thách thức suy nghĩ thông thường
  + Thường kể về những câu chuyện hậu trường ngành nghề, tạo sự bất ngờ
  + Sử dụng lối kể chuyện phong phú và không ngừng khơi gợi sự tò mò

- Phong cách nói:
  + Chuyên nghiệp nhưng gần gũi
  + Thường bắt đầu câu chuyện bằng những trải nghiệm cụ thể hoặc ví dụ thực tế
  + Giải thích kiến thức chuyên môn qua ẩn dụ đời thường
  + Thỉnh thoảng đặt câu hỏi ngược lại cho MC để tạo sự tương tác và thách thức suy nghĩ thông thường
  + Thường kết hợp các yếu tố kể chuyện và kiến thức để tạo ra những thông điệp dễ nhớ, bất ngờ
  + Dùng công thức: Câu chuyện -> Kiến thức -> Kết nối -> Thách thức góc nhìn
- Nhiệm vụ:
  + Chia sẻ kiến thức chuyên sâu qua những câu chuyện thú vị
  + Đặt câu hỏi ngược lại cho MC để tạo tương tác
  + Bày tỏ quan điểm cá nhân về các vấn đề
  + Kể những câu chuyện hậu trường thú vị trong ngành
  + Giải thích các khái niệm phức tạp bằng ngôn ngữ đời thường
  + Thỉnh thoảng callback đến nội dung đã thảo luận trước đó
  + Tạo "cliffhanger" để dẫn dắt sang chủ đề mới hoặc phần tiếp theo
- Cách xưng hô:
  + Xưng "tôi" với MC và khán giả
  + Gọi MC bằng tên hoặc "anh/chị + tên" tùy vào tình huống và mức độ thân thiết
  + Gọi khán giả là "các bạn/quý vị"

1. Quy tắc chuyển đổi
- Chỉ giữ lại nội dung thuần túy sẽ được đọc
- Không thêm bất kỳ chú thích về âm thanh, nhạc hay hiệu ứng
- Không sử dụng các ký hiệu đặc biệt và định dạng văn bản
- Viết tất cả số liệu bằng chữ để dễ đọc (ví dụ: "hai mươi lăm phần trăm" thay vì "25%")
- Chuyển bullet points thành đối thoại tự nhiên
- Chuyển đổi dữ liệu và bảng biểu thành câu chuyện đối thoại
- Loại bỏ hoàn toàn trích dẫn, nguồn tham khảo, link và chú thích
- Với thuật ngữ chuyên ngành: Giải thích qua ví dụ đời thường trước khi đưa ra định nghĩa

2. Cấu trúc đối thoại
- Mở đầu (10%): 
  + Voice 1: 
    * Chào đón, giới thiệu chủ đề + lý do quan tâm cá nhân
    * Giới thiệu khách mời
    * Tạo hook bằng câu hỏi gây tò mò hoặc fact thú vị
  + Voice 2: 
    * Đáp lại bằng câu chuyện thú vị + đặt câu hỏi ngược
    * Đưa ra một insight bất ngờ về chủ đề
- Thân bài (80%): 
  + Voice 1: Câu hỏi gợi mở + quan điểm cá nhân
  + Voice 2: Câu chuyện/ví dụ -> Kiến thức -> Kết nối -> Thách thức
  + Voice 1: Thể hiện ngạc nhiên + đào sâu
  + Voice 2: Chia sẻ insight + câu chuyện hậu trường
- Kết thúc (10%): 
  + Voice 1: Tóm tắt các điểm chính, chia sẻ cảm xúc cá nhân sau cuộc trò chuyện. Cảm ơn khách mời, tạm biệt và hẹn gặp lại khán giả
  + Voice 2: Cảm ơn MC, chào tạm biệt khán giả

3. Tương tác giữa hai voice
- Voice 1 có thể đưa ra những giả định hoặc đặt câu hỏi thử thách, và Voice 2 sẽ phản hồi với lý giải chi tiết
- Voice 2 thỉnh thoảng callback nội dung trước
- Cả hai voice có thể có những khoảnh khắc "wow", "aha", và "eureka" thể hiện sự ngạc nhiên hoặc thích thú trong câu chuyện của đối phương
- Cả hai voice có thể ngắt lời nhau một cách tự nhiên và nhẹ nhàng, không để tạo cảm giác gượng gạo
- Đảm bảo rằng cả hai voice không độc thoại quá lâu, để cuộc trò chuyện luôn duy trì sự hấp dẫn
- Sử dụng câu chuyện làm cầu nối giữa các chủ đề

4. Xử lý nội dung chuyên môn
- Voice 2 luôn bắt đầu bằng câu chuyện/ví dụ cụ thể
- Voice 1 đóng vai người học hỏi, thể hiện ngạc nhiên
- Chia nhỏ thông tin phức tạp thành các phần dễ hiểu
- Sử dụng ẩn dụ và tình huống đời thường để giải thích
- Với số liệu phức tạp:
  + Làm tròn số để dễ đọc và nhớ
  + Đặt trong ngữ cảnh so sánh thực tế
  + Tập trung vào ý nghĩa hơn con số chính xác

5. Chuyển tiếp và kết nối
- Voice 1 chịu trách nhiệm dẫn dắt chuyển cảnh
- Voice 2 tạo hook và cliffhanger để dẫn sang chủ đề mới
- Sử dụng câu chuyện làm cầu nối tự nhiên
- Callback nội dung trước để tạo mạch đối thoại

6. Phong cách
- Giọng điệu thân thiện, gần gũi
- Xen kẽ câu ngắn và dài để tạo nhịp điệu
- Thêm cảm xúc vào lời thoại để tạo sự liên kết với khán giả
- Tránh độc thoại dài quá 3 câu
- Sử dụng từ ngữ đời thường, tránh thuật ngữ phức tạp
- Thêm các sentiment words (tuyệt vời, thú vị, bất ngờ)
- Tránh các từ ngữ dễ gây nhầm lẫn khi đọc bằng TTS

7. Yêu cầu đầu ra
- Chỉ trả về kịch bản đối thoại theo định dạng:
  <strong class="red-text">[voice1]Nội dung thoại[/voice1]</strong>
  <strong class="red-text">[voice2]Nội dung thoại[/voice2]</strong>
- Không bao gồm bất kỳ chú thích hay hướng dẫn nào
- Không có đánh dấu phần, định dạng văn bản hay ký tự đặc biệt
- Mỗi lượt thoại không quá 3 câu để tránh độc thoại dài
- Tổng thời lượng: 10-15 phút (khoảng 1500-2000 từ)
        </pre>
    </div>
    <div class="tab-content" id="audio-podcast" style="padding: 25px 30px;">
        <div style="display: none;">
            feed_podcast_order
            <?php $feed_podcast_order = isset($this->options['feed_podcast_order']) ? $this->options['feed_podcast_order'] : ''; ?>
            <select name="vnaicontent_option[feed_podcast_order]" id="feed_podcast_order">
                <option value="" <?php selected($feed_podcast_order, ''); ?>>Mới nhất</option>
                <option value="ASC" <?php echo selected($feed_podcast_order, 'ASC', false) ?>>Cũ nhất</option>
            </select>
            <hr>
            feed_podcast_offset
            <?php $feed_podcast_offset = isset($this->options['feed_podcast_offset']) ? $this->options['feed_podcast_offset'] : 0; ?>
            <input name="vnaicontent_option[feed_podcast_offset]" id="feed_podcast_offset" class="small-text" value="<?php echo $feed_podcast_offset; ?>" min="0" type="number">
            <hr>
            feed_podcast_action_time
            <?php $feed_podcast_action_time = isset($this->options['feed_podcast_action_time']) ? $this->options['feed_podcast_action_time'] : 0; ?>
            <input type="number" name="vnaicontent_option[feed_podcast_action_time]" id="feed_podcast_action_time" class="small-text" value="<?php echo $feed_podcast_action_time; ?>" min="0">
        </div>
        <p>Danh sách feed podcast có thể sử dụng để đăng ký các kênh podcast, youtube:</p>
        <ol>
            <?php
            echo '<li><a target="_blank" href="' . home_url('/feed/podcast/') . '">' . home_url('/feed/podcast/') . '</a> (All - Mặc định của rankmath)</li>';

            $categories = get_categories(array('hide_empty' => true));
            foreach ($categories as $category) {
                $feed_podcast = home_url('/' . $category->slug . '/feed/podcast/');
                echo '<li><a target="_blank" href="' . $feed_podcast . '">' . $feed_podcast . '</a></li>';
            }
            ?>
        </ol>
        <p>- Trên đây là các feed podcast tạo ra dựa trên cấu trúc feed podcast của rankmath, vì vậy để sử dụng được các feed podcast này thì phải sử dụng rankmath và bật podcast. Mặc định rankmath chỉ tạo duy nhất 1 feed podcast cho toàn bộ website. Plugin VnAIContent đã tạo thêm các feed podcast tương ứng với từng danh mục để người dùng có thể sử dụng tùy mục đích của mình, ví dụ với mỗi danh mục có thể tạo tương ứng 1 playlist youtube</p>
        <p>- Với mỗi bài viết có audio nếu website của bạn sử dụng rankmath thì cũng sẽ tự động tạo ra schema Podcast Episode tương ứng với bài viết</p>
        <p>- Có thể thay đổi description của mỗi item trong feed mặc định của wp và feed podcast của rankmath theo các tham số truyền vào url feed: <strong>title</strong>, <strong>thumb</strong>, <strong>content</strong>, <strong>link</strong>, <strong>tags</strong>. Ví dụ:</p>
        <p><code><?php echo home_url('/feed/?title=1&thumb=1&content=3000&link=0&tags=1'); ?></code></p>
        <p><code><?php echo home_url('/feed/podcast/?title=1&thumb=1&content=3000&link=0&tags=1'); ?></code></p>
        <p>+ <strong>content</strong>: Độ dài description của mỗi item (nếu không set thì mặc định là 255 ký tự</p>
        <p>+ <strong>link</strong>: Link bài viết luôn được chèn cuối description của mỗi item. Nếu set = 0 thì sẽ không chèn link</p>
        <p>+ <strong>title, thumb, tags</strong>: Mặc định không chèn vào description của mỗi item. Nếu set = 1 thì sẽ được chèn</p>
        <hr>
        <p>Danh sách một số nền tảng podcast để tạo kênh podcast bằng feed:</p>
        <ol>
            <li><a target="_blank" href="https://podcastsconnect.apple.com">https://podcastsconnect.apple.com</a></li>
            <li><a target="_blank" href="https://podcasters.spotify.com">https://podcasters.spotify.com</a></li>
            <li><a target="_blank" href="https://podcasters.amazon.com/submit-rss">https://podcasters.amazon.com/submit-rss</a></li>
            <li><a target="_blank" href="https://publish.blubrry.com">https://publish.blubrry.com</a> (Từ nền tảng này có thể tạo thêm một loạt các kênh khác: Show -> Manage -> Destinations)</li>
            <li><a target="_blank" href="https://connect.simplecast.com">https://connect.simplecast.com</a></li>
            <li><a target="_blank" href="https://www.podbean.com/site/submitPodcast">https://www.podbean.com/site/submitPodcast</a></li>
            <li><a target="_blank" href="https://www.iheart.com">https://www.iheart.com</a> (Không reg đc bằng ip Việt, cần fake ip)</li>
            <li><a target="_blank" href="https://podcasters.ivoox.com/#/programs/create/import">https://podcasters.ivoox.com</a></li>
            <li><a target="_blank" href="https://podbay.fm/add">https://podbay.fm/add</a></li>
            <li><a target="_blank" href="https://rephonic.com/search/titles">https://rephonic.com/search/titles</a> (Search "Podcasts by Title" hoặc "Podcasts by Publisher")</li>
        </ol>
    </div>
</div>