<?php
$log_file = VNAICONTENT_PATH . 'log.txt';
$log = file_exists($log_file) ? file_get_contents($log_file) : '';

if ($cmd == 'clear-log' && $log != '') {
    wp_delete_file($log_file);
    set_transient('vnaicontent_admin_notice', array('message' => 'Xóa log thành công!', 'type' => 'success'), 30);
    echo '<script type="text/javascript">window.location="' . VNAICONTENT_ADMIN_PAGE . '";</script>';
}

$model_json = get_option('vnaicontent_model');
$models = json_decode($model_json, true);
?>

<div class="vnaicontent-tab-vertical settings" style="<?php echo isset($_GET['tab']) ? 'display: none;' : ''; ?>
">
    <div class="tab-links">
        <button type="button" data-tab="settings-config" class="button-first">Cấu hình chung</button>
        <button type="button" data-tab="settings-gemini">Gemini</button>
        <button type="button" data-tab="settings-openai">OpenAI</button>
        <button type="button" data-tab="settings-claude">Claude</button>
        <button type="button" data-tab="settings-azure">Azure OpenAI</button>
        <button type="button" data-tab="settings-abacus">Abacus</button>
    </div>

    <div class="tab-content tab-content-first" id="settings-config">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="user_key">User key</label></th>
                    <td>
                        <?php
                        $user_key = isset($this->options['user_key']) ? esc_attr($this->options['user_key']) : '';
                        ?>
                        <input name="vnaicontent_option[user_key]" id="user_key" class="regular-text" value="<?php echo $user_key; ?>" type="text" required>
                        <p>
                            <?php if ($user_key == ''): ?>
                                <span class="red-text">Chưa nhập User key! </span> Đăng nhập vào tài khoản của bạn tại <a target="_blank" href="https://vngpt.pro">vngpt.pro</a> để lấy user key
                            <?php else: ?>
                                <?php
                                $end_time = get_option('vnaicontent_end_time', '');
                                $run_u = get_transient('vnaicontent_user_run');
                                $free = get_option('vnaicontent_free', 0);
                                if ($run_u === false) {
                                    $run_u = 0;
                                }

                                if ($end_time == -1) {
                                    echo '<span class="green-text">Hạn sử dụng:</span> <span class="blinker">Lifetime</span>';
                                } elseif ($end_time == 1 || $user_key == '') {
                                    echo '<span class="red-text">Chưa nhập User key! </span>';
                                } elseif ($end_time == 2) {
                                    echo '<span class="red-text">User key không hợp lệ! </span>';
                                } elseif ($end_time == 3) {
                                    echo '<span class="red-text">Tên miền không hợp lệ! </span>';
                                } elseif ($end_time == 4) {
                                    echo '<span class="green-text">Miễn phí mỗi ngày (<strong class="orange-text">' . $run_u . '/' . $free . '</strong>) lần tạo bài thành công. <a href="https://vngpt.pro" target="_blank">Nâng cấp tài khoản</a></span>';
                                    set_transient('vnaicontent_mess', '<span class="orange-text">Số lượt miễn phí của ngày hôm nay đã hết. <a href="https://vngpt.pro" target="_blank">Nâng cấp tài khoản</a></span>', 24 * HOUR_IN_SECONDS);
                                } elseif ($end_time == 5) {
                                    echo '<span class="green-text">Miễn phí mỗi ngày (<strong class="orange-text">' . $run_u . '/' . $free . '</strong>) lần tạo bài thành công. <a href="https://vngpt.pro" target="_blank">Nâng cấp tài khoản</a></span>';
                                } elseif ($end_time > 5) {
                                    $end_date = date('d-m-Y', $end_time);
                                    if ($end_time >= time()) {
                                        if (($end_time - time()) <= 7 * 24 * 60 * 60) {
                                            echo '<span class="orange-text">Sắp hết hạn sử dụng:</span> <span class="blinker">' . $end_date . '</span>';
                                        } else {
                                            echo '<span class="green-text">Hạn sử dụng:</span> <span class="blinker">' . $end_date . '</span>';
                                        }
                                    } else {
                                        $mess = '<span class="red-text">Tài khoản đã hết hạn sử dụng! </span><span class="blinker">' . $end_date . '</span>. Gia hạn tại <a target="_blank" href="https://vngpt.pro">vngpt.pro</a>';
                                        echo $mess;
                                        set_transient('vnaicontent_mess', $mess, 24 * HOUR_IN_SECONDS);
                                    }
                                }
                                ?>
                            <?php endif ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="lang">Ngôn ngữ</label></th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[lang]" id="lang">
                            <?php
                            $lang = isset($this->options['lang']) ? $this->options['lang'] : 'Việt';
                            $lang_arr = ['Ả Rập', 'Bengali', 'Bulgaria', 'Trung', 'Croatia', 'Séc', 'Đan Mạch', 'Hà Lan', 'Anh', 'Estonia', 'Phần Lan', 'Pháp', 'Đức', 'Hy Lạp', 'Do Thái', 'Hindi', 'Hungary', 'Indonesia', 'Ý', 'Nhật', 'Hàn', 'Latvia', 'Lithuania', 'Na Uy', 'Ba Lan', 'Bồ Đào Nha', 'Romania', 'Nga', 'Serbia', 'Slovak', 'Slovenia', 'Tây Ban Nha', 'Swahili', 'Thuỵ Điển', 'Thái', 'Thổ Nhĩ Kỳ', 'Ukraina', 'Việt'];
                            foreach ($lang_arr as $lang_name) {
                                echo '<option value="' . $lang_name . '" ' . selected($lang, $lang_name, false) . '>' . $lang_name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="type_ai">Tự động tạo bài viết</label></th>
                    <td>
                        <label for="type_ai">Tạo bài viết bởi</label>
                        <select form="vnaicontent-form" name="vnaicontent_option[type_ai]" id="type_ai">
                            <?php
                            $type_ai = isset($this->options['type_ai']) ? $this->options['type_ai'] : 'gemini';
                            ?>
                            <option value="gemini" <?php selected($type_ai, 'gemini'); ?>>Gemini</option>
                            <option value="openai" <?php selected($type_ai, 'openai'); ?>>OpenAI</option>
                            <option value="claude" <?php selected($type_ai, 'claude'); ?>>Claude</option>
                            <option value="azure" <?php selected($type_ai, 'azure'); ?>>Azure OpenAI</option>
                            <option value="abacus" <?php selected($type_ai, 'abacus'); ?>>Abacus</option>
                        </select>
                        <label for="post_action_time">sau mỗi</label>
                        <input name="vnaicontent_option[post_action_time]" id="post_action_time" class="small-text" value="<?php echo isset($this->options['post_action_time']) ? esc_attr($this->options['post_action_time']) : '1'; ?>" type="number" min="0"> phút. <code>(Set = 0 sẽ dừng tự động tạo bài)</code>
                        <p>Nếu tính năng tự động không hoạt động vui lòng xem <a href="<?php echo VNAICONTENT_ADMIN_PAGE . '&tab=notes'; ?>">hướng dẫn</a></p>
                        <hr>
                        Mỗi phiên cronjob sẽ chạy liên tiếp tối đa
                        <input name="vnaicontent_option[loop_run]" id="loop_run" class="small-text" value="<?php echo isset($this->options['loop_run']) ? esc_attr($this->options['loop_run']) : '1'; ?>" type="number" min="1"> lần.
                        <p><code>- Mỗi phiên cronjob, nếu tạo bài viết thành công sẽ dừng và chờ chạy phiên cronjob tiếp theo. Ngược lại nếu tạo bài viết thất bại sẽ không kết thúc cronjob mà tiếp tục đổi keyword và chạy, quá trình lặp lại đến khi tạo bài thành công hoặc quá số lần bạn set mà vẫn thất bại thì sẽ dừng.</code></p>
                        <p><code>- Cân nhắc kỹ khi set số lớn vì tốn tài nguyên và không phù hợp với web dùng hosting hay vps yếu</code></p>
                        <p><code>- Tính năng này chỉ dùng cho tài khoản AI trả phí. Gemini loại free không dùng được vì bị giới hạn 2 request/phút</code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="type_ai">Tự động chạy lại</label></th>
                    <td>
                        <p style="margin-bottom: 10px;">
                            <input name="vnaicontent_option[re_run_keyword_miss]" id="re_run_keyword_miss" type="checkbox" value="1" <?php checked(isset($this->options['re_run_keyword_miss']) ? 1 : '', 1); ?>>
                            <label for="re_run_keyword_miss">Tự động chạy lại các "<strong>Keywords tạo bài viết thất bại</strong>"</label>
                        </p>
                        <p style="margin-bottom: 10px;">
                            <input name="vnaicontent_option[re_run_keyword_remove]" id="re_run_keyword_remove" type="checkbox" value="1" <?php checked(isset($this->options['re_run_keyword_remove']) ? 1 : '', 1); ?>>
                            <label for="re_run_keyword_remove">Tự động chạy lại các "<strong>Keywords của bài viết đã xóa</strong>"</label>
                        </p>
                        <p>Sau khi chạy hết tất cả keyword hệ thống sẽ kiểm tra sau đó tự động chạy lại và lặp lại hành động này đến khi nào hết keyword thì sẽ dừng</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="draft">Loại bỏ bài viết</label></th>
                    <td>
                        <label for="min_word">Loại bỏ bài viết nếu độ dài nhỏ hơn</label>
                        <input name="vnaicontent_option[min_word]" id="min_word" class="small-text" value="<?php echo isset($this->options['min_word']) ? esc_attr($this->options['min_word']) : '0'; ?>" type="number" min="0"> từ. <code>(Set = 0 sẽ không loại bỏ)</code>
                        <hr>
                        <!--<label for="min_seo_score">Loại bỏ bài viết nếu điểm Rankmath SEO nhỏ hơn</label>
                        <input name="vnaicontent_option[min_seo_score]" id="min_seo_score" class="small-text" value="<?php //echo isset($this->options['min_seo_score'])?esc_attr($this->options['min_seo_score']):'0'; 
                                                                                                                        ?>" type="number" min="0" max="100"> <code>(Set = 0 sẽ không loại bỏ)</code>
                        <hr>-->
                        <input name="vnaicontent_option[not_img]" id="not_img" type="checkbox" value="1" <?php checked(isset($this->options['not_img']) ? 1 : '', 1); ?>>
                        <label for="not_img">Loại bỏ bài viết nếu không có ảnh</label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="draft">User đăng bài</label></th>
                    <td>
                        <select form="vnaicontent-form" name="vnaicontent_option[user]" id="user">
                            <?php
                            $cur_user = isset($this->options['user']) ? $this->options['user'] : 1;
                            $users = get_users(array('fields' => array('ID', 'user_login')));
                            foreach ($users as $user) {
                                echo '<option value="' . $user->ID . '" ' . selected($cur_user, $user->ID, false) . '>' . $user->user_login . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="draft">Xuất bản</label></th>
                    <td>
                        <p style="margin-bottom:15px">
                            <input name="vnaicontent_option[draft]" id="draft" type="checkbox" value="1" <?php checked(isset($this->options['draft']) ? 1 : '', 1); ?>>
                            <label for="draft">Bài viết tạo ra là bản nháp</label>
                        </p>

                        Tự động xuất bản sau mỗi
                        <input name="vnaicontent_option[publish_action_time]" id="publish_action_time" class="small-text" value="<?php echo isset($this->options['publish_action_time']) ? esc_attr($this->options['publish_action_time']) : '0'; ?>" type="number" min="0"> phút. <code>(Set = 0 sẽ dừng tự động xuất bản)</code>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="link_cur">Liên kết nội bộ</label></th>
                    <td>
                        <p style="margin-bottom:15px">
                            <input name="vnaicontent_option[link_cur]" id="link_cur" type="checkbox" value="1" <?php checked(isset($this->options['link_cur']) ? 1 : '', 1); ?>>
                            <label for="link_cur">Link về chính bài viết với textlink là keyword</label>
                        </p>

                        <input name="vnaicontent_option[link_brand]" id="link_brand" type="checkbox" value="1" <?php checked(isset($this->options['link_brand']) ? 1 : '', 1); ?>>
                        <label for="link_brand">Link về home với textlink là brand</label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="log">Options</label></th>
                    <td>
                        <p style="margin-bottom: 8px;">
                            <input name="vnaicontent_option[log]" id="log" type="checkbox" value="1" <?php checked(isset($this->options['log']) ? 1 : '', 1); ?>>
                            <label for="log">Bật log để ghi lại lỗi (nếu có)</label>
                        </p>
                        <textarea id="vnaicontent-log" class="large-text" rows="5"><?php echo $log; ?></textarea>
                        <?php if ($log != ''): ?>
                            <p>
                                <a id="clear-log" class="button red-text" href="<?php echo VNAICONTENT_ADMIN_PAGE . '&cmd=clear-log'; ?>">Xóa log</button>
                                    <a style="margin-left:5px" id="download-log" class="button" href="<?php echo VNAICONTENT_URL . 'log.txt'; ?>" download>Tải log</a>
                            </p>
                            <div id="clear-log-dialog" title="Thông báo" style="display:none;">
                                <p class="red-text">Bạn muốn xóa log?</p>
                            </div>
                        <?php endif ?>
                        <hr>
                        <a class="button" href="<?php echo add_query_arg(array('cmd' => 'vnaicontent-update-model'), VNAICONTENT_ADMIN_PAGE); ?>">Update model</a>
                        <p>Click để cập nhật các model AI, model tạo ảnh AI mới nhất và loại bỏ các model lỗi thời không thể sử dụng</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="settings-gemini">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="gemini_api_key">API</label></th>
                    <td>
                        <?php $gemini_api_key = isset($this->options['gemini_api_key']) ? esc_attr($this->options['gemini_api_key']) : ''; ?>
                        <textarea name="vnaicontent_option[gemini_api_key]" id="gemini_api_key" class="large-text" rows="5"><?php echo $gemini_api_key; ?></textarea>
                        <?php if ($gemini_api_key == ''): ?>
                            <p class="red-text description">Chưa có Gemini API key!</p>
                        <?php endif ?>
                        <p>Nếu sử dụng nhiều <a target="_blank" href="https://console.cloud.google.com">api key</a> thì các api sẽ được sử dụng xoay vòng. Các api key phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>key1|key2|key3</strong></code>. <a target="_blank" href="https://www.youtube.com/watch?v=sB5MPyb33Js">Xem video hướng dẫn</a></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gemini_model">Model</label></th>
                    <td>
                        <?php
                        $gemini_model = isset($this->options['gemini_model']) ? $this->options['gemini_model'] : 'gemini-1.5-pro-latest';
                        $gemini_model_arr = !empty($models['ai']['gemini_model']) ? $models['ai']['gemini_model'] : ['gemini-1.5-pro-latest' => 'gemini-1.5-pro-latest'];
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[gemini_model]" id="gemini_model">
                            <?php
                            foreach ($gemini_model_arr as $value => $text) {
                                echo '<option value="' . $value . '" ' . selected($gemini_model, $value, false) . '>' . $text . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gemini_proxy">Proxy</label></th>
                    <td>
                        <?php $gemini_proxy = isset($this->options['gemini_proxy']) ? esc_attr($this->options['gemini_proxy']) : ''; ?>
                        <label for="gemini_proxy">Proxy</label>
                        <input name="vnaicontent_option[gemini_proxy]" class="large-text" value="<?php echo $gemini_proxy; ?>" type="text">
                        <p>- Nếu ip (host, vps) web bạn thuộc local mà gemini không support thì có thể sử dụng proxy. Định dạng: <code>ip:port:user:pass</code></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="settings-openai">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="openai_api_key" class="form-label">API</label></th>
                    <td>
                        <?php $openai_api_key = isset($this->options['openai_api_key']) ? esc_attr($this->options['openai_api_key']) : ''; ?>
                        <textarea name="vnaicontent_option[openai_api_key]" id="openai_api_key" class="large-text" rows="5"><?php echo $openai_api_key; ?></textarea>
                        <?php if ($openai_api_key == ''): ?>
                            <p class="red-text description">Chưa có Openai API key!</p>
                        <?php endif ?>
                        <p>- Nếu sử dụng nhiều <a target="_blank" href="https://platform.openai.com/api-keys">api key</a> thì các api sẽ được sử dụng xoay vòng. Các api key phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>key1|key2|key3</strong></code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="openai_endpoint" class="form-label">Endpoint</label></th>
                    <td>
                        <?php $openai_endpoint = isset($this->options['openai_endpoint']) ? esc_attr($this->options['openai_endpoint']) : 'https://api.openai.com/v1/chat/completions'; ?>
                        <input name="vnaicontent_option[openai_endpoint]" id="openai_endpoint" class="large-text" value="<?php echo $openai_endpoint; ?>" type="text" placeholder="https://api.openai.com/v1/chat/completions">
                        <p>- Mặc định <code>https://api.openai.com/v1/chat/completions</code></p>
                        <p>- Nếu sử dụng API của các bên trung gian thì cần thay thế <code>Endpoint</code> do bên trung gian cung cấp. Lưu ý: Chỉ sử dụng api từ bên trung gian tuân thủ chính xác dữ liệu returns của OpenAI để tránh lỗi hoặc khi gặp lỗi mà không có thông báo rõ ràng, dẫn đến không biết được nguyên nhân gây lỗi</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="openai_model" class="form-label">Model</label></th>
                    <td>
                        <?php
                        $openai_model = isset($this->options['openai_model']) ? $this->options['openai_model'] : 'chatgpt-4o-latest';
                        $openai_model_arr = !empty($models['ai']['openai_model']) ? $models['ai']['openai_model'] : ['chatgpt-4o-latest' => 'chatgpt-4o-latest (16k)'];
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[openai_model]" id="openai_model">
                            <?php
                            foreach ($openai_model_arr as $value => $text) {
                                echo '<option value="' . $value . '" ' . selected($openai_model, $value, false) . '>' . $text . '</option>';
                            }
                            ?>
                        </select>
                        <p>- Nếu sử dụng API của các bên trung gian thì cần xem API đó có thể dùng được những model nào để lựa chọn cho phù hợp</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="settings-claude">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="claude_api_key" class="form-label">API</label></th>
                    <td>
                        <?php $claude_api_key = isset($this->options['claude_api_key']) ? esc_attr($this->options['claude_api_key']) : ''; ?>
                        <textarea name="vnaicontent_option[claude_api_key]" id="claude_api_key" class="large-text" rows="5"><?php echo $claude_api_key; ?></textarea>
                        <?php if ($claude_api_key == ''): ?>
                            <p class="red-text">Chưa có Claude API key!</p>
                        <?php endif ?>
                        <p>- Nếu sử dụng nhiều <a target="_blank" href="https://console.anthropic.com/settings/keys">api key</a> thì các api sẽ được sử dụng xoay vòng. Các api key phân tách nhau bởi <code><strong>|</strong></code>. Ví dụ: <code><strong>key1|key2|key3</strong></code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="claude_endpoint" class="form-label">Endpoint</label></th>
                    <td>
                        <label for="claude_endpoint"></label>
                        <?php $claude_endpoint = isset($this->options['claude_endpoint']) ? esc_attr($this->options['claude_endpoint']) : 'https://api.anthropic.com/v1/messages'; ?>
                        <input name="vnaicontent_option[claude_endpoint]" id="claude_endpoint" class="large-text" value="<?php echo $claude_endpoint; ?>" type="text" placeholder="https://api.anthropic.com/v1/messages">
                        <p>- Mặc định <code>https://api.anthropic.com/v1/messages</code></p>
                        <p>- Nếu sử dụng API của các bên trung gian thì cần thay thế <code>Endpoint</code> do bên trung gian cung cấp. Lưu ý: Chỉ sử dụng api từ bên trung gian tuân thủ chính xác dữ liệu returns của Claude để tránh lỗi hoặc khi gặp lỗi mà không có thông báo rõ ràng, dẫn đến không biết được nguyên nhân gây lỗi</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="claude_model" class="form-label">Model</label></th>
                    <td>
                        <?php
                        $claude_model = isset($this->options['claude_model']) ? $this->options['claude_model'] : 'claude-3-5-sonnet-20240620';
                        $claude_model_arr = !empty($models['ai']['claude_model']) ? $models['ai']['claude_model'] : ['claude-3-5-sonnet-20240620' => 'claude-3-5-sonnet-20240620 (4k)'];
                        ?>
                        <select form="vnaicontent-form" name="vnaicontent_option[claude_model]" id="claude_model">
                            <?php
                            foreach ($claude_model_arr as $value => $text) {
                                echo '<option value="' . $value . '" ' . selected($claude_model, $value, false) . '>' . $text . '</option>';
                            }
                            ?>
                        </select>
                        <p>- Nếu sử dụng API của các bên trung gian thì cần xem API đó có thể dùng được những model nào để lựa chọn cho phù hợp</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="settings-azure">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="azure_openai_key" class="form-label">Key</label></th>
                    <td>
                        <?php $azure_openai_key = isset($this->options['azure_openai_key']) ? esc_attr($this->options['azure_openai_key']) : ''; ?>
                        <input name="vnaicontent_option[azure_openai_key]" id="azure_openai_key" class="large-text" value="<?php echo $azure_openai_key; ?>" type="text">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="azure_openai_text_endpoint" class="form-label">Endpoint</label></th>
                    <td>
                        <label for="azure_openai_text_endpoint">Endpoint</label>
                        <?php $azure_openai_text_endpoint = isset($this->options['azure_openai_text_endpoint']) ? esc_attr($this->options['azure_openai_text_endpoint']) : ''; ?>
                        <input name="vnaicontent_option[azure_openai_text_endpoint]" id="azure_openai_text_endpoint" class="large-text" value="<?php echo $azure_openai_text_endpoint; ?>" type="text">
                        <p>- Tùy vào loại tài khoản Azure đang sử dụng khi tạo Resources cần chọn <a target="_blank" href="https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/models?tabs=python-secure#model-summary-table-and-region-availability">region cho phép dùng model OpenAI mà bạn chọn</a>.</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-content" id="settings-abacus">
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="abacus_project_id" class="form-label">Project Id</label></th>
                    <td>
                        <?php
                        $abacus_project_id = isset($this->options['abacus_project_id']) ? $this->options['abacus_project_id'] : '';
                        $abacus_api = isset($this->options['abacus_api']) ? $this->options['abacus_api'] : '';

                        $abacus_token = isset($this->options['abacus_token']) ? $this->options['abacus_token'] : '';
                        $abacus_models_json = isset($this->options['abacus_models_json']) ? $this->options['abacus_models_json'] : '';
                        $abacus_model_arr = !empty($abacus_models_json) ? json_decode($abacus_models_json, true) : [];

                        $button_name_abacus = 'Create abacus';
                        if (!empty($abacus_model_arr)) {
                            $button_name_abacus = 'Update abacus';
                        }
                        ?>
                        <input name="vnaicontent_option[abacus_project_id]" id="abacus_project_id" class="regular-text" value="<?php echo $abacus_project_id; ?>" type="text">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="abacus_api" class="form-label">API</label></th>
                    <td>
                        <input name="vnaicontent_option[abacus_api]" id="abacus_api" class="regular-text" value="<?php echo $abacus_api; ?>" type="text">
                        <a class="button" href="<?php echo add_query_arg(array('cmd' => 'vnaicontent-update-abacus-model'), VNAICONTENT_ADMIN_PAGE); ?>"><?php echo $button_name_abacus; ?></a>
                    </td>
                </tr>
                <?php if (!empty($abacus_model_arr)): ?>
                    <tr>
                        <th scope="row"><label for="abacus_model" class="form-label">Model</label></th>
                        <td>
                            <select form="vnaicontent-form" name="vnaicontent_option[abacus_model]" id="abacus_model">
                                <?php
                                $abacus_model = isset($this->options['abacus_model']) ? $this->options['abacus_model'] : '';
                                if (!empty($abacus_model_arr)) {
                                    foreach ($abacus_model_arr as $model) {
                                        echo '<option value="' . $model['deploymentId'] . '" ' . selected($abacus_model, $model['deploymentId'], false) . '>' . $model['name'] . '</option>';
                                    }
                                }
                                ?>
                            </select>
                            <input type="hidden" name="vnaicontent_option[abacus_models_json]" value="<?php echo esc_attr($abacus_models_json); ?>">
                            <input type="hidden" name="vnaicontent_option[abacus_token]" value="<?php echo $abacus_token; ?>">

                            <p>- Với <a target="_blank" href="https://abacus.ai/app/projects">abacus.ai</a> bạn có thể tự build AI với thuật toán theo mô hình Claude, OpenAI, Gemini, Llama... Bạn cũng có thể training AI phù hợp với mục đích của bạn như chuyên về SEO, sáng tạo nội dung... <a target="_blank" href="https://www.youtube.com/watch?v=YySUHBMF9bM">Xem video hướng dẫn</a></p>
                        </td>
                    </tr>
                <?php endif ?>
            </tbody>
        </table>
    </div>
</div>