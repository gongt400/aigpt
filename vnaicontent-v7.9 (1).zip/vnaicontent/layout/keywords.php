<p style="margin-top: 10px; margin-bottom: 5px;">
    <?php
        $cat = isset($_GET['cat'])?$_GET['cat']:'';
        $args_cates = array(
            'show_count' => 0,
            'hide_empty' => 0,
            'hierarchical' => 1,
            'show_option_none' => 'Chọn danh mục',
            'option_none_value' => '',
            'selected' => $cat,
            'name' => 'cat_keywords',
            'id' => 'cat-keywords',
            'class' => ''
        );
        wp_dropdown_categories($args_cates);
    ?>
</p>
<?php if ($cat != ''): ?>
    <?php  
        $keyword              = 'keyword_' . $cat;
        $keyword_active       = 'keyword_active_' . $cat;
        $keyword_miss         = 'keyword_miss_' . $cat;
        $keyword_post_removed = 'keyword_post_removed_' . $cat;
        $keyword_not_suitable = 'keyword_not_suitable_' . $cat;

        $keyword_txt              = VNAICONTENT_DATA . $keyword . '.txt';
        $keyword_active_txt       = VNAICONTENT_DATA . $keyword_active . '.txt';
        $keyword_miss_txt         = VNAICONTENT_DATA . $keyword_miss . '.txt';
        $keyword_post_removed_txt = VNAICONTENT_DATA . $keyword_post_removed . '.txt';
        $keyword_not_suitable_txt = VNAICONTENT_DATA . $keyword_not_suitable . '.txt';

        $keyword_value               = file_exists($keyword_txt)?file_get_contents($keyword_txt):'';
        $keyword_active_value        = file_exists($keyword_active_txt)?file_get_contents($keyword_active_txt):'';
        $keyword_miss_value          = file_exists($keyword_miss_txt)?file_get_contents($keyword_miss_txt):'';
        $keyword_post_removed_value  = file_exists($keyword_post_removed_txt)?file_get_contents($keyword_post_removed_txt):'';
        $keyword_not_suitable_value  = file_exists($keyword_not_suitable_txt)?file_get_contents($keyword_not_suitable_txt):'';

        function vnaicontent_line_count($file){
            if (file_exists($file)) {
                $lines = file($file, FILE_IGNORE_NEW_LINES);
                return count($lines);
            }else{
                return 0;
            }
        }

        $topic_cate = get_term_meta($cat, 'topic', true);
    ?>
    <div id="list-keyword">
        <div style="border: 1px solid #8c8f94; padding: 15px; margin-top: 15px;">
            Trước khi AI tạo bài sẽ kiểm tra xem keyword có phù hợp với</label>
            <input style="<?php echo !empty($topic_cate)?'font-weight: bold;':''; ?>" name="topic_<?php echo $cat; ?>" id="topic_<?php echo $cat; ?>" class="regular-text" value="<?php echo $topic_cate; ?>" type="text" placeholder="công thức, cách làm món ăn">
            hay không? Nếu không sẽ bị loại bỏ. <code>(Nếu để trống sẽ không kiểm tra)</code>
        </div>
        <div class="poststuff">
            <div class="postbox">
                <div class="postbox-header">
                    <h2>Keywords chưa tạo bài viết (<?php echo vnaicontent_line_count($keyword_txt); ?>)</h2>
                </div>
                <div class="inside">
                    <textarea style="width: 100%" wrap="off" id="<?php echo $keyword; ?>" class="large-text" rows="15"><?php echo $keyword_value; ?></textarea>
                </div>
            </div>
            <div class="postbox">
                <div class="postbox-header">
                    <h2 class="green-text">Keywords tạo bài viết thành công (<?php echo vnaicontent_line_count($keyword_active_txt); ?>)</h2>
                </div>
                <div class="inside">
                    <textarea style="width: 100%" wrap="off" id="<?php echo $keyword_active; ?>" class="large-text" rows="15"><?php echo $keyword_active_value; ?></textarea>
                </div>
            </div>
            <div class="postbox">
                <div class="postbox-header">
                    <h2 class="red-text">Keywords tạo bài viết thất bại (<?php echo vnaicontent_line_count($keyword_miss_txt); ?>)</h2>
                </div>
                <div class="inside">
                    <textarea style="width: 100%" wrap="off" id="<?php echo $keyword_miss; ?>" class="large-text" rows="15"><?php echo $keyword_miss_value; ?></textarea>
                </div>
            </div>
        </div>
        <div class="poststuff">
            <div class="postbox">
                <div class="postbox-header">
                    <h2 class="red-text">Keywords không phù hợp (<?php echo vnaicontent_line_count($keyword_not_suitable_txt); ?>)</h2>
                </div>
                <div class="inside">
                    <textarea style="width: 100%" wrap="off" id="<?php echo $keyword_not_suitable; ?>" class="large-text" rows="15"><?php echo $keyword_not_suitable_value; ?></textarea>
                </div>
            </div>
            <div class="postbox">
                <div class="postbox-header">
                    <h2 class="red-text">Keywords của bài viết đã xóa (<?php echo vnaicontent_line_count($keyword_post_removed_txt); ?>)</h2>
                </div>
                <div class="inside">
                    <textarea style="width: 100%" wrap="off" id="<?php echo $keyword_post_removed; ?>" class="large-text" rows="15"><?php echo $keyword_post_removed_value; ?></textarea>
                </div>
            </div>
        </div>
        <?php  
            if ($cat != ''){
                echo '<button type="button" class="button button-primary" id="save-keyword" data-cat="' . $cat . '">Save</button>';
            }
        ?>
        <p class="orange-text"><em>(*) Mỗi keyword trên 1 dòng</em></p>
    </div>
<?php endif ?>