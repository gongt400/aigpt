<?php

$voice_viettel_arr = [
    ["name" => "Quỳnh Anh (nữ)", "local" => "Bắc", "code" => "hn-quynhanh"],
    [
        "name" => "Phương Trang (nữ)",
        "local" => "Bắc",
        "code" => "hn-phuongtrang",
    ],
    ["name" => "Thảo Chi (nữ)", "local" => "Bắc", "code" => "hn-thaochi"],
    ["name" => "Thanh Hà (nữ)", "local" => "Bắc", "code" => "hn-thanhha"],
    [
        "name" => "Thanh Phương (nữ)",
        "local" => "Bắc",
        "code" => "hn-thanhphuong",
    ],
    ["name" => "Tiến Quân (nam)", "local" => "Bắc", "code" => "hn-tienquan"],
    ["name" => "Nam Khánh (nam)", "local" => "Bắc", "code" => "hn-namkhanh"],
    ["name" => "Thanh Tùng (nam)", "local" => "Bắc", "code" => "hn-thanhtung"],
    ["name" => "Mai Ngọc (nữ)", "local" => "Trung", "code" => "hue-maingoc"],
    ["name" => "Bảo Quốc (nam)", "local" => "Trung", "code" => "hue-baoquoc"],
    ["name" => "Diễm My (nữ)", "local" => "Nam", "code" => "hcm-diemmy"],
    ["name" => "Phương Ly (nữ)", "local" => "Nam", "code" => "hcm-phuongly"],
    ["name" => "Thùy Dung (nữ)", "local" => "Nam", "code" => "hcm-thuydung"],
    ["name" => "Thùy Duyên (nữ)", "local" => "Nam", "code" => "hcm-thuyduyen"],
    ["name" => "Lê Yến (nữ)", "local" => "Nam", "code" => "hn-leyen"],
    ["name" => "Minh Quân (nam)", "local" => "Nam", "code" => "hcm-minhquan"],
];

$tts_gg = array(
    'af-ZA' => array(
        'name'     => 'Afrikaans (Suid-Afrika)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'ar-XA' => array(
        'name'     => 'Arabic, multi-region',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D'
    ),
    'ms-MY' => array(
        'name'     => 'Bahasa Melayu (Malaysia)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D'
    ),
    'ca-ES' => array(
        'name'     => 'Català (Espanya)',
        'Standard' => 'A',
        'Wavenet'  => ''
    ),
    'da-DK' => array(
        'name'     => 'Dansk (Danmark)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B,C,D,F'
    ),
    'de-DE' => array(
        'name'     => 'Deutsch (Deutschland)',
        'Standard' => 'A,B,C,D,E,F',
        'Wavenet'  => 'A,B,C,D,E,F'
    ),
    'en-AU' => array(
        'name'     => 'English (Australia)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B,C,D'
    ),
    'en-GB' => array(
        'name'     => 'English (Great Britain)',
        'Standard' => 'A,B,C,D,F',
        'Wavenet'  => 'A,B,C,D,F',
        'Neural2'  => 'A,B,C,D,F'
    ),
    'en-IN' => array(
        'name'     => 'English (India)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B,C,D'
    ),
    'en-US' => array(
        'name'     => 'English (United States)',
        'Standard' => 'A,B,C,D,E,F,G,H,I,J',
        'Wavenet'  => 'A,B,C,D,E,F,G,H,I,J',
        'Neural2'  => 'A,B,C,D,E,F,G,H,I,J'
    ),
    'es-ES' => array(
        'name'     => 'Español (España)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'B,C,D',
        'Neural2'  => 'A,B,C,D,E,F'
    ),
    'es-US' => array(
        'name'     => 'Español (Estados Unidos)',
        'Standard' => 'A,B,C',
        'Wavenet'  => 'A,B,C',
        'Neural2'  => 'A,B,C'
    ),
    'fil-PH' => array(
        'name'     => 'Filipino (Pilipinas)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B'
    ),
    'fr-CA' => array(
        'name'     => 'Français (Canada)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B,C,D'
    ),
    'fr-FR' => array(
        'name'     => 'Français (France)',
        'Standard' => 'A,B,C,D,E',
        'Wavenet'  => 'A,B,C,D,E',
        'Neural2'  => 'A,B,C,D,E'
    ),
    'it-IT' => array(
        'name'     => 'Italiano (Italia)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,C'
    ),
    'lv-LV' => array(
        'name'     => 'Latviešu (latviešu)',
        'Standard' => 'A',
        'Wavenet'  => ''
    ),
    'hu-HU' => array(
        'name'     => 'Magyar (Magyarország)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'nl-NL' => array(
        'name'     => 'Nederlands (Nederland)',
        'Standard' => 'A,B,C,D,E',
        'Wavenet'  => 'A,B,C,D,E'
    ),
    'nb-NO' => array(
        'name'     => 'Norsk bokmål (Norge)',
        'Standard' => 'A,B,C,D,E',
        'Wavenet'  => 'A,B,C,D,E'
    ),
    'pl-PL' => array(
        'name'     => 'Polski (Polska)',
        'Standard' => 'A,B,C,D,E',
        'Wavenet'  => 'A,B,C,D,E'
    ),
    'pt-BR' => array(
        'name'     => 'Português (Brasil)',
        'Standard' => 'A',
        'Wavenet'  => 'A',
        'Neural2'  => 'A,B,C'
    ),
    'pt-PT' => array(
        'name'     => 'Português (Portugal)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D'
    ),
    'ro-RO' => array(
        'name'     => 'Română (România)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'sk-SK' => array(
        'name'     => 'Slovenčina (Slovensko)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'fi-FI' => array(
        'name'     => 'Suomi (Suomi)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'sv-SE' => array(
        'name'     => 'Svenska (Sverige)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'vi-VN' => array(
        'name'     => 'Việt Nam',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,D'
    ),
    'tr-TR' => array(
        'name'     => 'Türkçe (Türkiye)',
        'Standard' => 'A,B,C,D,E',
        'Wavenet'  => 'A,B,C,D,E'
    ),
    'is-IS' => array(
        'name'     => 'Íslenska (Ísland)',
        'Standard' => 'A',
        'Wavenet'  => ''
    ),
    'cs-CZ' => array(
        'name'     => 'Čeština (Česká republika)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'el-GR' => array(
        'name'     => 'Ελληνικά (Ελλάδα)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'bg-BG' => array(
        'name'     => 'Български (България)',
        'Standard' => 'A',
        'Wavenet'  => ''
    ),
    'ru-RU' => array(
        'name'     => 'Русский (Россия)',
        'Standard' => 'A,B,C,D,E',
        'Wavenet'  => 'A,B,C,D,E'
    ),
    'sr-RS' => array(
        'name'     => 'Српски (Србија)',
        'Standard' => 'A',
        'Wavenet'  => ''
    ),
    'uk-UA' => array(
        'name'     => 'Українська (Україна)',
        'Standard' => 'A',
        'Wavenet'  => 'A'
    ),
    'hi-IN' => array(
        'name'     => 'हिन्दी (भारत)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B,C,D'
    ),
    'bn-IN' => array(
        'name'     => 'বাংলা (ভারত)',
        'Standard' => 'A,B',
        'Wavenet'  => 'A,B'
    ),
    'gu-IN' => array(
        'name'     => 'ગુજરાતી (ભારત)',
        'Standard' => 'A,B',
        'Wavenet'  => 'A,B'
    ),
    'ta-IN' => array(
        'name'     => 'தமிழ் (இந்தியா)',
        'Standard' => 'A,B',
        'Wavenet'  => 'A,B'
    ),
    'te-IN' => array(
        'name'     => 'తెలుగు (భారతదేశం)',
        'Standard' => 'A,B',
        'Wavenet'  => ''
    ),
    'kn-IN' => array(
        'name'     => 'ಕನ್ನಡ (ಭಾರತ)',
        'Standard' => 'A,B',
        'Wavenet'  => 'A,B'
    ),
    'ml-IN' => array(
        'name'     => 'മലയാളം (ഇന്ത്യ)',
        'Standard' => 'A,B',
        'Wavenet'  => 'A,B'
    ),
    'th-TH' => array(
        'name'     => 'ไทย (ประเทศไทย)',
        'Standard' => 'A',
        'Wavenet'  => '',
        'Neural2'  => 'C'
    ),
    'cmn-TW' => array(
        'name'     => '國語 (台灣)',
        'Standard' => 'A,B,C',
        'Wavenet'  => 'A,B,C'
    ),
    'yue-HK' => array(
        'name'     => '廣東話 (香港)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => ''
    ),
    'ja-JP' => array(
        'name'     => '日本語（日本)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'B,C,D'
    ),
    'cmn-CN' => array(
        'name'     => '普通话 (中国大陆)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D'
    ),
    'ko-KR' => array(
        'name'     => '한국어 (대한민국)',
        'Standard' => 'A,B,C,D',
        'Wavenet'  => 'A,B,C,D',
        'Neural2'  => 'A,B,C'
    )
);

$lang_azure = [
    "af-ZA" => "Nam Phi",
    "am-ET" => "Ethiopia",
    "ar-AE" => "UAE",
    "az-AZ" => "Azerbaijan",
    "bg-BG" => "Bulgaria",
    "bn-BD" => "Bangladesh",
    "bs-BA" => "Bosnia và Herzegovina",
    "ca-ES" => "Tây Ban Nha",
    "cs-CZ" => "Cộng hòa Séc",
    "cy-GB" => "Vương quốc Anh",
    "da-DK" => "Đan Mạch",
    "de-DE" => "Đức",
    "el-GR" => "Hy Lạp",
    "en-US" => "Hoa Kỳ",
    "es-ES" => "Tây Ban Nha",
    "et-EE" => "Estonia",
    "fa-IR" => "Iran",
    "fi-FI" => "Phần Lan",
    "fr-FR" => "Pháp",
    "ga-IE" => "Ireland",
    "gu-IN" => "Ấn Độ",
    "he-IL" => "Israel",
    "hi-IN" => "Ấn Độ",
    "hr-HR" => "Croatia",
    "hu-HU" => "Hungary",
    "hy-AM" => "Armenia",
    "id-ID" => "Indonesia",
    "is-IS" => "Iceland",
    "it-IT" => "Ý",
    "ja-JP" => "Nhật Bản",
    "jv-ID" => "Indonesia",
    "ka-GE" => "Georgia",
    "kk-KZ" => "Kazakhstan",
    "km-KH" => "Campuchia",
    "ko-KR" => "Hàn Quốc",
    "lo-LA" => "Lào",
    "lt-LT" => "Lithuania",
    "lv-LV" => "Latvia",
    "mk-MK" => "Bắc Macedonia",
    "ml-IN" => "Ấn Độ",
    "mn-MN" => "Mông Cổ",
    "ms-MY" => "Malaysia",
    "mt-MT" => "Malta",
    "my-MM" => "Myanmar",
    "nb-NO" => "Na Uy",
    "ne-NP" => "Nepal",
    "nl-NL" => "Hà Lan",
    "pl-PL" => "Ba Lan",
    "ps-AF" => "Afghanistan",
    "pt-BR" => "Brazil",
    "ro-RO" => "Romania",
    "ru-RU" => "Nga",
    "si-LK" => "Sri Lanka",
    "sk-SK" => "Slovakia",
    "sl-SI" => "Slovenia",
    "so-SO" => "Somalia",
    "sq-AL" => "Albania",
    "sr-RS" => "Serbia",
    "sv-SE" => "Thụy Điển",
    "sw-KE" => "Kenya",
    "ta-IN" => "Ấn Độ",
    "th-TH" => "Thái Lan",
    "tr-TR" => "Thổ Nhĩ Kỳ",
    "uk-UA" => "Ukraine",
    "ur-PK" => "Pakistan",
    "uz-UZ" => "Uzbekistan",
    "vi-VN" => "Việt Nam",
    "zh-CN" => "Trung Quốc",
    "zh-HK" => "Hồng Kông",
    "zh-TW" => "Đài Loan",
];

$tts_azure = [
    "af-ZA" => [
        [
            "LocalName" => "Adri",
            "ShortName" => "af-ZA-AdriNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Willem",
            "ShortName" => "af-ZA-WillemNeural",
            "Gender" => "Male",
        ],
    ],
    "am-ET" => [
        [
            "LocalName" => "መቅደስ",
            "ShortName" => "am-ET-MekdesNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "አምሀ",
            "ShortName" => "am-ET-AmehaNeural",
            "Gender" => "Male",
        ],
    ],
    "ar-AE" => [
        [
            "LocalName" => "فاطمة",
            "ShortName" => "ar-AE-FatimaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "حمدان",
            "ShortName" => "ar-AE-HamdanNeural",
            "Gender" => "Male",
        ],
    ],
    "az-AZ" => [
        [
            "LocalName" => "Banu",
            "ShortName" => "az-AZ-BanuNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Babək",
            "ShortName" => "az-AZ-BabekNeural",
            "Gender" => "Male",
        ],
    ],
    "bg-BG" => [
        [
            "LocalName" => "Калина",
            "ShortName" => "bg-BG-KalinaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Борислав",
            "ShortName" => "bg-BG-BorislavNeural",
            "Gender" => "Male",
        ],
    ],
    "bn-BD" => [
        [
            "LocalName" => "নবনীতা",
            "ShortName" => "bn-BD-NabanitaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "প্রদ্বীপ",
            "ShortName" => "bn-BD-PradeepNeural",
            "Gender" => "Male",
        ],
    ],
    "bs-BA" => [
        [
            "LocalName" => "Vesna",
            "ShortName" => "bs-BA-VesnaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Goran",
            "ShortName" => "bs-BA-GoranNeural",
            "Gender" => "Male",
        ],
    ],
    "ca-ES" => [
        [
            "LocalName" => "Joana",
            "ShortName" => "ca-ES-JoanaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Enric",
            "ShortName" => "ca-ES-EnricNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Alba",
            "ShortName" => "ca-ES-AlbaNeural",
            "Gender" => "Female",
        ],
    ],
    "cs-CZ" => [
        [
            "LocalName" => "Vlasta",
            "ShortName" => "cs-CZ-VlastaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Antonín",
            "ShortName" => "cs-CZ-AntoninNeural",
            "Gender" => "Male",
        ],
    ],
    "cy-GB" => [
        [
            "LocalName" => "Nia",
            "ShortName" => "cy-GB-NiaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Aled",
            "ShortName" => "cy-GB-AledNeural",
            "Gender" => "Male",
        ],
    ],
    "da-DK" => [
        [
            "LocalName" => "Christel",
            "ShortName" => "da-DK-ChristelNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Jeppe",
            "ShortName" => "da-DK-JeppeNeural",
            "Gender" => "Male",
        ],
    ],
    "de-DE" => [
        [
            "LocalName" => "Katja",
            "ShortName" => "de-DE-KatjaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Conrad",
            "ShortName" => "de-DE-ConradNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Amala",
            "ShortName" => "de-DE-AmalaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Bernd",
            "ShortName" => "de-DE-BerndNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Christoph",
            "ShortName" => "de-DE-ChristophNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Elke",
            "ShortName" => "de-DE-ElkeNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Florian Mehrsprachig",
            "ShortName" => "de-DE-FlorianMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Gisela",
            "ShortName" => "de-DE-GiselaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Kasper",
            "ShortName" => "de-DE-KasperNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Killian",
            "ShortName" => "de-DE-KillianNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Klarissa",
            "ShortName" => "de-DE-KlarissaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Klaus",
            "ShortName" => "de-DE-KlausNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Louisa",
            "ShortName" => "de-DE-LouisaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Maja",
            "ShortName" => "de-DE-MajaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ralf",
            "ShortName" => "de-DE-RalfNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Seraphina Mehrsprachig",
            "ShortName" => "de-DE-SeraphinaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Tanja",
            "ShortName" => "de-DE-TanjaNeural",
            "Gender" => "Female",
        ],
    ],
    "el-GR" => [
        [
            "LocalName" => "Αθηνά",
            "ShortName" => "el-GR-AthinaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Νέστορας",
            "ShortName" => "el-GR-NestorasNeural",
            "Gender" => "Male",
        ],
    ],
    "en-US" => [
        [
            "LocalName" => "Ava Multilingual",
            "ShortName" => "en-US-AvaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Andrew Multilingual",
            "ShortName" => "en-US-AndrewMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Emma Multilingual",
            "ShortName" => "en-US-EmmaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Brian Multilingual",
            "ShortName" => "en-US-BrianMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Ava",
            "ShortName" => "en-US-AvaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Andrew",
            "ShortName" => "en-US-AndrewNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Emma",
            "ShortName" => "en-US-EmmaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Brian",
            "ShortName" => "en-US-BrianNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Jenny",
            "ShortName" => "en-US-JennyNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Guy",
            "ShortName" => "en-US-GuyNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Aria",
            "ShortName" => "en-US-AriaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Davis",
            "ShortName" => "en-US-DavisNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Jane",
            "ShortName" => "en-US-JaneNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Jason",
            "ShortName" => "en-US-JasonNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Sara",
            "ShortName" => "en-US-SaraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Tony",
            "ShortName" => "en-US-TonyNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Nancy",
            "ShortName" => "en-US-NancyNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Amber",
            "ShortName" => "en-US-AmberNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ana",
            "ShortName" => "en-US-AnaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ashley",
            "ShortName" => "en-US-AshleyNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Brandon",
            "ShortName" => "en-US-BrandonNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Christopher",
            "ShortName" => "en-US-ChristopherNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Cora",
            "ShortName" => "en-US-CoraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Elizabeth",
            "ShortName" => "en-US-ElizabethNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Eric",
            "ShortName" => "en-US-EricNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Jacob",
            "ShortName" => "en-US-JacobNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Jenny Multilingual",
            "ShortName" => "en-US-JennyMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Michelle",
            "ShortName" => "en-US-MichelleNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Monica",
            "ShortName" => "en-US-MonicaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Roger",
            "ShortName" => "en-US-RogerNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Ryan Multilingual",
            "ShortName" => "en-US-RyanMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Steffan",
            "ShortName" => "en-US-SteffanNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Adam Multilingual",
            "ShortName" => "en-US-AdamMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "AIGenerate1",
            "ShortName" => "en-US-AIGenerate1Neural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "AIGenerate2",
            "ShortName" => "en-US-AIGenerate2Neural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "AlloyTurboMultilingual",
            "ShortName" => "en-US-AlloyTurboMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Amanda Multilingual",
            "ShortName" => "en-US-AmandaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Blue",
            "ShortName" => "en-US-BlueNeural",
            "Gender" => "Neutral",
        ],
        [
            "LocalName" => "Brandon Multilingual",
            "ShortName" => "en-US-BrandonMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Christopher Multilingual",
            "ShortName" => "en-US-ChristopherMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Cora Multilingual",
            "ShortName" => "en-US-CoraMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Davis Multilingual",
            "ShortName" => "en-US-DavisMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Derek Multilingual",
            "ShortName" => "en-US-DerekMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Dustin Multilingual",
            "ShortName" => "en-US-DustinMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Evelyn Multilingual",
            "ShortName" => "en-US-EvelynMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Kai",
            "ShortName" => "en-US-KaiNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Lewis Multilingual",
            "ShortName" => "en-US-LewisMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Lola Multilingual",
            "ShortName" => "en-US-LolaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Luna",
            "ShortName" => "en-US-LunaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Nancy Multilingual",
            "ShortName" => "en-US-NancyMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "NovaTurboMultilingual",
            "ShortName" => "en-US-NovaTurboMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Phoebe Multilingual",
            "ShortName" => "en-US-PhoebeMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Samuel Multilingual",
            "ShortName" => "en-US-SamuelMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Serena Multilingual",
            "ShortName" => "en-US-SerenaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Steffan Multilingual",
            "ShortName" => "en-US-SteffanMultilingualNeural",
            "Gender" => "Male",
        ],
    ],
    "es-ES" => [
        [
            "LocalName" => "Elvira",
            "ShortName" => "es-ES-ElviraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Álvaro",
            "ShortName" => "es-ES-AlvaroNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Abril",
            "ShortName" => "es-ES-AbrilNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Arnau",
            "ShortName" => "es-ES-ArnauNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Dario",
            "ShortName" => "es-ES-DarioNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Elias",
            "ShortName" => "es-ES-EliasNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Estrella",
            "ShortName" => "es-ES-EstrellaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Irene",
            "ShortName" => "es-ES-IreneNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Laia",
            "ShortName" => "es-ES-LaiaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Lia",
            "ShortName" => "es-ES-LiaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Nil",
            "ShortName" => "es-ES-NilNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Saul",
            "ShortName" => "es-ES-SaulNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Teo",
            "ShortName" => "es-ES-TeoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Triana",
            "ShortName" => "es-ES-TrianaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Vera",
            "ShortName" => "es-ES-VeraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ximena",
            "ShortName" => "es-ES-XimenaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Arabella Multilingual",
            "ShortName" => "es-ES-ArabellaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Isidora Multilingual",
            "ShortName" => "es-ES-IsidoraMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Tristan Multilingual",
            "ShortName" => "es-ES-TristanMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Ximena Multilingual",
            "ShortName" => "es-ES-XimenaMultilingualNeural",
            "Gender" => "Female",
        ],
    ],
    "et-EE" => [
        [
            "LocalName" => "Anu",
            "ShortName" => "et-EE-AnuNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Kert",
            "ShortName" => "et-EE-KertNeural",
            "Gender" => "Male",
        ],
    ],
    "fa-IR" => [
        [
            "LocalName" => "دلارا",
            "ShortName" => "fa-IR-DilaraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "فرید",
            "ShortName" => "fa-IR-FaridNeural",
            "Gender" => "Male",
        ],
    ],
    "fi-FI" => [
        [
            "LocalName" => "Selma",
            "ShortName" => "fi-FI-SelmaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Harri",
            "ShortName" => "fi-FI-HarriNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Noora",
            "ShortName" => "fi-FI-NooraNeural",
            "Gender" => "Female",
        ],
    ],
    "fr-FR" => [
        [
            "LocalName" => "Denise",
            "ShortName" => "fr-FR-DeniseNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Henri",
            "ShortName" => "fr-FR-HenriNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Alain",
            "ShortName" => "fr-FR-AlainNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Brigitte",
            "ShortName" => "fr-FR-BrigitteNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Celeste",
            "ShortName" => "fr-FR-CelesteNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Claude",
            "ShortName" => "fr-FR-ClaudeNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Coralie",
            "ShortName" => "fr-FR-CoralieNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Eloise",
            "ShortName" => "fr-FR-EloiseNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Jacqueline",
            "ShortName" => "fr-FR-JacquelineNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Jerome",
            "ShortName" => "fr-FR-JeromeNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Josephine",
            "ShortName" => "fr-FR-JosephineNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Maurice",
            "ShortName" => "fr-FR-MauriceNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Rémy Multilingue",
            "ShortName" => "fr-FR-RemyMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Vivienne Multilingue",
            "ShortName" => "fr-FR-VivienneMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Yves",
            "ShortName" => "fr-FR-YvesNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Yvette",
            "ShortName" => "fr-FR-YvetteNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Lucien Multilingual",
            "ShortName" => "fr-FR-LucienMultilingualNeural",
            "Gender" => "Male",
        ],
    ],
    "ga-IE" => [
        [
            "LocalName" => "Orla",
            "ShortName" => "ga-IE-OrlaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Colm",
            "ShortName" => "ga-IE-ColmNeural",
            "Gender" => "Male",
        ],
    ],
    "gu-IN" => [
        [
            "LocalName" => "ધ્વની",
            "ShortName" => "gu-IN-DhwaniNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "નિરંજન",
            "ShortName" => "gu-IN-NiranjanNeural",
            "Gender" => "Male",
        ],
    ],
    "he-IL" => [
        [
            "LocalName" => "הילה",
            "ShortName" => "he-IL-HilaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "אברי",
            "ShortName" => "he-IL-AvriNeural",
            "Gender" => "Male",
        ],
    ],
    "hi-IN" => [
        [
            "LocalName" => "आरव ",
            "ShortName" => "hi-IN-AaravNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "अनन्या",
            "ShortName" => "hi-IN-AnanyaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "काव्या",
            "ShortName" => "hi-IN-KavyaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "कुनाल ",
            "ShortName" => "hi-IN-KunalNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "रेहान",
            "ShortName" => "hi-IN-RehaanNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "स्वरा",
            "ShortName" => "hi-IN-SwaraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "मधुर",
            "ShortName" => "hi-IN-MadhurNeural",
            "Gender" => "Male",
        ],
    ],
    "hr-HR" => [
        [
            "LocalName" => "Gabrijela",
            "ShortName" => "hr-HR-GabrijelaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Srećko",
            "ShortName" => "hr-HR-SreckoNeural",
            "Gender" => "Male",
        ],
    ],
    "hu-HU" => [
        [
            "LocalName" => "Noémi",
            "ShortName" => "hu-HU-NoemiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Tamás",
            "ShortName" => "hu-HU-TamasNeural",
            "Gender" => "Male",
        ],
    ],
    "hy-AM" => [
        [
            "LocalName" => "Անահիտ",
            "ShortName" => "hy-AM-AnahitNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Հայկ",
            "ShortName" => "hy-AM-HaykNeural",
            "Gender" => "Male",
        ],
    ],
    "id-ID" => [
        [
            "LocalName" => "Gadis",
            "ShortName" => "id-ID-GadisNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ardi",
            "ShortName" => "id-ID-ArdiNeural",
            "Gender" => "Male",
        ],
    ],
    "is-IS" => [
        [
            "LocalName" => "Guðrún",
            "ShortName" => "is-IS-GudrunNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Gunnar",
            "ShortName" => "is-IS-GunnarNeural",
            "Gender" => "Male",
        ],
    ],
    "it-IT" => [
        [
            "LocalName" => "Elsa",
            "ShortName" => "it-IT-ElsaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Isabella",
            "ShortName" => "it-IT-IsabellaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Diego",
            "ShortName" => "it-IT-DiegoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Benigno",
            "ShortName" => "it-IT-BenignoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Calimero",
            "ShortName" => "it-IT-CalimeroNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Cataldo",
            "ShortName" => "it-IT-CataldoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Fabiola",
            "ShortName" => "it-IT-FabiolaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Fiamma",
            "ShortName" => "it-IT-FiammaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Gianni",
            "ShortName" => "it-IT-GianniNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Giuseppe",
            "ShortName" => "it-IT-GiuseppeNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Imelda",
            "ShortName" => "it-IT-ImeldaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Irma",
            "ShortName" => "it-IT-IrmaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Lisandro",
            "ShortName" => "it-IT-LisandroNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Palmira",
            "ShortName" => "it-IT-PalmiraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Pierina",
            "ShortName" => "it-IT-PierinaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Rinaldo",
            "ShortName" => "it-IT-RinaldoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Alessio Multilingual",
            "ShortName" => "it-IT-AlessioMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Giuseppe Multilingual",
            "ShortName" => "it-IT-GiuseppeMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Isabella Multilingual",
            "ShortName" => "it-IT-IsabellaMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Marcello Multilingual",
            "ShortName" => "it-IT-MarcelloMultilingualNeural",
            "Gender" => "Male",
        ],
    ],
    "ja-JP" => [
        [
            "LocalName" => "七海",
            "ShortName" => "ja-JP-NanamiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "圭太",
            "ShortName" => "ja-JP-KeitaNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "碧衣",
            "ShortName" => "ja-JP-AoiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "大智",
            "ShortName" => "ja-JP-DaichiNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "真夕",
            "ShortName" => "ja-JP-MayuNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "直紀",
            "ShortName" => "ja-JP-NaokiNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "志織",
            "ShortName" => "ja-JP-ShioriNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "勝 多言語",
            "ShortName" => "ja-JP-MasaruMultilingualNeural",
            "Gender" => "Male",
        ],
    ],
    "jv-ID" => [
        [
            "LocalName" => "Siti",
            "ShortName" => "jv-ID-SitiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Dimas",
            "ShortName" => "jv-ID-DimasNeural",
            "Gender" => "Male",
        ],
    ],
    "ka-GE" => [
        [
            "LocalName" => "ეკა",
            "ShortName" => "ka-GE-EkaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "გიორგი",
            "ShortName" => "ka-GE-GiorgiNeural",
            "Gender" => "Male",
        ],
    ],
    "kk-KZ" => [
        [
            "LocalName" => "Айгүл",
            "ShortName" => "kk-KZ-AigulNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Дәулет",
            "ShortName" => "kk-KZ-DauletNeural",
            "Gender" => "Male",
        ],
    ],
    "km-KH" => [
        [
            "LocalName" => "ស្រីមុំ",
            "ShortName" => "km-KH-SreymomNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "ពិសិដ្ឋ",
            "ShortName" => "km-KH-PisethNeural",
            "Gender" => "Male",
        ],
    ],
    "ko-KR" => [
        [
            "LocalName" => "선히",
            "ShortName" => "ko-KR-SunHiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "인준",
            "ShortName" => "ko-KR-InJoonNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "봉진",
            "ShortName" => "ko-KR-BongJinNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "국민",
            "ShortName" => "ko-KR-GookMinNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "현수",
            "ShortName" => "ko-KR-HyunsuNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "지민",
            "ShortName" => "ko-KR-JiMinNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "서현",
            "ShortName" => "ko-KR-SeoHyeonNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "순복",
            "ShortName" => "ko-KR-SoonBokNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "유진",
            "ShortName" => "ko-KR-YuJinNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Hyunsu Multilingual",
            "ShortName" => "ko-KR-HyunsuMultilingualNeural",
            "Gender" => "Male",
        ],
    ],
    "lo-LA" => [
        [
            "LocalName" => "ແກ້ວມະນີ",
            "ShortName" => "lo-LA-KeomanyNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "ຈັນທະວົງ",
            "ShortName" => "lo-LA-ChanthavongNeural",
            "Gender" => "Male",
        ],
    ],
    "lt-LT" => [
        [
            "LocalName" => "Ona",
            "ShortName" => "lt-LT-OnaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Leonas",
            "ShortName" => "lt-LT-LeonasNeural",
            "Gender" => "Male",
        ],
    ],
    "lv-LV" => [
        [
            "LocalName" => "Everita",
            "ShortName" => "lv-LV-EveritaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Nils",
            "ShortName" => "lv-LV-NilsNeural",
            "Gender" => "Male",
        ],
    ],
    "mk-MK" => [
        [
            "LocalName" => "Марија",
            "ShortName" => "mk-MK-MarijaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Александар",
            "ShortName" => "mk-MK-AleksandarNeural",
            "Gender" => "Male",
        ],
    ],
    "ml-IN" => [
        [
            "LocalName" => "ശോഭന",
            "ShortName" => "ml-IN-SobhanaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "മിഥുൻ",
            "ShortName" => "ml-IN-MidhunNeural",
            "Gender" => "Male",
        ],
    ],
    "mn-MN" => [
        [
            "LocalName" => "Есүй",
            "ShortName" => "mn-MN-YesuiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Батаа",
            "ShortName" => "mn-MN-BataaNeural",
            "Gender" => "Male",
        ],
    ],
    "ms-MY" => [
        [
            "LocalName" => "Yasmin",
            "ShortName" => "ms-MY-YasminNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Osman",
            "ShortName" => "ms-MY-OsmanNeural",
            "Gender" => "Male",
        ],
    ],
    "mt-MT" => [
        [
            "LocalName" => "Grace",
            "ShortName" => "mt-MT-GraceNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Joseph",
            "ShortName" => "mt-MT-JosephNeural",
            "Gender" => "Male",
        ],
    ],
    "my-MM" => [
        [
            "LocalName" => "နီလာ",
            "ShortName" => "my-MM-NilarNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "သီဟ",
            "ShortName" => "my-MM-ThihaNeural",
            "Gender" => "Male",
        ],
    ],
    "nb-NO" => [
        [
            "LocalName" => "Pernille",
            "ShortName" => "nb-NO-PernilleNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Finn",
            "ShortName" => "nb-NO-FinnNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Iselin",
            "ShortName" => "nb-NO-IselinNeural",
            "Gender" => "Female",
        ],
    ],
    "ne-NP" => [
        [
            "LocalName" => "हेमकला",
            "ShortName" => "ne-NP-HemkalaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "सागर",
            "ShortName" => "ne-NP-SagarNeural",
            "Gender" => "Male",
        ],
    ],
    "nl-NL" => [
        [
            "LocalName" => "Fenna",
            "ShortName" => "nl-NL-FennaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Maarten",
            "ShortName" => "nl-NL-MaartenNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Colette",
            "ShortName" => "nl-NL-ColetteNeural",
            "Gender" => "Female",
        ],
    ],
    "pl-PL" => [
        [
            "LocalName" => "Agnieszka",
            "ShortName" => "pl-PL-AgnieszkaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Marek",
            "ShortName" => "pl-PL-MarekNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Zofia",
            "ShortName" => "pl-PL-ZofiaNeural",
            "Gender" => "Female",
        ],
    ],
    "ps-AF" => [
        [
            "LocalName" => "لطيفه",
            "ShortName" => "ps-AF-LatifaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => " ګل نواز",
            "ShortName" => "ps-AF-GulNawazNeural",
            "Gender" => "Male",
        ],
    ],
    "pt-BR" => [
        [
            "LocalName" => "Francisca",
            "ShortName" => "pt-BR-FranciscaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Antônio",
            "ShortName" => "pt-BR-AntonioNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Brenda",
            "ShortName" => "pt-BR-BrendaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Donato",
            "ShortName" => "pt-BR-DonatoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Elza",
            "ShortName" => "pt-BR-ElzaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Fabio",
            "ShortName" => "pt-BR-FabioNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Giovanna",
            "ShortName" => "pt-BR-GiovannaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Humberto",
            "ShortName" => "pt-BR-HumbertoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Julio",
            "ShortName" => "pt-BR-JulioNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Leila",
            "ShortName" => "pt-BR-LeilaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Leticia",
            "ShortName" => "pt-BR-LeticiaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Manuela",
            "ShortName" => "pt-BR-ManuelaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Nicolau",
            "ShortName" => "pt-BR-NicolauNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Thalita",
            "ShortName" => "pt-BR-ThalitaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Valerio",
            "ShortName" => "pt-BR-ValerioNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Yara",
            "ShortName" => "pt-BR-YaraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Macerio Multilingual",
            "ShortName" => "pt-BR-MacerioMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Thalita multilíngue",
            "ShortName" => "pt-BR-ThalitaMultilingualNeural",
            "Gender" => "Female",
        ],
    ],
    "ro-RO" => [
        [
            "LocalName" => "Alina",
            "ShortName" => "ro-RO-AlinaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Emil",
            "ShortName" => "ro-RO-EmilNeural",
            "Gender" => "Male",
        ],
    ],
    "ru-RU" => [
        [
            "LocalName" => "Светлана",
            "ShortName" => "ru-RU-SvetlanaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Дмитрий",
            "ShortName" => "ru-RU-DmitryNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Дария",
            "ShortName" => "ru-RU-DariyaNeural",
            "Gender" => "Female",
        ],
    ],
    "si-LK" => [
        [
            "LocalName" => "තිළිණි",
            "ShortName" => "si-LK-ThiliniNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "සමීර",
            "ShortName" => "si-LK-SameeraNeural",
            "Gender" => "Male",
        ],
    ],
    "sk-SK" => [
        [
            "LocalName" => "Viktória",
            "ShortName" => "sk-SK-ViktoriaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Lukáš",
            "ShortName" => "sk-SK-LukasNeural",
            "Gender" => "Male",
        ],
    ],
    "sl-SI" => [
        [
            "LocalName" => "Petra",
            "ShortName" => "sl-SI-PetraNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Rok",
            "ShortName" => "sl-SI-RokNeural",
            "Gender" => "Male",
        ],
    ],
    "so-SO" => [
        [
            "LocalName" => "Ubax",
            "ShortName" => "so-SO-UbaxNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Muuse",
            "ShortName" => "so-SO-MuuseNeural",
            "Gender" => "Male",
        ],
    ],
    "sq-AL" => [
        [
            "LocalName" => "Anila",
            "ShortName" => "sq-AL-AnilaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ilir",
            "ShortName" => "sq-AL-IlirNeural",
            "Gender" => "Male",
        ],
    ],
    "sr-RS" => [
        [
            "LocalName" => "Софија",
            "ShortName" => "sr-RS-SophieNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Никола",
            "ShortName" => "sr-RS-NicholasNeural",
            "Gender" => "Male",
        ],
    ],
    "sv-SE" => [
        [
            "LocalName" => "Sofie",
            "ShortName" => "sv-SE-SofieNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Mattias",
            "ShortName" => "sv-SE-MattiasNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Hillevi",
            "ShortName" => "sv-SE-HilleviNeural",
            "Gender" => "Female",
        ],
    ],
    "sw-KE" => [
        [
            "LocalName" => "Zuri",
            "ShortName" => "sw-KE-ZuriNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Rafiki",
            "ShortName" => "sw-KE-RafikiNeural",
            "Gender" => "Male",
        ],
    ],
    "ta-IN" => [
        [
            "LocalName" => "பல்லவி",
            "ShortName" => "ta-IN-PallaviNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "வள்ளுவர்",
            "ShortName" => "ta-IN-ValluvarNeural",
            "Gender" => "Male",
        ],
    ],
    "th-TH" => [
        [
            "LocalName" => "เปรมวดี",
            "ShortName" => "th-TH-PremwadeeNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "นิวัฒน์",
            "ShortName" => "th-TH-NiwatNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "อัจฉรา",
            "ShortName" => "th-TH-AcharaNeural",
            "Gender" => "Female",
        ],
    ],
    "tr-TR" => [
        [
            "LocalName" => "Emel",
            "ShortName" => "tr-TR-EmelNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Ahmet",
            "ShortName" => "tr-TR-AhmetNeural",
            "Gender" => "Male",
        ],
    ],
    "uk-UA" => [
        [
            "LocalName" => "Поліна",
            "ShortName" => "uk-UA-PolinaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Остап",
            "ShortName" => "uk-UA-OstapNeural",
            "Gender" => "Male",
        ],
    ],
    "ur-PK" => [
        [
            "LocalName" => "عظمیٰ",
            "ShortName" => "ur-PK-UzmaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "اسد",
            "ShortName" => "ur-PK-AsadNeural",
            "Gender" => "Male",
        ],
    ],
    "uz-UZ" => [
        [
            "LocalName" => "Madina",
            "ShortName" => "uz-UZ-MadinaNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Sardor",
            "ShortName" => "uz-UZ-SardorNeural",
            "Gender" => "Male",
        ],
    ],
    "vi-VN" => [
        [
            "LocalName" => "Hoài My",
            "ShortName" => "vi-VN-HoaiMyNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "Nam Minh",
            "ShortName" => "vi-VN-NamMinhNeural",
            "Gender" => "Male",
        ],
    ],
    "zh-CN" => [
        [
            "LocalName" => "晓晓",
            "ShortName" => "zh-CN-XiaoxiaoNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "云希",
            "ShortName" => "zh-CN-YunxiNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云健",
            "ShortName" => "zh-CN-YunjianNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "晓伊",
            "ShortName" => "zh-CN-XiaoyiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "云扬",
            "ShortName" => "zh-CN-YunyangNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "晓辰",
            "ShortName" => "zh-CN-XiaochenNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓辰 多语言",
            "ShortName" => "zh-CN-XiaochenMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓涵",
            "ShortName" => "zh-CN-XiaohanNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓梦",
            "ShortName" => "zh-CN-XiaomengNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓墨",
            "ShortName" => "zh-CN-XiaomoNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓秋",
            "ShortName" => "zh-CN-XiaoqiuNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓柔",
            "ShortName" => "zh-CN-XiaorouNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓睿",
            "ShortName" => "zh-CN-XiaoruiNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓双",
            "ShortName" => "zh-CN-XiaoshuangNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓晓 方言",
            "ShortName" => "zh-CN-XiaoxiaoDialectsNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓晓 多语言",
            "ShortName" => "zh-CN-XiaoxiaoMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓颜",
            "ShortName" => "zh-CN-XiaoyanNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓悠",
            "ShortName" => "zh-CN-XiaoyouNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓宇 多语言",
            "ShortName" => "zh-CN-XiaoyuMultilingualNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "晓甄",
            "ShortName" => "zh-CN-XiaozhenNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "云枫",
            "ShortName" => "zh-CN-YunfengNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云皓",
            "ShortName" => "zh-CN-YunhaoNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云杰",
            "ShortName" => "zh-CN-YunjieNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云夏",
            "ShortName" => "zh-CN-YunxiaNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云野",
            "ShortName" => "zh-CN-YunyeNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云逸 多语言",
            "ShortName" => "zh-CN-YunyiMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "云泽",
            "ShortName" => "zh-CN-YunzeNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Yunfan Multilingual",
            "ShortName" => "zh-CN-YunfanMultilingualNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "Yunxiao Multilingual",
            "ShortName" => "zh-CN-YunxiaoMultilingualNeural",
            "Gender" => "Male",
        ],
    ],
    "zh-HK" => [
        [
            "LocalName" => "曉曼",
            "ShortName" => "zh-HK-HiuMaanNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "雲龍",
            "ShortName" => "zh-HK-WanLungNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "曉佳",
            "ShortName" => "zh-HK-HiuGaaiNeural",
            "Gender" => "Female",
        ],
    ],
    "zh-TW" => [
        [
            "LocalName" => "曉臻",
            "ShortName" => "zh-TW-HsiaoChenNeural",
            "Gender" => "Female",
        ],
        [
            "LocalName" => "雲哲",
            "ShortName" => "zh-TW-YunJheNeural",
            "Gender" => "Male",
        ],
        [
            "LocalName" => "曉雨",
            "ShortName" => "zh-TW-HsiaoYuNeural",
            "Gender" => "Female",
        ],
    ],
];
