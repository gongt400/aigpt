jQuery(document).ready(function ($) {
    "use strict";

    $("#clear_cache").on("click", function () {
        const $button = $(this);
        const $status = $("#clear_cache_status");

        $button.prop("disabled", true);
        $status.html("<span style=\"color: #666;\">Đang xóa cache...</span>");

        $.ajax({
            url: vnaicontent_obj.ajaxurl,
            type: "POST",
            data: {
                action: "clear_cache",
                nonce: vnaicontent_obj.clear_cache_nonce
            },
            success: function (response) {
                if (response.success) {
                    const processed = response.data.processed || 0;
                    const transients = response.data.transients_deleted || 0;
                    $status.html(`<span style="color: green;">✓ Đã xóa cache thành công! (${processed} bài viết, ${transients} transients)</span>`);
                } else {
                    $status.html("<span style=\"color: red;\">✗ " + (response.data || "Có lỗi xảy ra!") + "</span>");
                }
            },
            error: function () {
                $status.html("<span style=\"color: red;\">✗ Có lỗi xảy ra!</span>");
            },
            complete: function () {
                $button.prop("disabled", false);
                setTimeout(function () {
                    $status.html("");
                }, 3000);
            }
        });
    });

    var hash = window.location.hash.substring(1);
    if (hash) {
        $('.tab-links button').removeClass('active');
        $('.tab-content').removeClass('active');
        $('.tab-links button[data-tab="' + hash + '"]').addClass('active');
        $('#' + hash).addClass('active');
    } else {
        $('.tab-links button.button-first').addClass('active');
        $('.tab-content-first').addClass('active');
    }

    $('.tab-links button').click(function () {
        var tabID = $(this).data('tab');
        window.location.hash = tabID;
        $('.tab-links button').removeClass('active');
        $(this).addClass('active');
        $('.tab-content').removeClass('active');
        $('#' + tabID).addClass('active');
    });

    $('#vnaicontent-form').submit(function (e) {
        var activeTab = window.location.hash;
        if (activeTab) {
            $(this).attr('action', $(this).attr('action') + activeTab);
        }
    });

    $('#audio_lang_azure_speech').change(function () {
        var selectedLang = $(this).val();
        $('#audio_voice_azure_speech option').removeClass('show').addClass('hide');
        $('#audio_voice_azure_speech option.' + selectedLang).removeClass('hide').addClass('show');
        $('#audio_voice_azure_speech').val($('#audio_voice_azure_speech option.show:first').val());

        $('#audio_voice_azure_speech2 option').removeClass('show').addClass('hide');
        $('#audio_voice_azure_speech2 option.' + selectedLang).removeClass('hide').addClass('show');
        $('#audio_voice_azure_speech2').val($('#audio_voice_azure_speech2 option.show:first').val());
    });

    $('#audio_lang_gg').change(function () {
        var selectedLang = $(this).val();
        $('#audio_voice_gg option').removeClass('show').addClass('hide');
        $('#audio_voice_gg option.' + selectedLang).removeClass('hide').addClass('show');
        $('#audio_voice_gg').val($('#audio_voice_gg option.show:first').val());

        $('#audio_voice_gg2 option').removeClass('show').addClass('hide');
        $('#audio_voice_gg2 option.' + selectedLang).removeClass('hide').addClass('show');
        $('#audio_voice_gg2').val($('#audio_voice_gg2 option.show:first').val());
    });

    var podcast_thumb;
    $('#podcast_thumb_select').click(function () {
        if (podcast_thumb) {
            podcast_thumb.open();
            return;
        }
        podcast_thumb = wp.media.frames.file_frame = wp.media({
            title: 'Chọn logo',
            button: {
                text: 'Chọn logo'
            },
            library: {
                type: 'image'
            },
            multiple: false
        });
        podcast_thumb.on('select', function () {
            var attachment = podcast_thumb.state().get('selection').first().toJSON();
            var logo = attachment.url;
            $('#podcast_thumb').val(logo);
        });
        podcast_thumb.open();
    });
    $('#podcast_thumb_reset').click(function () {
        $('#podcast_thumb').val('');
    });

    //filterkeyword
    $('#model option').hide();
    $('.model-gemini').show();
    $('#model').val($('.model-gemini:first').val());

    $('#ai').change(function () {
        var selectedAI = $(this).val();
        $('#model option').hide();
        $('.model-' + selectedAI).show();
        $('#model').val($('.model-' + selectedAI + ':first').val());
    });

    $('#keyword-txt').on('change', function (e) {
        var file = e.target.files[0];
        if (file) {
            if (file.type !== 'text/plain') {
                $('#filterkeyword-res').html('<div class="error">Vui lòng chọn file txt danh sách keyword</div>');
                $(this).val('');
            }
        }
    });

    $('.filter-keyword-btn').on('click', function () {
        var $button = $(this);

        if ($button.hasClass('disabled')) {
            return;
        }
        $button.addClass('disabled');

        var lang = $('#lang').val();
        var ai = $('#ai').val();
        var model = $('#model').val();
        var file = $('#keyword-txt')[0].files[0];
        var topic = $('#topic').val().trim();

        var errors = [];

        if (!file) errors.push("Chưa chọn file txt danh sách keyword");
        if (!topic) errors.push("Chưa nhập \"Lọc lấy những keyword về\"");

        if (errors.length > 0) {
            notice(errors.join('<br>'));
            $button.removeClass('disabled');
        } else {
            var formData = new FormData();
            formData.append('action', 'vnaicontent_filterkeyword');
            formData.append('nonce', vnaicontent_obj.filterkeyword_nonce);
            formData.append('lang', lang);
            formData.append('ai', ai);
            formData.append('model', model);
            formData.append('file', file);
            formData.append('topic', topic);

            $.ajax({
                url: vnaicontent_obj.ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function () {
                    $('#filterkeyword-res').html('<div class="loading">' + ai + ' đang lọc từ khóa, vui lòng đợi ...</div>');
                },
                success: function (response) {
                    if (response.success && response.data && response.data.html) {
                        notice('Lọc từ khóa thành công', true);
                        $('#filterkeyword-res').html(response.data.html);
                    } else {
                        var errorMessage = response.data || 'Đã xảy ra lỗi không xác định.';
                        notice(errorMessage);
                    }
                    $button.removeClass('disabled');
                },
                error: function (xhr, status, error) {
                    notice(error);
                    $button.removeClass('disabled');
                }
            });
        }
    });

    //createprompt
    $(document).on('click', '#btn-create-ai-as, #btn-create-prompt', function () {
        var $button = $(this);

        if ($('.btn-create').hasClass('disabled')) {
            return;
        }
        $('.btn-create').addClass('disabled');

        $('.btn-create').removeClass('btn-prompt-selected');

        var ai = $('#ai').val();
        var model = $('#model').val();
        var topic = $('#prompt-topic').val().trim();
        var is_detail = $('#prompt-is-detail').prop('checked') ? 'yes' : '';
        var is_as_ai = $button.attr('id') === 'btn-create-ai-as' ? 'yes' : '';

        var errors = [];

        if (!topic) errors.push("Chưa nhập \"chủ đề\"");

        if (errors.length > 0) {
            $('.notice').show().addClass('notice-error').find('strong').html(errors.join());
            notice(errors.join());
            $('.btn-create').removeClass('disabled');
        } else {
            var formData = new FormData();
            formData.append('action', 'vnaicontent_createprompt');
            formData.append('nonce', vnaicontent_obj.createprompt_nonce);
            formData.append('ai', ai);
            formData.append('model', model);
            formData.append('topic', topic);
            formData.append('is_detail', is_detail);
            formData.append('is_as_ai', is_as_ai);

            $.ajax({
                url: vnaicontent_obj.ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function () {
                    $('#res-prompt').html('<div class="loading">' + ai + ' đang tạo ' + (is_as_ai === 'yes' ? 'vai trò AI' : 'prompt') + ', vui lòng đợi ...</div>');
                },
                success: function (response) {
                    if (response.success && response.data && response.data.html) {
                        $('#res-prompt').html(response.data.html);
                        notice('Tạo ' + (is_as_ai === 'yes' ? 'vai trò AI' : 'prompt') + ' thành công', true);
                        $button.addClass('btn-prompt-selected');
                    } else {
                        var errorMessage = response.data || 'Đã xảy ra lỗi không xác định.';
                        notice(errors.errorMessage);
                    }
                    $('.btn-create').removeClass('disabled');
                },
                error: function (xhr, status, error) {
                    notice(error);
                    $('.btn-create').removeClass('disabled');
                }
            });
        }
    });

    $(document).on('click', '#prompt-to-cat', function () {
        var $button = $(this);

        if ($button.hasClass('disabled')) {
            return;
        }
        $button.addClass('disabled');

        var cat = $('#cat-prompt').val();
        var prompt = $('.prompt-content').html().trim();

        var type_prompt = $('.btn-prompt-selected').attr('id') === 'btn-create-ai-as' ? 'ai_as' : 'prompt';

        var errors = [];

        if (!cat) errors.push("Chưa chọn danh mục");

        if (errors.length > 0) {
            notice(errors.join());
            $button.removeClass('disabled');
        } else {
            var formData = new FormData();
            formData.append('action', 'vnaicontent_createprompt_savecat');
            formData.append('nonce', vnaicontent_obj.createprompt_savecat_nonce);
            formData.append('cat', cat);
            formData.append('prompt', prompt);
            formData.append('type_prompt', type_prompt);

            $.ajax({
                url: vnaicontent_obj.ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success && response.data && response.data.html) {
                        notice(response.data.html, true);

                        var cur_prompt = $((type_prompt === 'ai_as' ? '#ai_as_cate' : '#prompt_cate') + cat);

                        cur_prompt.text(prompt);
                        $('html, body').animate({
                            scrollTop: cur_prompt.offset().top - ($(window).height() / 2) + (cur_prompt.outerHeight() / 2)
                        }, 1000);
                        cur_prompt.focus();
                    } else {
                        var errorMessage = response.data || 'Đã xảy ra lỗi không xác định.';
                        notice(errorMessage);
                    }
                    $button.removeClass('disabled');
                },
                error: function (xhr, status, error) {
                    notice(error);
                    $button.removeClass('disabled');
                }
            });
        }
    });

    $(document).on('click', '#copy-keyword', function () {
        var content = $('.prompt-content').text();
        var $temp = $("<textarea>");
        $("body").append($temp);
        $temp.val(content).select();
        document.execCommand("copy");
        $temp.remove();
        $('#copy-mess').fadeIn(100);
        $('#copy-mess').fadeOut(5000);
    });

    $(document).on('click', '.notice-dismiss', function () {
        var $notice = $(this).closest('.notice').hide();
    });

    function notice(content, success = false) {
        return $('.notice').show()
            .toggleClass('notice-success', success)
            .toggleClass('notice-error', !success)
            .find('strong').html(content)
            .end()
            .delay(5000)
            .fadeOut(2000);
    }

    //debug log
    $('.vnaicontent-toggle-button[data-action="toggle_debug_log"]').on('click', function (e) {
        e.preventDefault();
        var $button = $(this);

        $.ajax({
            url: vnaicontent_obj.ajaxurl,
            type: 'POST',
            data: {
                action: 'vnaicontent_toggle_debug_log',
                nonce: vnaicontent_obj.config_nonce
            },
            success: function (response) {
                if (response.success) {
                    var newStatus = response.status;
                    $button.toggleClass('button-primary button-secondary');
                    $button.html(newStatus ? '1. <strong>WP_DEBUG_LOG</strong> (đang bật)' : '1. <strong>WP_DEBUG_LOG</strong> (đang tắt)');

                    vnaicontent_obj.config_nonce = response.newNonce;

                    if (newStatus) {
                        $('#vnaicontent-error-log-container').show();
                        refreshErrorLog();
                    } else {
                        $('#vnaicontent-error-log-container').hide();
                    }

                    vnaicontent_obj.debug_enabled = newStatus;
                } else {
                    alert('Failed to toggle debug settings: ' + response.message);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error('AJAX Error:', textStatus, errorThrown);
                alert('An error occurred while toggling debug settings. Please check the console for more details.');
            }
        });
    });

    function refreshErrorLog() {
        $.ajax({
            url: vnaicontent_obj.ajaxurl,
            type: 'POST',
            data: {
                action: 'vnaicontent_read_log',
                nonce: vnaicontent_obj.read_log_nonce
            },
            success: function (response) {
                if (response.success) {
                    $('#vnaicontent-error-log').val(response.data);
                } else {
                    $('#vnaicontent-error-log').val('Failed to read log: ' + response.message);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error('AJAX Error:', textStatus, errorThrown);
                $('#vnaicontent-error-log').val('An error occurred while fetching the log. Please check the console for more details.');
            }
        });
    }

    $('#vnaicontent-refresh-log').on('click', refreshErrorLog);

    $('#vnaicontent-clear-log').on('click', function () {
        if (confirm('Are you sure you want to clear the debug log?')) {
            $.ajax({
                url: vnaicontent_obj.ajaxurl,
                type: 'POST',
                data: {
                    action: 'vnaicontent_clear_log',
                    nonce: vnaicontent_obj.read_log_nonce
                },
                success: function (response) {
                    if (response.success) {
                        alert(response.message);
                        refreshErrorLog();
                    } else {
                        alert('Failed to clear log: ' + response.message);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.error('AJAX Error:', textStatus, errorThrown);
                    alert('An error occurred while clearing the log. Please check the console for more details.');
                }
            });
        }
    });

    if (vnaicontent_obj.debug_enabled && $('#vnaicontent-error-log').length) {
        refreshErrorLog();
    }
    //===

    $('#openai_model_img').change(function () {
        var openai_model_img = $(this).val();
        if (openai_model_img == 'dall-e-2') {
            $('#openai_size_img').val('512x512');
            $('.only-2').show();
            $('.only-3').hide();
        } else {
            $('#openai_size_img').val('1024x1024');
            $('.only-2').hide();
            $('.only-3').show();
        }
    });

    //edit post
    function string_to_slug(str) {
        str = str.trim();
        str = str.toLowerCase();
        str = str.replace(/á|à|ả|ạ|ã|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ/gi, 'a');
        str = str.replace(/é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ/gi, 'e');
        str = str.replace(/i|í|ì|ỉ|ĩ|ị/gi, 'i');
        str = str.replace(/ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ/gi, 'o');
        str = str.replace(/ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự/gi, 'u');
        str = str.replace(/ý|ỳ|ỷ|ỹ|ỵ/gi, 'y');
        str = str.replace(/đ/gi, 'd');
        str = str.replace(/\`|\~|\!|\@|\#|\||\$|\%|\^|\&|\*|\(|\)|\+|\=|\,|\.|\/|\?|\>|\<|\'|\"|\:|\;|_/gi, '');
        str = str.replace(/ /gi, "-");
        str = str.replace(/\-\-\-\-\-/gi, '-');
        str = str.replace(/\-\-\-\-/gi, '-');
        str = str.replace(/\-\-\-/gi, '-');
        str = str.replace(/\-\-/gi, '-');
        str = '@' + str + '@';
        str = str.replace(/\@\-|\-\@|\@/gi, '');
        return str;
    }

    $('#vnaicontent_keyword').on('input', function () {
        var keyword_in = $(this).val();
        var slug_in = string_to_slug(keyword_in);
        $('#vnaicontent_slug').addClass('slug-focus').val(slug_in);
    });

    vnaicontent_create_post();
    function vnaicontent_create_post() {
        var ajax_running = false;
        $('.vnaicontent-cmd').off('click').on('click', function (event) {
            event.preventDefault();
            if (ajax_running) {
                return;
            }

            var keyword = $('#vnaicontent_keyword').val();
            if (keyword != '') {
                var id = $('#ctrl-cmd').data('id');
                var cur = $(this);
                var cur_text = cur.html();
                var cmd = cur.data('cmd');
                var type_ai = $('#vnaicontent_ai').val();
                var img_by = $('#vnaicontent_img_by').val();
                var content = $('#vnaicontent_content').html();
                var cat = '';
                if ($('#categorychecklist input:checked:first').length > 0) {
                    cat = $('#categorychecklist input:checked:first').val();
                }

                var mess = $(this).data('mess');
                if (cmd === 'create_title') {
                    mess = 'tạo <select id="num_title" name="num_title">';
                    for (var i = 1; i <= 15; i++) {
                        mess += '<option value="' + i + '">' + i + '</option>';
                    }
                    mess += '</select> tiêu đề?';
                }

                if (cmd === 'create_img' && img_by === '') {
                    $('#vnaicontent-dialog-content').html('Tính năng "Tạo ảnh" đang Tắt!');
                    $('#vnaicontent-dialog').dialog({
                        resizable: false,
                        height: "auto",
                        width: 400,
                        modal: true,
                        draggable: false,
                        position: { my: "center", at: "center", of: window },
                        buttons: {
                            "OK": function () {
                                $(this).dialog("close");
                            }
                        }
                    });
                } else {
                    $('#vnaicontent-dialog-content').html('Bạn muốn ' + mess);
                    $('#vnaicontent-dialog').dialog({
                        resizable: false,
                        height: "auto",
                        width: 400,
                        modal: true,
                        draggable: false,
                        position: { my: "center", at: "center", of: window },
                        buttons: {
                            "Đồng ý": function () {
                                $(this).dialog("close");
                                var num_title = $('#num_title').val();

                                if (cmd === 'create_all' || cmd === 'create_title' || cmd === 'create_img' || cmd === 'create_content') {
                                    ajax_running = true;
                                    $('.vnaicontent-btn').attr('disabled', true);

                                    $.ajax({
                                        method: 'POST',
                                        url: ajaxurl,
                                        data: {
                                            action: 'vnaicontent_create_post',
                                            cmd: cmd,
                                            type_ai: type_ai,
                                            img_by: img_by,
                                            keyword: keyword,
                                            id: id,
                                            content: content,
                                            num_title: num_title,
                                            cat: cat
                                        },
                                        beforeSend: function () {
                                            cur.html('<span class="spinner is-active"></span><span class="red-text">Vui lòng đợi, không tải lại trang!</span>');
                                        },
                                        success: function (response) {
                                            cur.html(cur_text);
                                            var res = JSON.parse(response);

                                            if (res['error'] !== '') {
                                                $('#vnaicontent-dialog-content').html(res['error']);
                                                $('#vnaicontent-dialog').dialog({
                                                    resizable: false,
                                                    height: "auto",
                                                    width: 400,
                                                    modal: true,
                                                    draggable: false,
                                                    position: { my: "center", at: "center", of: window },
                                                    buttons: {
                                                        "OK": function () {
                                                            $(this).dialog("close");
                                                        }
                                                    }
                                                });
                                            } else {
                                                if (cmd === 'create_all') {
                                                    if (res['title'] !== null && res['content'] !== null) {
                                                        $('#vnaicontent_title').val(res['title']);
                                                        $('#vnaicontent_content').html(res['content']);
                                                        $('#ctrl-cmd').html('<button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_all" data-mess="tạo lại bài viết?">Tạo lại bài viết</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_title" data-mess="tạo lại tiêu đề?">Tạo lại tiêu đề</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_img" data-mess="tạo ảnh? (Chỉ tạo ảnh, nội dung không thay đổi!)">Tạo ảnh</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_content" data-mess="tạo lại nội dung?">Tạo lại nội dung</button><button type="button" id="vnaicontent-save-draft" class="vnaicontent-btn button vnaicontent-save-post" data-cmd="save_draft" data-mess="lưu bản nháp?">Lưu nháp</button><button type="button" id="vnaicontent-save-publish" class="vnaicontent-btn button button-primary vnaicontent-save-post" data-cmd="save_publish" data-mess="xuất bản bài viết?">Xuất bản</button>');
                                                    }
                                                } else {
                                                    if (cmd === 'create_title' && res['title'] !== null) {
                                                        var lines = res['title'].trimEnd().split('\n').map(line => line.replace(/^- |^\* /, ''));
                                                        var list_title = `<ul>${lines.map(line => `<li>${line}</li>`).join('')}</ul>`;

                                                        $('#list-title').html(list_title);
                                                        $('#list-title li').on('click', function (e) {
                                                            e.preventDefault();
                                                            $('#list-title li').removeClass('title-cur');
                                                            $(this).addClass('title-cur');

                                                            var decode_html = $('<div>').html($(this).html()).text();
                                                            $('#vnaicontent_title').val(decode_html);
                                                        });

                                                        $('#ctrl-cmd').html('<button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_all" data-mess="tạo lại bài viết?">Tạo lại bài viết</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_title" data-mess="tạo lại tiêu đề?">Tạo lại tiêu đề</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_img" data-mess="tạo ảnh? (Chỉ tạo ảnh, nội dung không thay đổi!)">Tạo ảnh</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_content" data-mess="tạo lại nội dung?">Tạo lại nội dung</button><button type="button" id="vnaicontent-save-draft" class="vnaicontent-btn button vnaicontent-save-post" data-cmd="save_draft" data-mess="lưu bản nháp?">Lưu nháp</button><button type="button" id="vnaicontent-save-publish" class="vnaicontent-btn button button-primary vnaicontent-save-post" data-cmd="save_publish" data-mess="xuất bản bài viết?">Xuất bản</button>');
                                                    } else if ((cmd === 'create_img' || cmd === 'create_content') && res['content'] !== null) {
                                                        $('#vnaicontent_content').html(res['content']);
                                                        $('#ctrl-cmd').html('<button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_all" data-mess="tạo lại bài viết?">Tạo lại bài viết</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_title" data-mess="tạo lại tiêu đề?">Tạo lại tiêu đề</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_img" data-mess="tạo ảnh? (Chỉ tạo ảnh, nội dung không thay đổi!)">Tạo ảnh</button><button type="button" class="vnaicontent-btn button vnaicontent-cmd" data-cmd="create_content" data-mess="tạo lại nội dung?">Tạo lại nội dung</button><button type="button" id="vnaicontent-save-draft" class="vnaicontent-btn button vnaicontent-save-post" data-cmd="save_draft" data-mess="lưu bản nháp?">Lưu nháp</button><button type="button" id="vnaicontent-save-publish" class="vnaicontent-btn button button-primary vnaicontent-save-post" data-cmd="save_publish" data-mess="xuất bản bài viết?">Xuất bản</button>');
                                                    }
                                                }
                                                vnaicontent_create_post();
                                            }

                                            ajax_running = false;
                                            $('.vnaicontent-btn').attr('disabled', false);

                                            vnaicontent_save_post();
                                        },
                                        error: function () {
                                            ajax_running = false;
                                            $('.vnaicontent-btn').attr('disabled', false);
                                        }
                                    });
                                } else {
                                    alert('Thất bại! 2');
                                }

                            },
                            "Hủy": function () {
                                $(this).dialog("close");
                            }
                        }
                    });
                }
            } else {
                $('#vnaicontent-dialog-content').html('<span class="red-text">Từ khóa không thể bỏ trống!</span>');
                $('#vnaicontent-dialog').dialog({
                    resizable: false,
                    height: "auto",
                    width: 400,
                    modal: true,
                    draggable: false,
                    position: { my: "center", at: "center", of: window },
                    buttons: {
                        "OK": function () {
                            $(this).dialog("close");
                            $("#vnaicontent_keyword").focus();
                        }
                    }
                });
            }
        });
    }

    vnaicontent_save_post();
    function vnaicontent_save_post() {
        var ajax_running = false;
        $('.vnaicontent-save-post').off('click').on('click', function (event) {
            event.preventDefault();
            if (ajax_running) {
                return;
            }

            var cur = $(this);
            var cur_text = cur.html();
            var cmd = cur.data('cmd');

            var id = $('#ctrl-cmd').data('id');
            var type_ai = $('#vnaicontent_ai').val();
            var img_by = $('#vnaicontent_img_by').val();
            var keyword = $('#vnaicontent_keyword').val();
            var slug = $('#vnaicontent_slug').val();
            var title = $('#vnaicontent_title').val();
            var content = $('#vnaicontent_content').html();
            var cat = '';
            if ($('#categorychecklist input:checked:first').length > 0) {
                cat = $('#categorychecklist input:checked:first').val();
            }

            if (keyword != '' && slug != '' && title != '' && content != '') {
                var mess = $(this).data('mess');

                $('#vnaicontent-dialog-content').html('Bạn muốn ' + mess);

                $('#vnaicontent-dialog').dialog({
                    resizable: false,
                    height: "auto",
                    width: 400,
                    modal: true,
                    draggable: false,
                    position: { my: "center", at: "center", of: window },
                    buttons: {
                        "Đồng ý": function () {
                            $(this).dialog("close");

                            if (cmd === 'save_draft' || cmd === 'save_publish') {
                                ajax_running = true;
                                $('.vnaicontent-btn').attr('disabled', true);

                                $.ajax({
                                    method: 'POST',
                                    url: ajaxurl,
                                    data: {
                                        action: 'vnaicontent_save_post',
                                        cmd: cmd,
                                        id: id,
                                        type_ai: type_ai,
                                        img_by: img_by,
                                        keyword: keyword,
                                        slug: slug,
                                        title: title,
                                        content: content,
                                        cat: cat
                                    },
                                    beforeSend: function () {
                                        cur.html('<span class="spinner is-active"></span><span class="red-text">Vui lòng đợi, không tải lại trang!</span>');
                                    },
                                    success: function (response) {
                                        cur.html(cur_text);
                                        ajax_running = false;
                                        $('.vnaicontent-btn').attr('disabled', false);

                                        var res = JSON.parse(response);

                                        if (res['status'] === 'ok') {
                                            var mess_save_post = '<span class="green-text">Đã lưu bản nháp!</span>';
                                            if (cmd === 'save_publish') {
                                                mess_save_post = '<span class="green-text">Đã xuất bản bài viết!</span>';
                                            }
                                            $('#vnaicontent-dialog-content').html(mess_save_post);

                                            $('#vnaicontent-dialog').dialog({
                                                resizable: false,
                                                height: "auto",
                                                width: 400,
                                                modal: true,
                                                draggable: false,
                                                position: { my: "center", at: "center", of: window },
                                                dialogClass: 'no-close',
                                                buttons: {
                                                    "OK": function () {
                                                        $(this).dialog("close");
                                                        window.location.href = res['mess'].replace(/&amp;/g, '&');
                                                    }
                                                }
                                            });
                                        } else {
                                            $('#vnaicontent-dialog-content').html(res['mess']);
                                            $('#vnaicontent-dialog').dialog({
                                                resizable: false,
                                                height: "auto",
                                                width: 400,
                                                modal: true,
                                                draggable: false,
                                                position: { my: "center", at: "center", of: window },
                                                buttons: {
                                                    "OK": function () {
                                                        $(this).dialog("close");
                                                    }
                                                }
                                            });
                                        }

                                        vnaicontent_create_post();
                                    },
                                    error: function () {
                                        ajax_running = false;
                                        $('.vnaicontent-btn').attr('disabled', false);
                                    }
                                });
                            }
                        },
                        "Hủy": function () {
                            $(this).dialog("close");
                        }
                    }
                });
            } else {
                $('#vnaicontent-dialog-content').html('<span class="red-text">Các trường không thể bỏ trống!</span>');
                $('#vnaicontent-dialog').dialog({
                    resizable: false,
                    height: "auto",
                    width: 400,
                    modal: true,
                    draggable: false,
                    position: { my: "center", at: "center", of: window },
                    buttons: {
                        "OK": function () {
                            $(this).dialog("close");
                        }
                    }
                });
            }
        });
    }

    $('#select-cat').on('click', function (event) {
        event.preventDefault();
        $('#select-cat-dialog').dialog({
            resizable: false,
            height: "auto",
            width: 600,
            modal: true,
            draggable: false,
            position: { my: "center", at: "center", of: window },
            dialogClass: 'no-close',
            buttons: {
                "OK": function () {
                    $(this).dialog("close");
                }
            }
        });
    });

    ajax_load_keyword();
    function ajax_load_keyword() {
        $('#ajax-cat-keywords').change(function () {
            var cat = $(this).val();

            if (cat) {
                $.ajax({
                    method: 'POST',
                    url: ajaxurl + '?' + new Date().getTime(),
                    data: {
                        action: 'ajax_load_keyword',
                        cat: cat
                    },
                    beforeSend: function () {
                        $('#ajax-list-keyword').html('<span class="spinner is-active"></span><span class="red-text">Vui lòng đợi, không tải lại trang!</span>');
                    },
                    success: function (response) {
                        setTimeout(function () {
                            if (response != '') {
                                let lines = response.split('\n');
                                let ulList = '<ul>';
                                lines.forEach(function (line) {
                                    ulList += `<li>${line}</li>`;
                                });
                                ulList += '</ul>';

                                $('#ajax-list-keyword').html('<div id="cat-' + cat + '" class="ajax-cat">' + ulList + '</div>');

                                $('.ajax-cat li').on('click', function (event) {
                                    event.preventDefault();
                                    $('.ajax-cat li').removeClass('keyword-cur');
                                    $(this).addClass('keyword-cur');
                                    var keyword = $(this).html();
                                    var slug = string_to_slug(keyword);
                                    $('#vnaicontent_keyword').val(keyword);
                                    $('#vnaicontent_slug').addClass('slug-focus').val(slug);
                                    $('#in-category-' + cat).prop('checked', true);
                                });
                            } else {
                                $('#ajax-list-keyword').html('<span class="orange-text">Danh mục này không có từ khóa!</span>');
                            }
                            ajax_load_keyword();
                        }, 300);
                    }
                });
            }
        });
    }

    //settings
    $('#clear-log').click(function (event) {
        event.preventDefault();
        var url = $(this).attr('href');
        $('#clear-log-dialog').dialog({
            resizable: false,
            height: "auto",
            width: 400,
            modal: true,
            draggable: false,
            position: { my: "center", at: "center", of: window },
            buttons: {
                "OK": function () {
                    $(this).dialog("close");
                    window.location.href = url;
                },
                "Hủy": function () {
                    $(this).dialog("close");
                }
            }
        });
    });

    //keywords
    $('#cat-keywords').change(function () {
        var cat_id = $(this).val();
        var url = vnaicontent_obj.keywords;
        if (cat_id != '') {
            url += '&cat=' + cat_id;
        }
        window.location = url;
    });

    save_keyword();
    function save_keyword() {
        $('#save-keyword').off('click').click(function (event) {
            var cat = $(this).attr('data-cat');
            var input_keyword = $('#keyword_' + cat).val();
            var input_keyword_active = $('#keyword_active_' + cat).val();
            var input_keyword_miss = $('#keyword_miss_' + cat).val();
            var input_keyword_post_removed = $('#keyword_post_removed_' + cat).val();
            var input_keyword_not_suitable = $('#keyword_not_suitable_' + cat).val();
            var input_topic = $('#topic_' + cat).val();

            $.ajax({
                method: 'POST',
                url: ajaxurl,
                data: {
                    action: 'vnaicontent_save_keyword',
                    cat: cat,
                    input_keyword: input_keyword,
                    input_keyword_active: input_keyword_active,
                    input_keyword_miss: input_keyword_miss,
                    input_keyword_post_removed: input_keyword_post_removed,
                    input_keyword_not_suitable: input_keyword_not_suitable,
                    input_topic: input_topic,
                },
                beforeSend: function () {
                    $('#save-keyword').attr('disabled', 'disabled').html('<span class="spinner is-active"></span>');
                },
                success: function (content) {
                    setTimeout(function () {
                        $('#list-keyword').html(content);
                        $('#save-keyword').removeAttr('disabled').html('Save');
                        save_keyword();
                    }, 300);
                }
            });
        });
    }

    //mess
    var messTime = 0;
    var messContent = '';
    var updateInterval = 5000;

    function updateMess() {
        $.ajax({
            method: "POST",
            url: ajaxurl,
            data: {
                action: 'vnaicontent_check_mess',
                last_update: messTime
            },
            success: function (content) {
                var result = JSON.parse(content);
                if (result[0] != messTime) {
                    messTime = result[0];
                    messContent = result[1];
                    updateDisplay();
                }
            },
            complete: function () {
                setTimeout(updateMess, updateInterval);
            }
        });
    }

    function updateDisplay() {
        var $messBound = $('#mess-bound');
        $messBound.html('<span class="blinker" id="mess-time" data-mess-time="' + messTime + '"></span> s trước - <span id="mess">' + messContent + '</span>');
        updateTimer();
    }

    function updateTimer() {
        var $messTime = $('#mess-time');
        function updateSeconds() {
            var seconds = Math.floor(Date.now() / 1000) - messTime;
            $messTime.text(seconds);
        }
        updateSeconds();
        setInterval(updateSeconds, 1000);
    }

    if ($('#mess-bound').length) {
        updateMess();
    }

    setTimeout(function () {
        $('.notice.is-dismissible').fadeOut('slow');
    }, 3000);
});